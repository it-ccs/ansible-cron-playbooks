# AccountInfo.pl
#
# Author: Steve Tonnesen
# Email: tonnesen@cmsd.bc.ca
# 
# This script is intended to run on a Windows NT machine.  It listens on port
# 4249 (or the port set in the first argument to the program) and will only
# accept connections from hosts in the valid list below.
#
# The script accepts the following commands:
#
#    add,userid,password,firstname,lastname,type,school,pdc,mail,school,
#    addtoschool,school,type,userid,pdc,mail,file,
#    addtodomain,pdc,userid,firstname,lastname,... (this was never used)
#    addroute,myip,mysubnet,mynetmask,
#    delete,userid,school,type,
#    getuinfo,userid,
#    modify,userid command,
#    getgrouplist,group,
#    newgrp,group,
#    removegrp,group,
#    chpass,userid,password,
#    addgrp,userid,group,school,
#    delgrp,userid,group,school,
#    run,"command",
#    shutdown,
#    restart,
#    quit,
#
# There are _severe_ security implications to running this script.  If 
# anyone can connect to this server, and knows the above commands, they 
# will be able to gain administrator access to your machine in a hurry.
# Please be careful.  Along with the builtin list of valid ports, it might
# not be a bad idea to set up a firewall to deny connections to this 
# server from the Internet at large, and also from unsecure workstations
# in your own intranets.  You have been warned.
#
# I would like to be able to create a secure connection of some kind to this
# server, but I do not have the necessary software on the NT end.
#

# Commas at the beginning and end of this list are necessary, spaces are not
# allowed.

$allowedhosts=",209.52.148.2,";

open (LOG, ">>c:\\admin.log") || print "LOG Failed: $!\n";
$date=localtime(time);
($port,$host)=@ARGV;
($host) || ($host='bell');
($host eq 'bell') && ($host='manhattan');
$host=`hostname`;
chop($host);
($port) || ($port=4250);
$port+=6;
($port == 4266) && ($port=4260);
$oport=$port;
$ohost=$host;
print LOG  "$date HOST: $host, PORT: $port\n";

# This next section listens on the requested port for a connection

$AF_INET = 2;
$SOCK_STREAM = 1;
$sockaddr = 'S n a4 x8';

($name, $aliases, $proto) = getprotobyname('tcp');
if ($port !~ /^\d+$/) {
  ($name, $aliases, $port) = getservbyport($port, 'tcp');
}

$this=pack($sockaddr, $AF_INET, $port, "\0\0\0\0");

select(NS); $| = 1; select(stdout);

socket(S, $AF_INET, $SOCK_STREAM, $proto) || die "socket: $!";
bind(S, $this) || die "bind: $!";
listen(S,5) || die "connect: $!";

select(S); $| = 1; select(stdout);

for($con = 1; ; $con++) {
  close LOG;
  printf("Listening for connection %d....\n", $con);
  ($addr = accept(NS,S)) || die $!;
  open (LOG, ">>c:\\admin$oport.log");
  ($af,$port,$inetaddr) = unpack($sockaddr,$addr);
  @inetaddr = unpack('C4', $inetaddr);
  $address=join('.',@inetaddr);
  print "$con: $af $port $address\n";
  if ($allowedhosts=~/,$address,/) {
    print LOG  "$con: $af $port $address\n";
    print NS "Waiting: \n";
    IN:  while (<NS>) {
      chomp; chomp;
      @params=split(/,/);
      print LOG  "$date: @params\n";
      SWITCH: {
	if ($params[0] eq 'add') { &add(@params); last SWITCH; }
	if ($params[0] eq 'addtoschool') { &addtoschool(@params); last SWITCH; }
	if ($params[0] eq 'addtodomain') { &addtodomain(@params); last SWITCH; }
	if ($params[0] eq 'addroute') { &addroute(@params); last SWITCH; }
	if ($params[0] eq 'delete') { &delete(@params); last SWITCH; }
	if ($params[0] eq 'getuinfo') { &getuinfo(@params); last SWITCH; }
	if ($params[0] eq 'modify') { &modify(@params); last SWITCH; }
	if ($params[0] eq 'getgrouplist') { &getgrouplist(@params); last SWITCH; }
	if ($params[0] eq 'newgrp') { &newgrp(@params); last SWITCH; }
	if ($params[0] eq 'removegrp') { &removegrp(@params); last SWITCH; }
	if ($params[0] eq 'chpass') { &chpass(@params); last SWITCH; }
	if ($params[0] eq 'addgrp') { &addgrp(@params); last SWITCH; }
	if ($params[0] eq 'delgrp') { &delgrp(@params); last SWITCH; }
	if ($params[0] eq 'shutdown') {&shutdown(@params); last SWITCH; }
	if ($params[0] eq 'restart') { &restart(@params); last SWITCH; }
	if ($params[0] eq 'run') { &run(@params); last SWITCH; }
	if ($params[0] eq 'getinfo') { &getinfo(@params); last SWITCH; }
	if ($params[0] eq 'restrict') { &restrict(@params); last SWITCH; }
	if ($params[0] eq 'forward') { &forward(@params); last SWITCH; }
	if ($params[0] eq 'quit') { last IN; }
      }
      print NS "Waiting: \n";
    }
  }
  close(NS);
}

sub getinfo {
  print NS "$host, $oport\n";
}

sub run {
  ($null, $command)=@params;
  open (PR, "$command|");
  while (<PR>) {
    print NS $_;
  }
  print "completed\n";
}



# addroute
#
# Tells the pdc to add a route to the local subnet.  This little script has to
# be able to determine who it's PDC is, what its local subnet is, and what
# the ip address of its dialup interface is.

sub addroute {
  ($null, $myip, $mysubnet, $mynetmask)=@params;
  print "Adding route to $mysubnet/$mynetmask through $myip\n";
  system("route add $mysubnet mask $mynetmask $myip");
  print NS "completed\n";
}

# restrict
#
# Used to limit login times for a user to 8am-4pm Monday through Friday
# Used primarily for secretarial staff who must be able to dial in to
# Manhattan for RISC access.

sub restrict {
  local($userid, $status);
  ($null, $userid, $status)=@params;
  print LOG "Time restriction for $userid: $status\n";
  if ($status eq 'on') {
    open (NU, "net user $userid /TIMES:M-F,8am-4pm|");
  } else {
    open (NU, "net user $userid /TIMES:ALL|");
  }
  while (<NU>) {
    print LOG $_;
  }
  print NS "completed\n";
}

# forward
#
# Used to set mail forwarding policies.  Used on Terrace server only.

sub forward {
  local($userid, $forwardto);
  ($null, $userid, $forwardto)=@params;
  print LOG "Mail forwarded for $userid to $forwardto\n";
  print NS "Forwarding from $userid to $forwardto\n";
  if ($forwardto eq 'showme') {
      print NS "Showing...\n";
    open (IMSCTL, "\\\\mail\\users\\staff\\$userid\\INETMAIL\\INBOX\\IMS.CTL");
    while (<IMSCTL>) {
      chop;
      ($option, $value)=split(/\s+=\s+/);
      if ($option eq 'ForwardTo') {
	print NS "$value\n";
      }
    }
    open (IMSCTL, "\\\\mail\\users\\student\\$userid\\INETMAIL\\INBOX\\IMS.CTL");
    while (<IMSCTL>) {
      chop;
      ($option, $value)=split(/\s+=\s+/);
      if ($option eq 'ForwardTo') {
	print NS "$value\n";
      }
    }

  } elsif ($forwardto eq '') {
    unlink ("\\\\mail\\users\\staff\\$userid\\INETMAIL\\INBOX\\IMS.CTL");
    unlink ("\\\\mail\\users\\student\\$userid\\INETMAIL\\INBOX\\IMS.CTL");
  } else {
    open (IMSCTL, ">\\\\mail\\users\\student\\$userid\\INETMAIL\\INBOX\\IMS.CTL");
    print IMSCTL "[AutoForward]\n";
    print IMSCTL "ForwardTo = $forwardto\n";
    print IMSCTL "[Delivery]\n";
    print IMSCTL "Discard = Yes\n";
    close IMSCTL;
    open (IMSCTL, ">\\\\mail\\users\\staff\\$userid\\INETMAIL\\INBOX\\IMS.CTL");
    print IMSCTL "[AutoForward]\n";
    print IMSCTL "ForwardTo = $forwardto\n";
    print IMSCTL "[Delivery]\n";
    print IMSCTL "Discard = Yes\n";
    close IMSCTL;
  }
  print NS "completed\n";
}


# restart
#
# Restarts the "other" service.  I start two services, one on 4250, and one on 
# 4251.  This allows me to restart one with the other.  I also though that
# I could improve performance by having some connections going to one port
# and some going to the other port.  This turns out not to have been a concern
#

sub restart {
  ($ARGV[0]==4250) ? ($stop=4251) : ($stop=4250);
  print NS "$oport: Stopping $stop\n";
  system("net stop AI$stop");
  system("net start AI$stop");
  print LOG  "Restarted.\n";
  print NS "Restarted.\n";
}

# getuinfo
#
# This subroutine gets the fullname, comment, and account active and dialin
# access flags for a user.  Uses the HTMLUSER.EXE program
#

sub getuinfo {
  local ($start,$end,$fullname,$comment,$active,$dialin,$userid,$i);
  ($null,$userid)=@params;
  print LOG  "Getting user info for $userid\n";
  print NS "Getting user info for $userid\n";
  open (HU, "htmluser $userid|");
  while (<HU>) {
    chop;
    ($start,$end)=split(/\s*:\s*/);
    ($start=~/^Fullname/) && ($fullname=$end);
    ($start=~/^Comment/) && ($comment=$end);
    ($start=~/^Active/) && ($active=$end);
    ($start=~/^Dialin/) && ($dialin=$end);
  }
  print NS "$fullname\n$comment\n$active\n$dialin\n";    
}

# modify
#
# This subroutine goes hand-in-hand with the getuinfo subroutine.  It uses
# the HTMLUSER.EXE program to _set_ the fullname, comment, and account
# active and dialin flags for a user.
#

sub modify {
  local ($out, $return,$userid,$i);
  ($null,$userid)=@params;
  open (HU, "htmluser $userid|");
  while (<HU>) {
    $return=<HU>;
    if ($return=~/^user/) {
      chop($return);
      $out.=$return;
    }
  }
  print NS $out."\n";
}

#
# shutdown
#
# This subroutine exits the Perl script, by stopping the service.
#


sub shutdown {
  system("net stop AI$oport");;
  exit;
}


#
# getgrouplist
#
# gets a list of the members of a group
#

sub getgrouplist {
  local(@members, @g,$group,$null,$start,$g);
  ($null,$group)=@params;
  print LOG  "Getting $group Group List...\n\n";
  open (NU, "net group $group|");
  select NU; $|=1; select STDOUT;
  while(<NU>) {
    if ($start==0) {
      (/^-------/) && ($start=1);
    } else {
      unless (/^The command/) {
	chop;
	if ($group eq '') {
	  @g=split(/\s+\s+/);
	} else {
	  @g=split(/\s+/);
	}
	foreach $g (@g) {
	  (substr($g,0,1) eq "*") && ($g=substr($g,1));
	}
	push (@members,@g);
      }
    }
  }
  close NU;
  while (($members[$#members] eq "") && ($#members >0)) { pop(@members); }
  foreach (@members) {
    print NS "$_\n";
  }
}

#
# removegrp
#
# Deletes a group from the server $pdc.  This, most likely, will not work if
# there are still users in the group.  I'm not certain about that, though.
#


sub removegrp {
  local($group);
  ($null,$group)=@params;
  print LOG  "\nRemoving $group\n";
  open(NU, "net group $group /delete 2>&1|");
  $error=0;
  select NU; $|=1; select STDOUT;
  while(<NU>) {
    if (/NET HELPMSG (\d\d\d\d)/) {
      print LOG  "Error: $1\n";
      ERRORS: {
	if ($1==3755) { print NS "User $username does not exist\n"; last ERRORS; }
	if ($1==3753) { print NS "User $username is not in group $group\n"; last ERRORS; }
	if ($1==3754) { print NS "User already in group\n"; last ERRORS; }
	if ($1==2220) { print NS "Group $group does not exist\n"; last ERRORS; }
	if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
      }
      ($error==2) || ($error=1);
    }
  }
  ($error==2) && ($error=0);
  close NU;
  if ($error == 0) {
    print NS "completed\n";
    print LOG  "completed\n";
  }
}

#
# newgrp
#
# Creates a new group on the server $pdc
#

sub newgrp {
  local($group);
  ($null,$group)=@params;
  print LOG  "HOST: $ohost\n";
  print LOG  "\nCreating $group\n";
  open(NU, "net group $group /add 2>&1|");
  $error=0;
  select NU; $|=1; select STDOUT;
  while(<NU>) {
    if (/NET HELPMSG (\d\d\d\d)/) {
      print LOG  "Error: $1\n";
      ERRORS: {
	if ($1==3755) { print NS "User $username does not exist\n"; last ERRORS; }
	if ($1==3753) { print NS "User $username is not in group $group\n"; last ERRORS; }
	if ($1==3754) { print NS "User already in group\n"; last ERRORS; }
	if ($1==2223) { print NS "Group $group already exists\n"; last ERRORS; }
	if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
      }
      ($error==2) || ($error=1);
    }
  }
  ($error==2) && ($error=0);
  close NU;
  if ($error == 0) {
    print NS "completed\n";
    print LOG  "completed\n";
  }
}

#
# delgrp
#
# removes a user from a group
#


sub delgrp {
  local($username,$group,$school);
  ($null,$username,$group,$school)=@params;
  print LOG  "\nRemoving $username from \"$school $group\"\n";
  open(NU, "net group \"$school $group\" $username /delete 2>&1|");
  $error=0;
  select NU; $|=1; select STDOUT;
  while(<NU>) {
    if (/NET HELPMSG (\d\d\d\d)/) {
      print LOG  "Error: $1\n";
      ERRORS: {
	if ($1==3755) { print NS "User $username does not exist\n"; last ERRORS; }
	if ($1==3753) { $error=2; last ERRORS; print NS "User $username is not in group $group\n"; last ERRORS; }
	if ($1==3754) { print NS "User already in group\n"; last ERRORS; }
	if ($1==2220) { print NS "Group \"$school $group\" does not exist\n"; last ERRORS; }
	if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
      }
      ($error==2) || ($error=1);
    }
  }
  ($error==2) && ($error=0);
  close NU;
  if ($group eq 'imsusers') {
      system("net group imsusers $username /delete");
  }
  if ($group eq 'inactive') {
      system("htmluser $username /active:yes");
  }
  if ($group eq 'timeres') {
    system("net user $username /TIMES:ALL");
  }
  if ($group eq 'dialin') {
      system("htmluser $username /dialin:no");
  }
  if ($error == 0) {
    print NS "completed\n";
    print LOG  "completed\n";
  }
}



#
# addgrp
#
# adds a user to a group
#

sub addgrp {
  local($username,$group,$school);
  ($null,$username,$group,$school)=@params;
  $result=system("net group \"$school $group\"");
  if ($result == 512) {
      system("net group \"$school $group\" /add");
  }
  print LOG  "HOST: $ohost\n";
  print LOG  "\nAdding $username to \"$school $group\"\n";
  open(NU, "net group \"$school $group\" $username /add 2>&1|");
  $error=0;
  select NU; $|=1; select STDOUT;
  while(<NU>) {
    if (/NET HELPMSG (\d\d\d\d)/) {
      print LOG  "Error: $1\n";
      ERRORS: {
	if ($1==3755) { print NS "User $username does not exist\n"; last ERRORS; }
	if ($1==2224) { print NS "User already exists\n"; last ERRORS; }
	if ($1==3754) { $error=2; last ERRORS; print NS "User already in group\n"; last ERRORS; }
	if ($1==2220) { print NS "Group $group does not exist\n"; last ERRORS; }
	if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
      }
      ($error==2) || ($error=1);
    }
  }
  if ($group eq 'imsusers') {
      system("net group imsusers $username /add");
  }
  if ($group eq 'inactive') {
      system("htmluser $username /active:no");
  }
  if ($group eq 'timeres') {
    system("net user $username /TIMES:M-F,8am-4pm");
  }
  if ($group eq 'dialin') {
      system("htmluser $username /dialin:yes");
  }
  close NU;
  ($error==2) && ($error=0);
  if ($error == 0) {
    print NS "completed\n";
    print LOG  "completed\n";
  }
}


#
# addtoschool
#
# adds a user to a school.  The user added should already exist in the domain.
# All that this needs to do is run rcmd on the school server.
#

sub addtoschool {
  local ($user, $school, $type, $pdc, $mail, $file, $s, $m);
  ($null, $school, $type, $user, $pdc, $mail, $file) = @params;
  $m=(split(/\./,$mail))[0];
  $s=(split(/\./,$file))[0];
  $s=~tr/A-Z/a-z/;
  $m=~tr/A-Z/a-z/;
  print LOG  "Adding pre-existing account $user to $school\n";
  print LOG  "\nMaking User Directory: ";
  if ($s ne $m) {
    print LOG  "Same as Mail Directory";
  } else {
    open(MD,"md \\\\$s\\users\\$type\\$user 2>&1|");
    while (<MD>) { chomp; ($_ ne '') && (print LOG  "$_\n"); } close MD;
  }
  print LOG  "\nSetting User's Rights: ";
  open(MD, "cacls \\\\$s\\users\\$type\\$user /E /G $user:F|");
  while (<MD>) { print LOG  $_; } close MD;
  print LOG  "\nrcmd $s: ";
  open(MD, "rcmd \\\\$s rmtadd.bat $s $user $type|");
  while(<MD>) { print LOG  $_; } close MD;
  print NS "completed\n";
  print LOG  "completed\n";
}

#
# addtodomain
#
# adds a user to a secondary domain (ie not bell's sd88.bc.ca domain).  The user added will
# already exist in bell's domain, but will be recreated in the secondary domain.  The user
# will have two passwords until they change their password.  When they change their password
# (using bell's password) the new password will be applied to both domains that they are in.
#
# A more elegant solution would be to start adding users to bell, and all secondary domains at
# the same time, but this does nothing for the thousand accounts that already exist, or the
# problem of adding new secondary domains (Kitimat?) in the future.  Probably leave this little
# glitch alone.  At least everyone will be in the same boat this way.  (Was this user around 
# before Hazelton's domain was created?  Kitimat's?)
#

sub addtodomain {
  local ($user);
  ($null,$pdc,$user,$firstname,$lastname,$password,$type,$school,$dialin,$internet,$web,$mail,$file)=@params;
  print LOG  "Adding pre-existing account $user to $school and $pdc\n";

}
  



#
# add
#
# adds a user.  This is the heart of the program, and the part that will
# most need individual modification.  I haven't given a lot of thought to 
# how best that modification could be performed.  There are several steps 
# where it is nice to know if something fails or not, so I'd rather not
# carve this all out and place it in a batch script, although I could 
# probably still monitor the stdout of the batch script....  Nah.
#


sub add {
  local($pdc,$mail,$server,$username,$password,$firstname,$lastname,$type,$error);
  ($null, $username, $password, $firstname, $lastname, $type, $school, $pdc, $mail, $server)=@params;
  print LOG  "\nAdding $username to $school\n";
  open(NU, "net user $username $password /ADD /fullname:\"$lastname $firstname\" /comment:\"$school $type\" /HOMEDIR:d:\\users\\$type\\$username /scriptpath:login.bat /DOMAIN 2>&1|");
  $error=0;
  select NU; $|=1; select STDOUT;
  while(<NU>) {
    if (/NET HELPMSG (\d\d\d\d)/) {
      print LOG  "Adding User: $1\n";
      ERRORS: {
	if ($1==2245) { print NS "Password too short\n"; last ERRORS; }
	if ($1==2224) { print NS "User already exists\n"; last ERRORS; }
	if ($1==3754) { print NS "User already in group\n"; last ERRORS; }
	if ($1==2220) { print NS "Group does not exist\n"; last ERRORS; }
	if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
      }
      $error=1;
    }
  }
  if (! $error) {
    $host=~tr/A-Z/a-z/;
    print LOG  "HOST: $host\n";
    open(NU, "net group \"$school $type\" $username /ADD 2>&1|");
    while(<NU>) {
      if (/NET HELPMSG (\d\d\d\d)/) {
	ERRORS: {
	  print LOG  "$school $type: $1\n";
	  if ($1==2245) { print NS "Password too short\n"; last ERRORS; }
	  if ($1==2224) { print NS "User already exists\n"; last ERRORS; }
	  if ($1==3754) { print NS "User already in group $school $type\n"; last ERRORS; }
	  if ($1==2220) { print NS "$school $type group does not exist\n"; last ERRORS; }
	  if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
	}
	$error=1;
      }
    }
    open(NU, "net group "imsusers" $username /add 2>&1|");
    while (<NU>) {
	if (/NET HELPMSG(\d\d\d\d)/) {
	    ERRORS: {
		print LOG  "imsusers: $1\n";
		if ($1==2245) { print NS "Password too short\n"; last ERRORS; }
		if ($1==2224) { print NS "User already exists\n"; last ERRORS; }
		if ($1==3754) { print NS "User already in group imsusers\n"; last ERRORS; }
		if ($1==2220) { print NS "imsusers group does not exist\n"; last ERRORS; }
		if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
	    }
	    $error=1;
	}
    }
    if ($host eq 'manhattan') {
      print LOG  "Making Mail Directory (Manhattan) : ";
      open (MD, "md \\\\mail\\users\\$type\\$username 2>&1|");
      while (<MD>) { print LOG  $_; } close MD;
    }
    if ($error == 0) {
      print NS "completed\n";
    }
  }
}


# 
# chpass
#
# Changes a user's password.  Note: no confirmation of old or new passwords.
# As I said before, security is not a concern.  If a user has connected to
# this port, it is assumed they have all rights to the system.
#

sub chpass {
  local($null,$username,$password,$error);
  ($null, $username, $password)=@params;
  open(NU, "net user $username $password 2>&1|");
  $error=0;
  select NU; $|=1; select STDOUT;
  while(<NU>) {
    if (/NET HELPMSG (\d\d\d\d)/) {
      ERRORS: {
	if ($1==2245) { print NS "Password too short\n"; last ERRORS; }
	if ($1==2224) { print NS "User already exists\n"; last ERRORS; }
	if ($1==3754) { print NS "User already in group\n"; last ERRORS; }
	if ($1==2220) { print NS "Group does not exist\n"; last ERRORS; }
	if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
      }
      $error=1;
    }
  }
  if ($error == 0) {
    print NS "completed\n";
  }
}

#
# delete
#
# deletes a user's account.  Currently deletes the user's home directory, but
# not mail directory.  That is bad.  If an administrator creates a user with
# the same userid, they'll get the old user's mail.  Might be better to move
# the user's mail to a holding area, in case the deletion was an accident, or
# the account gets reinstated for some reason.
#

sub delete {
  local($null,$username,$error,$school,$type);
  ($null, $username,$school,$type)=@params;
  print LOG  "\nDeleting $username\n";
  open(NU, "net user $username /delete /DOMAIN 2>&1|");
  $error=0;
  select NU; $|=1; select STDOUT;
  while(<NU>) {
    if (/NET HELPMSG (\d\d\d\d)/) {
      print LOG  "Deleting User: $1\n";
      ERRORS: {
	if ($1==2245) { print NS "Password too short\n"; last ERRORS; }
	if ($1==2224) { print NS "User already exists\n"; last ERRORS; }
	if ($1==3754) { print NS "User already in group\n"; last ERRORS; }
	if ($1==2220) { print NS "Group does not exist\n"; last ERRORS; }
	if ($1==2221) { print NS "User does not exist\n"; last ERRORS; }
	if ($1) { print NS "Unknown error: $1\n"; last ERRORS; }
      }
      $error=1;
    }
  }
  if ($error == 0) {
    print NS "completed\n";
  }
}
