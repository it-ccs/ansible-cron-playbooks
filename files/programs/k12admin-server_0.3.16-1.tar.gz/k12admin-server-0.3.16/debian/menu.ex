?package(k12admin):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="k12admin" command="/usr/bin/k12admin"
