#:OTHER:
k12admin	stream	tcp	nowait	root	/usr/sbin/tcpd /usr/sbin/k12admin
