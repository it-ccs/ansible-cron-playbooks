#!/usr/bin/perl

package ACTIONS;

#
# Translate strings for the ::getstr() subroutine
#

sub submitjavascript {
    my @tasks=split(/\n/,$::query->param('submitdata'));
    print "<h1>Submitted Data</h1>\n";
    foreach (@tasks) {
	my ($task, @params) = split(/\s/, $_);
	if ($task eq 'Password') {
	    my ($userid, $newpass) = @params;
	    print "Changing password for $userid to $newpass.<br>\n";
	}
	if ($task eq 'Deleteuser') {
	    my ($userid) = @params;
	    print "Deleting user $userid.<br>\n";
	}
	if ($task eq 'Addtogroup') {
	    my ($userid,$group,$school) = @params;
	    print "Adding $userid to $group at $school.<br>\n";
	}
	if ($task eq 'Removefromgroup') {
	    my ($userid,$group,$school) = @params;
	    print "Removing $userid from $group at $school.<br>\n";
	}
    }
}

sub translate {
    my @trans=$::query->param;
    foreach (@trans) {
	if (/translation(\d*)/) {
	    my $id=$1;
	    my $translation=(($::query->param($_)) || (''));
	    
	    $q_translation=$::dbh->quote($translation);
	    my $sth=$::dbh->prepare("select $::lang from strings where id=$id");
	    $sth->execute;
	    MENUS::dbherr();
	    my $oldtrans='';
	    if ($sth->rows) {
		($oldtrans) = $sth->fetchrow;
	    }
	    if ($translation ne $oldtrans) {
		::log("Translate:$::lang $id $q_translation");
		$param="update strings set $::lang=$q_translation where id=$id";
		my $sth=$::dbh->prepare($param);
		$sth->execute;
		MENUS::dbherr();
	    }
	}
    }
}


sub adminmachines {
    my $newmachine=$::query->param('newmachine');
    print "Adding $newmachine\$ to domain.<p>\n";
}


sub setdomainadmins {
    my $add = $::query->param("adddomainadmins");
    my @delete  = $::query->param("removedomainadmins");
    print "<hr>\n";
    foreach (@delete) {
	if ($_ eq $::username) {
	    print "You cannot remove yourself as a domain administrator.  If you wish to do this, you must do so from another domain administrator's account.  This is a safety mechanism to prevent you from accidentally removing all domain administrators and leaving the system in an unusable state.<p>\n";
	    next;
	}
	my $q_userid=$::dbh->quote($_);
	my $allones=(2**32-1);
	my $notgroup=$allones-$::flags{'domainadmins'};
	my $sth=$::dbh->prepare("update users set flags=(flags & $notgroup) where userid=$q_userid");
	$sth->execute;
	print ::getstr("Removing domainadmin rights for ","this is followed by a userid") . "$_<br>\n";
    }
    if ($add) {
	my $q_userid=$::dbh->quote($add);
	my $sth=$::dbh->prepare("update users set flags=(flags | $::flags{'domainadmins'}) where userid=$q_userid");
	$sth->execute;
	print ::getstr("Granting domainadmin rights to", "this is followed by a list of userids"). " $add...<br>\n";
    }
    print "<hr>\n";
}

#
# Set the user's preferred language
#

sub language {
    my %langs;
    my $sth=$::dbh->prepare("show columns from strings");
    $sth->execute;
    while (my ($field) = $sth->fetchrow) {
	(next) if ($field eq 'id');
	$langs{$field}=1;
    }
    my $lang=$::query->param("lang");
    unless ($langs{$lang}) {
	print ::getstr("Adding") . " $lang " . ::getstr("to language database.") . "<p>\n";
	my $sth=$::dbh->prepare("alter table strings add column $lang text");
	$sth->execute;
	MENUS::dbherr();
    }
    
    my $q_lang=$::dbh->quote($lang);
    my $q_username=$::dbh->quote($::username);
    $sth=$::dbh->prepare("update users set lang=$q_lang where userid=$q_username");
    $sth->execute;
    MENUS::dbherr();
    print ::getstr("Language variable set to") . " $lang.<hr>\n";
    ::log("ChangeLanguage:$lang");
}

# Updates group information.  This needs to be altered to read from a textarea
# element instead of a selection list as it is pretty slow writing to a
# selection list.  Actually, it might be slow writing to a textarea element
# too.

sub localgroups {
    my %groups;
    my $groups=$::query->param('returndata');
    my @groups=split(/\n/, $groups);
    my $q_s=$::dbh->quote($::adminschool);
    my $membership=0;
    my $endmembership=0;
    foreach (@groups) {
	s/\r//g;
	s/\n//g;
	if ($_ =~/BeginGroupMembership/) {
	    $membership=1;
	    next;
	}
	if ($_ =~/EndGroupMembership/) {
	    $endmembership=1;
	    last;
	}
	if ($membership) {
	    push (@membership, $_);
	    next;
	}
	my ($sn, $order, $ln) = split(/:/, $_, 3);
	$groups{$sn}=1;
	my $q_sn=$::dbh->quote($sn);
	my $q_ln=$::dbh->quote($ln);

# Update grouplists.  Updates viewing order and inserts new groups.

	my $sth=$::dbh->prepare("select shortname from localgroups where school=$q_s and shortname=$q_sn");
	$sth->execute;
	MENUS::dbherr();
	if ($sth->rows) {
	    $sth=$::dbh->prepare("update localgroups set vieworder=$order where school=$q_s and shortname=$q_sn");
	    $sth->execute;
	    MENUS::dbherr();
	} else {
	    ::log("Addgroup: $::adminschool $sn $ln");
	    $sth=$::dbh->prepare("insert into localgroups (school, shortname,longname,vieworder) values ($q_s, $q_sn, $q_ln, $order)");
	    $sth->execute;
	    MENUS::dbherr();
	}
    }

# Deletes removed groups

    $sth=$::dbh->prepare("select shortname from localgroups where school=$q_s");
    $sth->execute;
    MENUS::dbherr();
    while (($sn)=$sth->fetchrow) {
	unless ($groups{$sn}) {
	    $allowedgroups{$group}=1;
	    $q_sn=$::dbh->quote($sn);
	    my $sti=$::dbh->prepare("select longname from localgroups where school=$q_s and shortname=$q_sn");
	    $sti->execute;
	    MENUS::dbherr();
	    my ($ln) = $sti->fetchrow;
	    $sti=$::dbh->prepare("delete from localgroups where school=$q_s and shortname=$q_sn");
	    $sti->execute;
	    MENUS::dbherr();
	    ::log("Deletegroup: $::adminschool $sn $ln");
	}
    }


# Update group memberships.  The $endmembership test just ensures that the
# data received from the form was complete.

    if ($endmembership)  {

# Build a hashtable of current group memberships at this school.

	$sth=$::dbh->prepare("select userid,localgroup from lglist where school='$::adminschool'");
	$sth->execute;
	MENUS::dbherr();
	while (my ($userid,$group)=$sth->fetchrow) {
	    $memberlist{"$userid:$group"}=1;
	}

# Get a list of group restrictions.  Restricted groups are groups that only
# domain admins are allowed to change the membership of.

	$sth=$::dbh->prepare("select id,shortname,restricted from localgroups");
	$sth->execute;
	MENUS::dbherr();
	while (my ($id, $shortname, $restricted)=$sth->fetchrow) {
	    $res{$shortname}=$restricted;
	}

# Run through the list of members from the form, inserting new members into
# their groups and deleting their entry from the %memberlist hashtable.  The
# entries that are left over the %memberlist hashtable need to be removed from
# those groups.

	foreach (@membership) {
	    my ($group, $member) = split (/:/, $_, 2);
	    if (($::indomainadmin) || ($res{$group} == 0)) {
		if ($memberlist{"$member:$group"}) {
		    delete $memberlist{"$member:$group"}
		} else {
		    ::log("Addtogroup:$member $group $::adminschool");
		    if ($::flags{$group}) {
			$sti=$::dbh->prepare("update users set flags=(flags | $::flags{$group}) where userid='$member'");
			$sti->execute;
			MENUS::dbherr();
		    }
		    $sti=$::dbh->prepare("insert into lglist (userid,school,localgroup) values ('$member', '$::adminschool', '$group')");
		    $sti->execute;
		    MENUS::dbherr();
		}
	    }
	}

# Here's where we remove the userid/group combinations that are still in the
# %memberlist hashtable.

	foreach (keys %memberlist) {
	    my ($member, $group) = split(/:/);
	    if (($::indomainadmin) || ($res{$group}==0)) {
		::log("Removefromgroup:$member $group $::adminschool");
		if ($::flags{$group}) {
		    my $allones=(2**32-1);
		    my $notgroup=$allones-$::flags{$group};
		    my $q_userid=$::dbh->quote($member);
		    $sth=$::dbh->prepare("update users set flags=(flags & $notgroup) where userid=$q_userid");
		    $sth->execute;
		    MENUS::dbherr();
		}
		my $q_member=$::dbh->quote($member);
		my $q_s=$::dbh->quote($::adminschool);
		my $q_group=$::dbh->quote($group);
		$sti=$::dbh->prepare("delete from lglist where userid=$q_member and school=$q_s and localgroup=$q_group");
		$sti->execute;
		MENUS::dbherr();
	    }
	}
    } else {
	print "<hr><font color=red>Something went wrong.  The data submitted in the form was not complete.  All changes have been aborted.</font><hr>\n";
	return;
    }
}


# Deprecated.  Replaced by sub localgroups.

sub dellocalgroups {
    local(@groups);
    @groups=$::query->param('dellocalgroups');
    foreach (@groups) {
	# Should check to see if anyone is actually in this localgroup first!!!!
	$st=$::dbh->prepare("delete from localgroups where school=".$::dbh->quote($::adminschool)." and shortname=".$::dbh->quote($_));
	$st->execute;
	MENUS::dbherr();
    }
}


# Deprecated.  Replaced by sub localgroups.

sub createlocalgroups {
    local(@groups);
    @groups=split(/[\n]+/, $::query->param('newlocalgroups'));
    foreach (@groups) {
	$char=chop;
	(ord($char) != 13) && ($_.=$char);
	($short, $long)=split(/,/,$_);
	print ::getstr("Creating new group") . " $long ($short)<br>\n";
#Check if short or long name already exists
	$short=$::dbh->quote($short);
	$long=$::dbh->quote($long);
	$s=$::dbh->quote($::adminschool);
	$st=$::dbh->prepare("insert into localgroups (school, shortname, longname, restricted) values ($s, $short, $long, 0)");
	$st->execute;
MENUS::dbherr();
    }
}


# Deprecated.  Replaced by sub localgroups.

sub modifygroups {
    my @staffadd=$::query->param('staffadd');
    my @staffremove=$::query->param('staffremove');
    my @studentadd=$::query->param('studentadd');
    my @studentremove=$::query->param('studentremove');
    my $school=$::dbh->quote($::adminschool);
    my $lg=$::query->param('modifygroup');
    my $localgroup=$::dbh->quote($::query->param('modifygroup'));
    my $sth=$::dbh->prepare("select school from localgroups where shortname=$localgroup");
    $sth->execute;
    MENUS::dbherr();
    while (my ($s) = $sth->fetchrow) {
#	($s eq 'global') && ($school="'global'");
    }
    foreach (@studentadd) {
	print ::getstr("Added to group:", "this is followed by a userid and a groupname") . " $_ (" . ::getstr("Student") . ") $localgroup.<br>\n";
	::log("Addtogroup:$_ $lg $::adminschool");
	my $userid=$::dbh->quote($_);
	my $sth=$::dbh->prepare("insert into lglist (userid,school,localgroup) values ($userid,$school,$localgroup)");
	$sth->execute;
	MENUS::dbherr();
    }
    foreach (@staffadd) {
	print ::getstr("Added to group:", "this is followed by a userid and a groupname") . " $_ (" . ::getstr("Staff") . ") $localgroup.<br>\n";
	::log("Addtogroup:$_ $lg $::adminschool");
	my $userid=$::dbh->quote($_);
	my $sth=$::dbh->prepare("insert into lglist (userid,school,localgroup) values ($userid,$school,$localgroup)");
	$sth->execute;
	MENUS::dbherr();

    
    }
    foreach (@staffremove) {
	print ::getstr("Removed from group:", "this is followed by a userid and a groupname") . " $_ (" . ::getstr("Staff") . ") " . $::query->param('modifygroup') . "<br>\n";
	::log("Removefromgroup:$_ $lg $::adminschool");
	$userid=$::dbh->quote($_);
	$school=$::dbh->quote($::adminschool);
	$localgroup=$::dbh->quote($::query->param('modifygroup'));
	$sth=$::dbh->prepare("delete from lglist where userid=$userid and school=$school and localgroup=$localgroup");
	$sth->execute;
MENUS::dbherr();

    
    }
    foreach (@studentremove) {
	print ::getstr("Removed from group:", "this is followed by a userid and a groupname") . " $_ (" . ::getstr("Student") . ") " . $::query->param('modifygroup') . "<br>\n";
	::log("Removefromgroup:$_ $lg $::adminschool");
	$userid=$::dbh->quote($_);
	$school=$::dbh->quote($::adminschool);
	$localgroup=$::dbh->quote($::query->param('modifygroup'));
	$sth=$::dbh->prepare("delete from lglist where userid=$userid and school=$school and localgroup=$localgroup");
	$sth->execute;
MENUS::dbherr();

    
    }
}


# Modify individual account ($userid)

sub modify {
    print '<hr><a href="/" onClick="return goOpener(this,true,true)">'.::getstr("Close This Window and return to the list of accounts").'</a><hr>';
    my $userid=$::query->param('account');
    print "<center><h1>" . ::getstr("Modify", "this is followed by a single userid") . " $userid</h1>\n";
    my $f=$::query->param('fullname');
    my $pass1=$::query->param('password1');
    my $pass2=$::query->param('password2');
    my $lg=$::query->param('lg');
    my $gg=$::query->param('gg');
    my $q_userid=$::dbh->quote($userid);
    my $sth=$::dbh->prepare("select fullname,comment,flags from users where userid=$q_userid");
    $sth->execute;
    MENUS::dbherr();
    my ($fullname,$comment,$flags)=$sth->fetchrow;
    my $change=0;

# If fullname was changed then change database.

    if ($f ne $fullname) {
	print ::getstr("Full name changed:", "followed by a userid and a new full name") . "$userid ($f)<br>\n";
	$change=1;
	::log("Fullname:$userid $f");
	my $q_f=$::dbh->quote($f);
	my $daf=$::dbh->prepare("update users set fullname=$q_f where userid=$q_userid");
	$daf->execute;
	MENUS::dbherr();
    }

# If a password was entered, make the changes.  I limit password length to 6-8
# characters.  This may not be appropriate everywhere.

    if ($pass1 eq $pass2) {
	unless ($pass1 eq '') {
	    if ($userid eq 'demoteacher') {
		print "<font color=red>Don't change demoteacher's password!!!!</font><br>\n";
		return;
	    }
	    if (length($pass1) <6 || length($pass1)>8) {
		print "Passwords should be between 6 and 8 characters long.";
	    } else {
		$change=1;
		::log("Password:$userid $pass1");
		my $cryptpass=&crypt($pass1);
		my $q_pass=$::dbh->quote($pass1);
		$sth=$::dbh->prepare("select password from users where userid=$q_userid");
		$sth->execute;
		MENUS::dbherr();
		if ($::configs{'noplaintextpasswords'}) {
		    $q_pass="''";
		}
		if ($sth->rows) {
		    $sth=$::dbh->do("update users set password='$cryptpass',pt=$q_pass where userid=$q_userid");
		} else {
# Yikes!!  How can the user not exist?
		}
		print ::getstr("Password changed.") . "<br>\n";
	    }
	}
    } else {
	print ::getstr("Passwords don't match.  Password has not been changed.") . "<br>\n";
    }

    my (%currentglobal, %currentlocal);

    $sth=$::dbh->prepare("select localgroup from lglist where userid='$userid' and school='$::adminschool'");
    $sth->execute;
    MENUS::dbherr();
    while (my ($g) = $sth->fetchrow) {
	$currentlocal{$g}=1;
    }

    foreach ($::query->param('lg')) {
	if ($currentlocal{$_}) {
	    delete $currentlocal{$_};
	} else {
	    print ::getstr("Added to group:", "followed by a group name") . "$_<br>\n";
	    ::log("Addtogroup:$userid $_ $::adminschool");
	    $sth=$::dbh->prepare("insert into lglist (userid,school,localgroup) values ( '$userid', '$::adminschool', '$_' )");
	    $sth->execute;
	    MENUS::dbherr();
	    $change=1;
	}
    }

    ($change) && (print "<p>\n");

    my %gg;
    foreach ($::query->param('gg')) {
	if ($::flags{$_}) {
	    if (!($flags & $::flags{$_})) {
		$change=1;
		$sth=$::dbh->prepare("update users set flags=(flags | $::flags{$_}) where userid=$q_userid");
		$sth->execute;
		MENUS::dbherr();
	    }
	}
	unless ($gg{$_}) {
	    my $sth=$::dbh->prepare("select restricted from localgroups where shortname='$_'");
	    $sth->execute;
	    MENUS::dbherr();
	    $gg{$_}=($sth->fetchrow)[0];
	}
	if (($gg{$_} == 1) && (! ($::indomainadmin))) {
	    print "Denied access to $_<br>\n";
	    next;
	}
	if ($currentlocal{$_}) {
	    delete $currentlocal{$_};
	} else {
	    ::log("Addtogroup:$userid $_ $::adminschool");
	    print ::getstr("Added to group:", "followed by a group name") . "$_<br>\n";
	    $sth=$::dbh->prepare("insert into lglist (userid,school,localgroup) values ( '$userid', '$::adminschool', '$_' )");
	    $sth->execute;
	    MENUS::dbherr();
	    $change=1;
	}
    }

    foreach ( keys %currentlocal ) {
	unless ($gg{$_}) {
	    my $sth=$::dbh->prepare("select restricted from localgroups where shortname='$_'");
	    $sth->execute;
	    MENUS::dbherr();
	    $gg{$_}=($sth->fetchrow)[0];
	}
	if ($::flags{$_}) {
	    if ($flags & $::flags{$_}) {
		$change=1;
		my $allones=(2**32-1);
		my $notgroup=$allones-$::flags{$_};
		$sth=$::dbh->prepare("update users set flags=(flags & $notgroup) where userid=$q_userid");
		$sth->execute;
		MENUS::dbherr();
	    }
	}
	if ($gg{$_} == 1 && ! $::indomainadmin) {
	  next;
	}
	print ::getstr("Removed from group:", "followed by a group name") . "$_<br>\n";
	::log("Removefromgroup:$userid $_ $::adminschool");
	$daf=$::dbh->do("delete from lglist where userid='$userid' and school='$::adminschool' and localgroup='$_'");
	$change=1;
    }


    ($change) || (print ::getstr("No changes have been made.") . "<br>\n");
}



sub deleteschool {
    my (@users);
    my $school=$::query->param('deleteschool');
    my $q_school=$::dbh->quote($school);
    $sth=$::dbh->prepare("select count(*) from users,homeschools where users.userid=homeschools.userid and homeschools.school=$q_school");
    $sth->execute;
    my ($count) = $sth->fetchrow;
    if ($count > 0) {
	printf "<font color=red>" . ::getstr("Please remove all of the users from this school before deleting.  This is a precautionary measure to prevent accidental deletion of school accounts.  This school still has %d users in it.") . "</font><br>\n", $count;
	return;
    }
    ::log("DeleteSchool:$school");
    print ::getstr("Deleting") . " $school<br>\n";

    $sth=$::dbh->prepare("select id from schools where school=$q_school");
    $sth->execute;
    MENUS::dbherr();
    my ($id) = $sth->fetchrow;

    $sth=$::dbh->prepare("delete from servermap where school=$id");
    $sth->execute;
    MENUS::dbherr();

    $sth=$::dbh->prepare("delete from schools where school=$q_school");
    $sth->execute;
    MENUS::dbherr();
    
    $sth=$::dbh->prepare("delete from localgroups where school=$q_school");
    $sth->execute;
    MENUS::dbherr();

    $sth=$::dbh->prepare("delete from lglist where school=$q_school");
    $sth->execute;
    MENUS::dbherr();
}

sub renameschool {
    my $oldname=$::query->param('oldname');
    my $newname=$::query->param('newname');
    print ::getstr("Renaming School:") . "$oldname : $newname<br>\n";
    ::log("RenameSchool:$oldname,$newname");
    
    my $daf=$::dbh->prepare("select * from schools where longname='$newname'");
    $daf->execute;
    MENUS::dbherr();

    if ($daf->rows == 0) {
	my $q_longname=$::dbh->quote($newname);
	my $q_oldname=$::dbh->quote($oldname);
	$daf=$::dbh->prepare("update schools set longname=$q_longname where school=$q_oldname");
	$daf->execute;
	MENUS::dbherr();
    } else {
	print ::getstr("The new name chosen for the school is already being used.") . "<br>\n";
	return;
    }
}

sub moveuser {
    my $user=shift;
    my $school=shift;
    my $q_user=$::dbh->quote($user);
    my $q_school=$::dbh->quote($school);
    my $time=time();
    #my $sth=$::dbh->prepare("select school from homeschools where userid=$q_user");
    #$sth->execute;
    #MENUS::dbherr();
    my $movefrom=$::adminschool;
    my $sth=$::dbh->prepare("select school from homeschools where userid=$q_user and school=$::q_adminschool");
    $sth->execute;
    if ($sth->rows == 0) {
	if ($::indomainadmin) {
	    my $sti=$::dbh->prepare("select school from homeschools where
	    userid=$q_user");
	    $sti->execute;
	    ($movefrom) = $sti->fetchrow;
	} else {
	    print "What's going on?  $user isn't even in $::adminschool!!!<br>\n";
	    return;
	}
    }
    print "<center>$user has been moved from $movefrom to $school<br>\n";
    ::log("Moveuser:$user $movefrom $school");
    
    my $daf=$::dbh->prepare("select comment from users where userid=$q_user");
    $sth->execute;
    my ($comment) = $sth->fetchrow;
    my ($type) = (split($comment, /\s+/))[1];
    
    my $daf=$::dbh->prepare("update users set comment='$school $type' where userid=$q_user");
    $daf->execute;
    MENUS::dbherr();

    $daf=$::dbh->prepare("delete from lglist where userid=$q_user and school='$movefrom'");
    $daf->execute;
    MENUS::dbherr();

    $daf=$::dbh->prepare("insert into homeschools (school,userid) values ( $q_school, $q_user)");
    $daf->execute;
    MENUS::dbherr();

    $daf=$::dbh->prepare("delete from homeschools where school='$movefrom' and userid=$q_user");
    $daf->execute;
    MENUS::dbherr();

    $daf=$::dbh->prepare("select shortname from localgroups where school=$q_school and shortname='Incoming'");
    $daf->execute;
    MENUS::dbherr();

    if (! $daf->fetchrow) {
	$daf=$::dbh->prepare("insert into localgroups (school, shortname, longname) values ($q_school, 'Incoming', 'Incoming Users')");
	$daf->execute;
	MENUS::dbherr();
    }
    $daf=$::dbh->prepare("insert into lglist (userid,school,localgroup) values ($q_user, $q_school, 'Incoming')");
    $daf->execute;
    MENUS::dbherr();
}

sub mvuser {
  local ($user, $school, $type, $origschool, $pdc, $p, $origpdc, $mail, $file);
  $time=time();
  $user=$::query->param('mvuser');
  $school=$::query->param('muschool');
  $sth=$::dbh->prepare("select comment from users where userid='$user'");
  $sth->execute;
  MENUS::dbherr();
    
  while (($comment)=$sth->fetchrow) {
    if (($comment=~/Staff$/i) || ($comment=~/Student$/i)) {
      ($origschool, $type)=split(m#\s#,$comment);
    }
  }
  printf "<center><p>" . ::getstr("%s has been moved from %s to %s", "user has been moved from oldschool to newschool") . "<p>\n", $user, $origschool, $school;
  $param=$::dbh->quote("addgrp,$user,\"$school $type\",$p,");
  $daf=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', $param, '1', '' )");
  $daf->execute;
MENUS::dbherr();

    
  $daf=$::dbh->prepare("insert into groups values ( '$school $type', '$user' )");
  $daf->execute;
MENUS::dbherr();

    
  $param=$::dbh->quote("delgrp,$user,\"$origschool $type\",$p,");
  $daf=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', $param, '1', '' )");
  $daf->execute;
MENUS::dbherr();

    
  $daf=$::dbh->prepare("delete from groups where grp='$origschool $type' and member='$user'");
  $daf->execute;
MENUS::dbherr();

    
  $param=$::dbh->quote("modify,$user /comment:\"$school $type\",$p,");
  $daf=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', $param, '1', '' )");
  $daf->execute;
MENUS::dbherr();

    
  $daf=$::dbh->prepare("update users set comment='$school $type' where userid='$user'");
  $daf->execute;
MENUS::dbherr();

    
}

sub logout {
  $sth=$::dbh->prepare("update ActiveUsers set host='logged out',time='' where user='$::username'");
  $sth->execute;
MENUS::dbherr();

}


sub editsystem {
    if ($::indomainadmin) {
      my %systemoption;
	my @params=$::query->param;
	foreach (@params) {
	    if (m#systemoption(\d*)#) {
		my $optionnum=$1;
		$systemoption{$optionnum} = $::query->param($_);
	    }
	}

	$sth=$::dbh->prepare("select id, vieworder, type, shortname,longname,options,depends from systemconfigoptions order by vieworder");
	$sth->execute;
	my $b_i=-1;
	my $c_i=-1;
	while (my ($id, $order, $type, $shortname, $longname, $options, $depends) = $sth->fetchrow) {
	    if ($type eq 'BOOLEAN') {
		@options=split(/:/, $options);
		($systemoption{$id}) ? ($systemoption{$id}=1) : ($systemoption{$id}=0);
	    } elsif ($type eq 'CHOICE') {
		unless ($systemoption{$id}) {
		    $systemoption{$id} = (split(/:/, $options))[0];
		}
	    } elsif ($type eq 'TEXT') {
		unless ($systemoption{$id}) {
		    $systemoption{$id} = '';
		}
	    }
	    my $q_shortname=$::dbh->quote($shortname);
	    $sti=$::dbh->prepare("select optionvalue from systemconfig where optionname=$q_shortname");
	    $sti->execute;
	    my ($oldvalue) = $sti->fetchrow;
	    my $newvalue=$systemoption{$id};
	    if ($newvalue ne $oldvalue) {
		my $changeto=$newvalue;
		if ($type eq 'BOOLEAN') {
		    print ::getstr($options[$newvalue-1]) . "<br>\n";
		    ($newvalue) ? ($changeto='on') : ($changeto='off');
		} else {
		    print ::getstr("Change") . "  " . ::getstr($longname) . " ". ::getstr("to")." ".::getstr($changeto)."<br>\n";
		}
		::log("Serveroption:$servername $shortname $changeto");
		my $q_newvalue=$::dbh->quote($newvalue);
		my $q_servername=$::dbh->quote($servername);
		if ($sti->rows) {
		    $sti=$::dbh->prepare("update systemconfig set optionvalue=$q_newvalue where optionname=$q_shortname");
		} else {
		    $sti=$::dbh->prepare("insert into systemconfig (optionname,optionvalue) values ($q_shortname, $q_newvalue)");
		}
		$sti->execute;
	    }
	}
    }
}


sub editserver {
    if ($::indomainadmin) {
	my $serverid=$::query->param("serverid");
	my $sth=$::dbh->prepare("select name from schoolservers where id=$serverid");
	$sth->execute;
	my ($servername) = $sth->fetchrow;
	my $description=$::query->param("description");
	my @params=$::query->param;
	foreach (@params) {
	    if (/serveroption(\d*)/) {
		my $optionnum=$1;
		$serveroption{$optionnum} = $::query->param($_);
	    }
	    if (/serviceoption(\d*)/) {
		my $optionnum=$1;
		$serviceoption{$optionnum} = $::query->param($_);
	    }
	}

# If the SSH key has been compromised, then delete it.  A new one will need to
# be created on the client by running k12admin-client.setup

	if ($::query->param("deletesshkey")) {
	    $sth=$::dbh->prepare("update schoolservers set sshkey='' where id=$serverid");
	    $sth->execute;
	    MENUS::dbherr();
	}

	$sth=$::dbh->prepare("select id,type,name from services");
	$sth->execute;
	my %servicenames;
	while (my ($id, $type, $name) = $sth->fetchrow) {
	    $servicenames{$id}=$name;
	    if ($type eq 'BOOLEAN') {
		($serviceoption{$id}) ? ($serviceoption{$id}=1) : ($serviceoption{$id}=0);
	    }
	    my $q_name=$::dbh->quote($name);
	    $sti=$::dbh->prepare("select value from serviceconfig where schoolserver=$serverid and service=$q_name");
	    $sti->execute;
	    my ($oldvalue) = $sti->fetchrow;
	    my $newvalue=$serviceoption{$id};
	    if ($newvalue ne $oldvalue) {
		my $changeto=$newvalue;
		my $q_newvalue=$::dbh->quote($newvalue);
		($changeto) ? (print "Enabling the $q_name service.<br>\n") : (print "Disabling the $q_name service.<br>\n");
		if ($sti->rows) {
		    $sti=$::dbh->do("update serviceconfig set value=$q_newvalue where service=$q_name and schoolserver=$serverid");
		} else {
		    $sti=$::dbh->do("insert into serviceconfig (schoolserver,service,value) values ($serverid, $q_name, $q_newvalue)");
		}
	    }
	}
	$sth=$::dbh->prepare("select id, vieworder, type, shortname,longname,options,depends from serverconfigoptions order by vieworder");
	$sth->execute;
	my $b_i=-1;
	my $c_i=-1;
	while (my ($id, $order, $type, $shortname, $longname, $options, $depends) = $sth->fetchrow) {
	    if ($type eq 'BOOLEAN') {
		@options=split(/:/, $options);
		($serveroption{$id}) ? ($serveroption{$id}=1) : ($serveroption{$id}=0);
	    } elsif ($type eq 'CHOICE') {
		unless ($serveroption{$id}) {
		    $serveroption{$id} = (split(/:/, $options))[0];
		}
	    }
	    my $q_shortname=$::dbh->quote($shortname);
	    $sti=$::dbh->prepare("select optionvalue from serverconfig where schoolserver=$serverid and optionname=$q_shortname");
	    $sti->execute;
	    my ($oldvalue) = $sti->fetchrow;
	    my $newvalue=$serveroption{$id};
	    if ($newvalue ne $oldvalue) {
		my $changeto=$newvalue;
		if ($type eq 'BOOLEAN') {
		    print $options[$newvalue-1]."<br>\n";
		    ($newvalue) ? ($changeto='on') : ($changeto='off');
		} else {
		    print ::getstr("Change") . "  " . ::getstr($longname) . " ". ::getstr("to")." ".::getstr($changeto)."<br>\n";
		}
		::log("Serveroption:$servername $shortname $newvalue");
		my $q_newvalue=$::dbh->quote($newvalue);
		my $q_servername=$::dbh->quote($servername);
		if ($sti->rows) {
		    $sti=$::dbh->prepare("update serverconfig set optionvalue=$q_newvalue where optionname=$q_shortname and schoolserver=$serverid");
		} else {
		    $sti=$::dbh->prepare("insert into serverconfig (schoolserver,optionname,optionvalue) values ($serverid, $q_shortname, $q_newvalue)");
		}
		$sti->execute;
	    }
	}

	$sth=$::dbh->prepare("select id,longname from schools order by longname");
	$sth->execute;
	MENUS::dbherr();
	$attachedschools="<tr>\n";
	$i=-1;
	while (my ($schoolid, $longname) = $sth->fetchrow) {
	    if ($::query->param("School$schoolid")) {
		$attached{$schoolid}=1;
		printf ::getstr("Attached to %s", "This server has been attached to school %s") . "<br>\n", $longname;
		$sti=$::dbh->prepare("select * from servermap where server=$serverid and school=$schoolid");
		$sti->execute;
		MENUS::dbherr();
		unless ($sti->rows) {
		    $sti=$::dbh->prepare("insert into servermap (server,school) values ($serverid, $schoolid)");
		    $sti->execute;
		    MENUS::dbherr();
		}
	    } else {
		$attached{$schoolid}=0;
	    }
	}
	$sth=$::dbh->prepare("select servermap.school,schools.longname from servermap,schools where servermap.server=$serverid and schools.id=servermap.school");
	$sth->execute;
	MENUS::dbherr();
	while (my ($school, $longname) = $sth->fetchrow) {
	    unless ($attached{$school}) {
		printf ::getstr("Removing from %s", "The server will no longer use accounts from the %s school") . "<br>\n", $longname;
		$sti=$::dbh->prepare("delete from servermap where school=$school and server=$serverid");
		$sti->execute;
		MENUS::dbherr();
	    }
	}
	$q_description=$::dbh->quote($description);
	$sth=$::dbh->prepare("update schoolservers set description=$q_description where id=$serverid");
	$sth->execute;
	MENUS::dbherr();
    }
}

sub editschool {
    if ($::indomainadmin) {
	my $id=$::query->param("schoolid");
	my $longname=$::query->param("longname");
	printf ::getstr("Changing school's name to %s") . "<br>\n", $longname;
	my $q_longname=$::dbh->quote($longname);
	my $sth=$::dbh->prepare("update schools set longname=$q_longname where id=$id");
	$sth->execute;
	MENUS::dbherr();
	::log("Renameschool: $id $longname");
    }
}

sub addschool {
    if ($::indomainadmin) {
	my $school=$::query->param('newschool');
	my $longname=$::query->param('longname');
	$school=~s/[^A-Za-z0-9]//g;

	::log("Addschool:$school $longname");

	my $q_school=$::dbh->quote($school);
	my $q_longname=$::dbh->quote($longname);
	my $sth=$::dbh->prepare("insert into schools (school,longname) values ( $q_school, $q_longname )");
	$sth->execute;
	MENUS::dbherr();
    }
}


sub delacct {
    local(@student,@staff,$param,$time,%params,$task,$userid,$state);
    @staff=$::query->param('delstaff');
    @student=$::query->param('delstudent');
    foreach (@staff) {
	if ($_ eq 'demoteacher') {
	    print "<font color=red>Do not delete demoteacher account.</font><br>\n";
	    next;
	}
	::log("Deleteuser:$_");
	
	$sth=$::dbh->prepare("delete from lglist where userid='$_'");
	$sth->execute;
	MENUS::dbherr();

	$sth=$::dbh->prepare("delete from homeschools where userid='$_'");
	$sth->execute;
	MENUS::dbherr();

	$sth=$::dbh->prepare("delete from users where userid='$_'");
	$sth->execute;
	MENUS::dbherr();
    }
    foreach (@student) {
	::log("Deleteuser:$_");
	
	$sth=$::dbh->prepare("delete from lglist where userid='$_'");
	$sth->execute;
	MENUS::dbherr();

	$sth=$::dbh->prepare("delete from homeschools where userid='$_'");
	$sth->execute;
	MENUS::dbherr();

	$sth=$::dbh->prepare("delete from users where userid='$_'");
	$sth->execute;
	MENUS::dbherr();
    }
}

sub generateuserid {
    my ($first, $last) = @_;
    my $scheme = $::configs{'namescheme'};
    my $limit8 = $::configs{'limit8'};
    my $nametaken=0;
    my $i=1;
    my $j=1;
    $last=~tr/A-Z/a-z/;
    $last=~s/\W//g;
    $first=~tr/A-Z/a-z/;
    $first=~s/\W//g;
    ($scheme) || ($scheme = 'First Initial + Last Name');

    if ($scheme eq 'First Initial + Last Name') {
	my $id=substr($first,0,$i++).$last;
	if ($limit8) {
	    $id=substr($id, 0, 8);
	}
	my $stf=$::dbh->prepare("select userid from users where userid='$id'");
	$stf->execute;
	MENUS::dbherr();
	($stf->rows) && ($nametaken=1);
	$stf=$::dbh->prepare("select userid from systemusers where userid='$id'");
	$stf->execute();
	MENUS::dbherr();
	($stf->rows) && ($nametaken=1);
	while ($nametaken) {
	    if ($limit8) {
		if ($j>9) {
		    $id=substr($id,0,6).$j++;
		} else {
		    $id=substr($id,0,7).$j++;
	        }
	    } else {
		if ($i <= length($first)) {
		    $id=substr($first,0,$i++).$last;
		} else {
		    $id=substr($first,0,1).$last.$j++;
		}
	    }
	    $stf=$::dbh->prepare("select userid from users where userid='$id'");
	    $stf->execute;
	    MENUS::dbherr();
	    ($stf->rows) ? ($nametaken=1) : ($nametaken=0);
	}
	return $id;
    } elsif ($scheme eq 'First Name + Last Initial') {
	my $id=$first.substr($last,0,1);
	if ($limit8) {
	    $id=substr($id, 0, 8);
	}
	my $stf=$::dbh->prepare("select userid from users where userid='$id'");
	$stf->execute;
	MENUS::dbherr();
	($stf->rows) && ($nametaken=1);
	$stf=$::dbh->prepare("select userid from systemusers where userid='$id'");
	$stf->execute();
	MENUS::dbherr();
	($stf->rows) && ($nametaken=1);
	while ($nametaken) {
	    if ($limit8) {
		if ($j > 9) {
		    $id=substr($id,0,6).$j++;
		} else {
		    $id=substr($id,0,7).$j++;
		}
	    } else {
		$id=$first.substr($last,0,1).$j++;
	    }
	    $stf=$::dbh->prepare("select userid from users where userid='$id'");
	    $stf->execute;
	    MENUS::dbherr();
	    ($stf->rows) ? ($nametaken=1) : ($nametaken=0);
	}
	return $id;
    } elsif ($scheme eq 'numeric') {

# Not yet available.  Just reverts to first initial+last name I kind of doubt
# the usefulness of this option anyway.  I was just filling in space until
# other options are added.

	my $id=substr($first,0,$i++).$last;
	my $stf=$::dbh->prepare("select userid from users where userid='$id'");
	$stf->execute;
	MENUS::dbherr();
	($stf->rows) && ($nametaken=1);
	$stf=$::dbh->prepare("select userid from systemusers where userid='$id'");
	$stf->execute();
	MENUS::dbherr();
	($stf->rows) && ($nametaken=1);
	while ($nametaken) {
	  if ($i <= length($first)) {
	    $id=substr($first,0,$i++).$last;
	  } else {
	    $id=substr($first,0,1).$last.$j++;
	  }
	  $stf=$::dbh->prepare("select userid from users where userid='$id'");
	  $stf->execute;
	  MENUS::dbherr();
	  ($stf->rows) ? ($nametaken=1) : ($nametaken=0);
	}
	return $id;
    }
}

sub addmultiple {
  my (@addusers,$nametaken,$id,$first,$last,$password,%params,$param,$userid,$i,$j,$k,$type,$localgroup);
  @addusers=split(/\n/,$::query->param('multusers'));
  printf ::getstr("%d users added.") . "<p>\n", $#addusers+1;
  $type='';
  foreach (@addusers) {
    s/^\s+//g;
    ($first,$last,$password,$userid)=split(/\s+|\s*,\s*/);
    if (($first eq '') && ($last eq '')) {
	next;
    }
    my $id=&generateuserid($first, $last);
    if (($::query->param('defaultpass')) && (! $password)) { $password=$::query->param('defaultpass'); }
    if (! $password) { $password=ACTIONS::randpass(); }
    until (length($password)>5) {
	if ($passlengthcheck==0) {
	    print "<font color=red>" . ::getstr("Some passwords were too short.  The number zero (0) has been added to the end of the passwords to bring the password length up to six characters.  For example, a password of 'short' would be changed to 'short0'") . "</font><p>\n";
	    $passlengthcheck=1;
	}
	$password.='0';
    }
    $q_fullname=$::dbh->quote("$last $first");
    $pt=$::dbh->quote($password);
    my $flags=0;
    my $type='';
    foreach ($::query->param('gg')) {
	($type='Staff') if ($_ eq 'staff');
	if ($::flags{$_}) {
	    $flags=$flags|$::flags{$_};
	}
    }
    ($type eq 'Staff') || ($type='Student');
    ::log("Adduser:$id $password $first $last $type $::adminschool");
    $sth=$::dbh->prepare("insert into homeschools (userid,school) values ('$id', '$::adminschool')");
    $sth->execute;
    $cryptpass=$::dbh->quote(&crypt($password));
    if ($::configs{'noplaintextpasswords'}) {
	$pt="''";
    }
    $sth=$::dbh->prepare("insert into users (userid, fullname,comment,shell,password,pt,flags) values ( '$id', $q_fullname,  '$::adminschool $type', '/bin/bash', $cryptpass, $pt, $flags)");
    $sth->execute;
    MENUS::dbherr();

    foreach ($::query->param('lg')) {
	::log("Addtogroup:$id $_ $::adminschool");
	$sth=$::dbh->prepare("insert into lglist (userid,school,localgroup) values ( '$id', '$::adminschool', '$_' )");
	$sth->execute;
	MENUS::dbherr();
    }

    my %gg;
    foreach $_ ($::query->param('gg')) {

# Restricted field is used to limit access to that group to domain admins only

	unless ($gg{$_}) {
	    my $sth=$::dbh->prepare("select restricted from localgroups where shortname='$_'");
	    $sth->execute;
	    MENUS::dbherr();
	    $gg{$_}=($sth->fetchrow)[0];
	}
	if ($gg{$_} == 1 && ! $::indomainadmin) {
# Whoops. You can't edit this group.
	    next;
	}
	::log("Addtogroup:$id $_ $::adminschool");
	$sth=$::dbh->prepare("insert into lglist (userid,school,localgroup) values ( '$id', '$::adminschool', '$_' )");
	$sth->execute;
	MENUS::dbherr();
    }
  }
}

sub crypt {
  local ($pass, $letters, $salt, $l, $c);
  ($pass)=@_;
  $letters='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  $l=length($letters);
  $salt=substr($letters, rand($l), 1).substr($letters, rand($l), 1);
  $c=crypt($pass, $salt);
  return ($c);
}

sub randpass {
  local ($_, $w1, $w2, $num);
  if ($#words == -1) {
    srand(time);
    open (T, "words");
    while (<T>) {
      chop;
      push (@words, $_);
    }
  }
  $w1=$words[int(rand($#words))];
  $w2=$words[int(rand($#words))];
  $num=int(rand(10));
  $pass=$w1.$num.$w2;
  return ($pass);
}

sub listrequests {
    my $i=0;
    if ($::query->param('listtype') eq 'time') {
	my $mult=0;
	if ($::query->param('units')=~/hours/) { $mult=3600; }
	if ($::query->param('units')=~/days/) { $mult=24*3600; }
	if ($::query->param('units')=~/weeks/) { $mult=7*24*3600; }
	::log("ListAccounts:Going back ".$::query->param('backhowfar')." ".$::query->param('units'));
	my $back=$::query->param('backhowfar')*$mult;
	my $time=time()-$back;
	my $sth=$::dbh->prepare("select activity from log where user='$::username' and time>'$time' and activity like 'Adduser:%'");
	$sth->execute;
	MENUS::dbherr();
	print "<center>\n<table border=1 cellpadding=14>\n";
	print "<tr>";
	while (my ($activity)=$sth->fetchrow) {
	    $activity=~s/^Adduser://;
	    my ($userid,$password,$first,$last,$type,$school)=split(m#\s#,$activity);
	    if ($i++>2) {
		$i=0;
		my $text="<td align=center>$first $last<br>".$::longnames{$school}." $type<br>" . ::getstr("Userid") . ": $userid<br>" . ::getstr("Password") . ": $password</td>\n";
		print $text;
		print "</tr>\n<tr>";
	    } else {
		my $text="<td align=center>$first $last<br>".$::longnames{$school}." $type<br>" . ::getstr("Userid") . ": $userid<br>" . ::getstr("Password") . ": $password</td>\n";
		print $text;
	    }
	}
    } else {
	my $lg=$::query->param('localgroup');
	::log("ListAccounts:Members of $lg");
	my $sth=$::dbh->prepare("select longname from localgroups where school='$::adminschool' and shortname='$lg'");
	$sth->execute;
	MENUS::dbherr();
	my ($localgroup)=$sth->fetchrow;
	$sth=$::dbh->prepare("select lglist.userid,users.pt,users.fullname from users,lglist where users.userid=lglist.userid and lglist.localgroup='$lg' and school='$::adminschool' order by users.fullname");
	$sth->execute;
	MENUS::dbherr();
	printf "<center>\n<h1>" . ::getstr("Members of %s at %s", "ie. Members of Web Users at Demo Secondary") . "</h1>\n", $localgroup, $::adminschool;
	print "<table border=1 cellpadding=14>\n";
	print "<tr>";
	while (my ($userid,$password, $fullname) = $sth->fetchrow) {
	    my $q_userid=$::dbh->quote($userid);
	    my $sti=$::dbh->prepare("select localgroup from lglist where userid=$q_userid and localgroup='staff'");
	    $sti->execute;
	    MENUS::dbherr();
	    ($sti->rows) ? ($type=::getstr('Staff')) : ($type=::getstr('Student'));
	    ($password='*******') if ($type eq ::getstr('Staff'));
	    my ($last, $first) = split(/\s+/, $fullname);
	    print "<td align=center>$first $last<br>$::longnames{$::adminschool} $type<br>" . ::getstr("Userid") . ": $userid<br>" . ::getstr("Password") . ": $password</td>\n";
	    if ($i++>2) {
		$i=0;
		print "</tr>\n<tr>\n";
	    }
	}
    }
    print "</tr>\n</table>\n";
}
  
  


1;
