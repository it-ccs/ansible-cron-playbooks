#!/usr/bin/perl


package MENUS;

#
# $Id: menus.pl,v 1.5 1998/07/06 16:10:09 tonnesen Exp $
#
# $Log: menus.pl,v $
# Revision 1.5  1998/07/06 16:10:09  tonnesen
# Beginning to add localgroup functions.
#
# Revision 1.1  1998/07/06 16:02:18  tonnesen
# Initial revision
#
# Revision 1.4  1998/05/23 16:22:37  tonnesen
# Modified squidlog subroutine to show list of users first, rather than a
# list of hosts.  Now only shows potential abuses.
#
# Revision 1.3  1998/05/11 15:51:29  tonnesen
# Added a missing closing bracket.  Promise to verify that programs work before
# committing next time.  :)
#
# Revision 1.2  1998/05/11 15:49:12  tonnesen
# Removed the "dialin" and "time restriction" options from the "Add Users" menu
# for non "domain admins".
#
# Revision 1.1.1.1  1998/05/09 16:11:03  tonnesen
# Web Administration
#
#

sub test {
    my $frame=$::query->param('frame');
    unless ($frame) {
	print << "EOF";
    <FRAMESET ROWS="10%,90%">
	<FRAME SRC=users.pl?menuitem=test&frame=top&adminschool=$::adminschool NAME="menu">
	<FRAME SRC=users.pl?menuitem=test&frame=bottom&adminschool=$::adminschool NAME="output">
    </FRAMESET>
EOF
	return;
    }
    if ($frame eq 'top') {
	print << "EOF";
	<a href=/ onClick='return top.menu.CreateAccounts()'>Create Users</a> | 
	<a href=/ onClick='return top.menu.DeleteAccounts(0)'>Delete Users</a> | 
	<a href=/ onClick='return top.menu.ModifyAccounts(0)'>Modify Users</a> | 
	<a href=/ onClick='return top.menu.GroupLists()'>Modify Group Lists</a> | 
	<a href=/ onClick='return top.menu.Search()'>Search</a> | 
	<a href=/ onClick='return top.menu.Changes()'>List Changes</a> |
	<a href=/ onClick='return top.menu.Submit()'>Submit Changes</a>
EOF
	return;
    }
    print "SCHOOL: $::q_adminschool\n";
    print "After the top frame has completed loading, press the START button to begin.<br>\n";
} 

sub translate {
    my $param="select id,english,hint,$::lang from strings order by $::lang,english";
    my $sth=$::dbh->prepare($param);
    $sth->execute;
    MENUS::dbherr();
    my $trans_string='';
    while (my ($id, $english, $hint, $translation) = $sth->fetchrow) {
	if ($hint) {
	    $trans_string.="<tr><td>$english<br><font color=red>$hint</font></td><td><input name='translation$id' size=50 value=\"$translation\"></td></tr>\n";
	} else {
	    $trans_string.="<tr><td>$english</td><td><input name='translation$id' size=50 value=\"$translation\"></td></tr>\n";
	}
    }
    my $submittranslations_str=::getstr("Submit Translations");
    my $localizing_str=::getstr("Localizing Text Database");
    my $translationfor_str=::getstr("Translation for");
    print <<"EOF";
    <center>
    <form method=post>
    <input type=hidden name=menuitem value=translate>
    <input type=hidden name=action value=translate>
    <table cellpadding=0 cellspacing=0>
    <tr><th colspan=2>$localizing_str</th></tr>
    <tr><th>English</th><th>$translationfor_str $::lang</th></tr>
    $trans_string
    </table>
    <input type=submit value="$submittranslations_str">
    </form>
    <p>
EOF
}

sub searchuser {
    my $searchuser=$::query->param('searchuser');
    my $searchschool=$::query->param('searchschool');
    my $searchforuser_str=::getstr("Search For A User");
    my $name_str=::getstr("Name");
    my $school_str=::getstr("School");
    my $enterpartialuseridorfullname_str=::getstr("Enter Partial Userid or Fullname");
    print << "EOF";
    <center>
    <FORM action=users.pl method=post>
    <input type=hidden name=menuitem value=searchuser>
    <input  type=hidden name=userid value=$::username>
    <input type=hidden name=adminschool value=$::adminschool>
    <table border=1>
    <tr><th colspan=2>$searchforuser_str
    <tr><td>$name_str: <input name=searchuser><br>
    $school_str: <select name=searchschool><option value=AllSchools>All Schools$::schoollist</select><br>
    <Center>
    $enterpartialuseridorfullname_str<br>
    </table>
    <p>
    <input type=submit value="$searchforuser_str">
    </form>
    <p>
EOF
  if ($searchuser) {
      ::log("Search:$searchuser");
      $searchuser=~tr/A-Z/a-z/;
      my $useridslike_str=::getstr("Userids like");
      if ($::indomainadmin) {
	  print "<p><hr><table border=1><tr><th colspan=4>$useridslike_str '$searchuser' ($::longnames{$searchschool})\n";
      } else {
	  print "<p><hr><table border=1><tr><th colspan=3>$useridslike_str '$searchuser' ($::longnames{$searchschool})\n";
      }
      my $sth;
      if ($searchschool eq 'AllSchools') {
	  $sth=$::dbh->prepare("select users.userid,users.fullname,homeschools.school from users,homeschools where users.userid=homeschools.userid and (users.userid like '%$searchuser%' or users.fullname like '%$searchuser%')");
      } else {
	  my $q_searchschool=$::dbh->quote($searchschool);
	  $sth=$::dbh->prepare("select users.userid,users.fullname,homeschools.school from users,homeschools where users.userid=homeschools.userid and (users.userid like '%$searchuser%' or users.fullname like '%$searchuser%') and homeschools.school=$q_searchschool");
      }
      $sth->execute;
      MENUS::dbherr();
      while (($u, $fullname, $school)=$sth->fetchrow) {
	  my $movecol='';
	  if ($::indomainadmin) {
	      $movecol="<td><a href=users.pl?menuitem=moveuser&moveuser=$u>Move User</a></td>";
	  }
	  print "<tr><td>$u</td><td>$fullname</td><td>$::longnames{$school}</td>$movecol</tr>\n";
      }
      print "</table>\n";
  }
}

# Subroutine for modifying individual accounts

sub modify {
    my $account;
    if ($account=$::query->param('a')) {
	my $q_account=$::dbh->quote($account);
        my $sth=$::dbh->prepare("select userid,fullname,comment from users where userid=$q_account");
	$sth->execute;
	MENUS::dbherr();
        my ($userid,$fullname,$comment)=$sth->fetchrow;
	$sth=$::dbh->prepare("select localgroup from lglist where school=$::q_adminschool and userid='$userid'");
	$sth->execute;
	MENUS::dbherr();
	my %lgs;
	while (my ($lg)=$sth->fetchrow) {
	    $lgs{$lg}=1;
	}
	my $lglist='';
	$sth=$::dbh->prepare("select shortname,longname from localgroups where school=$::q_adminschool order by vieworder,longname");
	$sth->execute;
	MENUS::dbherr();
	while (my ($short, $long)=$sth->fetchrow) {
	    my $checked='';
	    ($lgs{$short}) && ($checked='checked');
	    $lglist.="<input type=checkbox name=lg value=$short $checked>
	    $long<br>\n";
	}
	($lglist) || ($lglist=::getstr("No Local Groups Defined"));
	if ($::indomainadmin) {
	    $sth=$::dbh->prepare("select shortname,longname from localgroups
	    where school='global'  order by vieworder,longname");
	} else {
	    $sth=$::dbh->prepare("select shortname,longname from localgroups
	    where school='global'  and restricted !=1 order by
	    vieworder,longname");
	}
	$sth->execute;
	MENUS::dbherr();
	my $gglist='';
	while (my ($short, $long)=$sth->fetchrow) {
	    my $checked='';
	    ($lgs{$short}) && ($checked='checked');
	    $gglist.="<input type=checkbox name=gg value=$short $checked> $long<br>\n";
	}
	($gglist) || ($gglist=::getstr("No Global Groups Defined"));


# Get home school and type (staff/student)
# Still need to deal with users in multiple schools somehow.


	$sth=$::dbh->prepare("select localgroup from lglist where userid=$q_account and school=$::q_adminschool and localgroup='staff'");
	$sth->execute;
	MENUS::dbherr();
	($sth->rows) ? ($type='Staff') : ($type='Student');

	$sth=$::dbh->prepare("select school from homeschools where userid=$q_account");
	$sth->execute;
	MENUS::dbherr();
	my ($school) = $sth->fetchrow;

# Verify that administrator has rights in this school and over staff acounts

	if ($::admins{$::username}!~/$school,/) {
	    print "USERNAME: $::username<br>ADMINS: $::admins{$::username}<br>SCHOOL:
	    $school<br>\n";
	    print "ERRRORRRRR!!!!!!<br>\n";
	    print "This abuse has been logged<br>\n";
	    print "USERID: $userid<br>\n";
	    return;
	}


	$modifying_str=::getstr("Modifying");
	$fullname_str=::getstr("Full Name");
	$password_str=::getstr("Password");
	$confirmpassword_str=::getstr("Confirm Password");
	$leaveblank_str=::getstr("Leave password fields blank to not change password");
	$modifyaccount_str=::getstr("Modify Account");
	$localgroups_str=::getstr("Local Groups");
	$globalgroups_str=::getstr("Global Groups");
	$closewindow_str=::getstr("Close This Window and return to the list of accounts");
	print << "EOF";
        <hr><a href="/" onClick="return goOpener(this,true,true)">$closewindow_str</a><hr>
	<center>
	<form method=post>
	<input type=hidden name=adminschool value=$::adminschool>
	<input type=hidden name=action value=modify>
	<input type=hidden name=menuitem value=skip2>
	<input type=hidden name=account value=$userid>
	<table border=1>
	<tr><th colspan=2>$modifying_str $userid</th></tr>
	<tr>
	<td valign=top>
	<table>
	<tr><td>$fullname_str:</td><td><input size=20 name=fullname value="$fullname"></td>
	</tr>
	<tr>
	<!-- <td colspan=2 align=center>
	<table border=0> -->
	<tr><td>$password_str:</td><td><input type=password size=10 name=password1></td></tr>
	<tr><td>$confirmpassword_str:</td><td><input type=password size=10 name=password2></td></tr>
	<tr><td colspan=2><font size=-1>$leaveblank_str</font></td></tr>
	<!-- </table> -->
	</td></tr>
	<tr><td colspan=2 align=center><input type=submit value="$modifyaccount_str"></td></tr>
	</table>
	</td>
	<td valign=top>
	    <table>
	    <tr><td valign=top>
	    <center>
	    $globalgroups_str</center><hr>$gglist
	    </td><td valign=top>
	    <center>
	    $localgroups_str</center><hr>$lglist
	    </td></tr>
	    </table>
	</td></tr>
	</table>
	</form>
	<p>
EOF

    } else {
	my @staff;
	print "<h1>" . ::getstr("Modify Accounts") . "</h1><center>\n";
	print "<table border=1><tr><th colspan=3>" . ::getstr("Staff Accounts at") . " $::adminschool</th></tr><tr><td valign=top>\n";
	my $sth=$::dbh->prepare("select users.userid,users.fullname from users,homeschools where users.userid=homeschools.userid and homeschools.school=$::q_adminschool and (users.flags&$::flags{'staff'}) order by fullname");
	$sth->execute;
	MENUS::dbherr();
	$n=$sth->rows;
	$break=int(($n+2)/3);
	$i=0;
	while (($userid,$fullname)=($sth->fetchrow)) {
	    my ($last, $first)=split(/\s+/, $fullname);
	    $fullname="$last, $first";
	    $staff{$userid}=1;
	    if ($i == $break) {
		$i=0;
		print "</td>\n<td valign=top>\n";
	    }
	    $i++;
	    print "<a href=users.pl?menuitem=modify&a=$userid&adminschool=$::adminschool onClick=\"openWindow(this,'ModifyUser',460,630)\">$fullname</a><br>\n";
	}
	print "</tr></table>\n";
	
	print "<p><table border=1><tr><th colspan=3>" . ::getstr("Student Accounts at") . " $::adminschool</th></tr><tr><td valign=top>\n";
	$sth=$::dbh->prepare("select users.userid,users.fullname from users,homeschools where users.userid=homeschools.userid and homeschools.school=$::q_adminschool and !(users.flags&$::flags{'staff'}) order by fullname");
	$sth->execute;
	MENUS::dbherr();
	$n=$sth->rows;
	$break=int(($n+2)/3);
	$i=0;
	while (($userid,$fullname)=($sth->fetchrow)) {
	    my ($last, $first)=split(/\s+/, $fullname);
	    $fullname="$last, $first";
	    if ($i==$break) {
		$i=0;
		print "</td>\n<td valign=top>\n";
	    }
	    $i++;
	    print "<a href=users.pl?menuitem=modify&a=$userid&adminschool=$::adminschool onClick=\"openWindow(this,'ModifyUser',460,630)\">$fullname</a><br>\n";
	}
	print "</tr></table>\n";
	print <<"EOF";
	<p>
EOF
    }
}

# Subroutine for modifying group memberships.  Deprecated by sub localgroups.
# This subroutine is called by the page created by the grouplists subroutine.

sub modifygroups {
    my ($lg,$sth,$userid,$fullname,%stafflist,%studentlist);
    my $stafflistin=$studentlistin=$stafflistout=$studentlistout='';
    $lg=$::query->param('modifygroup');

    $sth=$::dbh->prepare("select userid from lglist where localgroup='$lg' and school='$::adminschool'");
    $sth->execute;
    MENUS::dbherr();
    while (($userid)=$sth->fetchrow) {
	$members{$userid}=1;
    }

    $sth=$::dbh->prepare("select userid,fullname from users where comment='$::adminschool Staff' order by fullname");
    $sth->execute;
    MENUS::dbherr();
    while (($userid,$fullname)=$sth->fetchrow) {
	if ($members{$userid}) {
	    $stafflistin.="<option value=$userid>$fullname\n";
	} else {
	    $stafflistout.="<option value=$userid>$fullname\n";
	}
    }
    $sth=$::dbh->prepare("select userid,fullname from users where comment='$::adminschool Student' order by fullname");
    $sth->execute;
    MENUS::dbherr();
    while (($userid,$fullname)=$sth->fetchrow) {
	if ($members{$userid}) {
	    $studentlistin.="<option value=$userid>$fullname\n";
	} else {
	    $studentlistout.="<option value=$userid>$fullname\n";
	}
    }

    my $removefromgroup_str=::getstr("Remove From Group");
    my $addtogroup_str=::getstr("Add To Group");
    my $students_str=::getstr("Students");
    my $staff_str=::getstr("Staff");
    my $modifygroup_str=::getstr("Modify Group");
    print <<"EOF";
    <center>
    <form method=post action=users.pl>
    <input type=hidden name=action value=modifygroups>
    <input type=hidden name=menuitem value=grouplists>
    <input type=hidden name=adminschool value=$::adminschool>
    <input type=hidden name=modifygroup value=$lg>
    <table border=1 cellpadding=10>
    <tr><td>
    <table border=1>
    <tr><th colspan=2>$removefromgroup_str ($lg)</th></tr>
    <tr><th>$staff_str</th><th>$students_str</th></tr>
    <tr><td align=center>
    <select name=staffremove multiple size=10>$stafflistin</select>
    </td><td align=center>
    <select name=studentremove multiple size=10>$studentlistin</select>
    </td></tr>
    </table>
    </td><td>
    <table border=1>
    <tr><th colspan=2>$addtogroup_str ($lg)</th></tr>
    <tr><th>$staff_str</th><th>$students_str</th></tr>
    <tr><td align=center>
    <select name=staffadd multiple size=10>$stafflistout</select>
    </td><td align=center>
    <select name=studentadd multiple size=10>$studentlistout</select>
    </td></tr>
    </table>
    </td></tr>
    </table>
    <input type=submit value="$modifygroup_str">
    </form>

EOF



}

# Deprecated group membership editing.  Replaced by sub localgroups (which
# requires javascript and more testing.

sub grouplists {
    my $localgrouplist='';
    $st=$::dbh->prepare("select shortname,longname from localgroups where school=".$::dbh->quote($::adminschool)." order by longname");
    $st->execute;
    MENUS::dbherr();
    while (($short, $long)=$st->fetchrow) {
	$localgrouplist.="<option value=$short>$long\n";
    }

    if ($::indomainadmin) {
	$st=$::dbh->prepare("select shortname,longname from localgroups where school='global'  order by longname");
    } else {
	$st=$::dbh->prepare("select shortname,longname from localgroups where school='global'  and restricted !=1 order by longname");
    }
    $st->execute;
    MENUS::dbherr();
    while (($short, $long)=$st->fetchrow) {
	$localgrouplist.="<option value=$short>$long\n";
    }
    print <<"EOF";
    <center>
    $::adminschool
    <form action=users.pl method=post>
    <input type=hidden name=menuitem value=modifygroups>
    <input type=hidden name=adminschool value=$::adminschool>
    <table border=1>
    <tr><th>Group Membership Lists</th></tr>
    <tr><td align=center>
    <select name=modifygroup>$localgrouplist</select><br>
    <input type=submit value="Show Member List">
    </td>
    </tr>
    </table>
    </form>
    <p>
EOF

}


# First javascript heavy subroutine.  Works well with netscape 4 or IE 4
# clients, might need work to be more portable.  Needs to use a "textarea" for
# submitting data back to improve performance.

sub localgroups {
    my $localgroups_str=::getstr("Local Groups");
    my $functions_str=::getstr("Functions");
    my $addlocalgroups_str=::getstr("Add Local Groups");
    my $deletegroups_str=::getstr("Delete Selected Groups");
    my $moveup_str=::getstr("Move Up");
    my $movedown_str=::getstr("Move Down");
    my $submitchanges_str=::getstr("Submit Changes");
    my $modifygroupmembership_str=::getstr("Modify Group Membership");
    my $selectall_str=::getstr("Select All");
    my $selectnone_str=::getstr("Select None");
    my $addtoleft_str=::getstr("Add To Left Group");
    my $removefromleft_str=::getstr("Remove From Left Group");
    print <<"EOFFRM";
    <center>
    $::adminschool
    <FORM action=users.pl method=post name=localgroups onLoad=redraw()>
    <table border=1 cellpadding=8>
    <tr><th>$localgroups_str</th><th>$functions_str</th></tr>
    <tr align=center><td>
    <input type=hidden name=action value=localgroups>
    <input type=hidden name=adminschool value=$::adminschool>
    <select name=grouplist multiple width=50 size=15>
    <option value=blank>Long Blank Option Inserted Here
    </select><br>
    </td>
    <td>
    
    <input type=button value="$addlocalgroups_str" onClick=addlocalgroup()><p>
    <input type=button value="$deletegroups_str" onClick=deletelocalgroups()>
    <hr>
    <input type=button value="$moveup_str" onClick=moveup()><p>
    <input type=button value="$movedown_str" onClick=movedown()>
    <hr>
    <input type=button value="$submitchanges_str" onClick=submitChanges()>
    </td>

    </tr></table>
    </form>
    <p>
<form method=post name=editgroups>
<table border=1>
<tr>
<th colspan=2>
$modifygroupmembership_str
</th>
<tr>
<tr>
<th align=left>
<select name=leftgroup onChange="showMembers()">
<option value=blank>No Group Selected
</select>
</th>
<th align=left>
<select name=rightgroup onChange="showMembers()">
<option value=blank>No Group Selected
</select>
</th>
</tr>
<tr>
<td align=center>
<select name=members multiple size=10>
<option value=blank>Full Name of User xxxxxxxxxxxxxxx (userid)
</select>
</td>
<td align=center>
<select name=nonmembers multiple size=10>
<option value=blank>Full Name of User xxxxxxxxxxxxxxxx (userid)
</select>
</td>
</tr>
<tr>
<td align=center>
<input type=button value="$selectall_str" onClick=selectAllMembers(true)>
<input type=button value="$selectnone_str" onClick=selectAllMembers(false)>
<br>
<input name=removebutton type=button value="$removefromleft_str" onClick="removefromgroup()"><p>
<td align=center>
<input type=button value="$selectall_str" onClick=selectAllNonmembers(true)>
<input type=button value="$selectnone_str" onClick=selectAllNonmembers(false)>
<br>
<input name=addbutton type=button value="$addtoleft_str" onClick="addtogroup()"><p>
</td>
</tr>
</table>
<br>
<input type=button value="$submitchanges_str" onClick=submitChanges()>
<p>
</form>

    <p>
    <p>
    <form name=submitdata method=post>
    <input type=hidden name=action value=localgroups>
    <input type=hidden name=adminschool value=$::adminschool>
    <textarea name=returndata rows=1 cols=30>
    </textarea>
    </form>
EOFFRM
}


# Pretty Self-explanatory.  Deletes a school.

sub deleteschool {
    my $deletethisschool_str=::getstr("Delete this school");
    my $school_str=::getstr("School");
    print <<"EOFFRM";
    <center>
    <FORM action=users.pl method=post>
    <input type=hidden name=menuitem value=deleteschool>
    <input type=hidden name=action value=deleteschool>
    <input type=hidden name=adminschool value=$::adminschool>
    $school_str: <select name=deleteschool>$::schoollist</select><br>
    <input type=submit value="$deletethisschool_str">
    </form>
EOFFRM
}


# Rename a school.  This subroutine is deprecated.  Replaced by sub
# editschool.

sub renameschool {
    my $oldname_str=::getstr("Old Name");
    my $newname_str=::getstr("New Name");
    my $renameschool_str=::getstr("Rename School");
    print <<"EOFFRM";
    <center>
    <FORM action=users.pl method=post>
    <input type=hidden name=menuitem value=renameschool>
    <input type=hidden name=action value=renameschool>
    <input type=hidden name=adminschool value=$::adminschool>
    $oldname_str: <select name=oldname>$::schoollist</select><br>
    $newname_str: <input name=newname size=20><br>
    <input type=submit value="$renameschool_str">
    </form>
EOFFRM
}



# Proxy log browser.  Allows school admins to browse student browsing records.

sub squidlog {
  my ($user, $host, $text, $sth);
  $user=$::query->param('squidloguser');
  $host=$::query->param('squidloghost');
  if ($user) {
    if ($host) {
      $sth=$::dbh->prepare("select distinct squidlog.url from squidlog,users where squidlog.user='$user' and squidlog.host='$host' and squidlog.user=users.userid and users.comment='$::adminschool student'");
      $sth->execute;
      MENUS::dbherr();
      while (my $url=($sth->fetchrow)[0]) {
	$text.="<li><a href=$url>$url</a>\n";
      }
      my $clickonurl_str=::getstr("Click on a URL to visit that site.");
      my $pagesfrom_str=::getstr("Pages from");
      my $visitedby_str=::getstr("visited by");
      print << "EOF";
      <center>
      <h1>$clickonurl_str</h1>
      <hr>
      $pagesfrom_str $host $visitedby_str $user
      <hr>
      $text
      </ul>
      <p>
EOF
    } else {
      $sth=$::dbh->prepare("select distinct host from squidlog where user='$user'");
      $sth->execute;
      MENUS::dbherr();
      while (my $host=($sth->fetchrow)[0]) {
	$text.="<option value=$host>$host\n";
      }
      my $selectahost_str=::getstr("Select a Host");
      my $listofhostsbrowsed_str=::getstr("List of hosts browsed by");
      my $listdocumentsbrowsed_str=::getstr("List Documents Browsed");
      print << "EOF";
      <center>
      <h1>$selectahost_str</h1>
      <hr>
      $listofhostsbrowsed_str $user
      <hr>
      <form method=post action=users.pl>
      <input type=hidden name=menuitem value=squidlog>
      <input type=hidden name=adminschool value=$::adminschool>
      <input type=hidden name=squidloguser value=$user>
      <select size=10 name=squidloghost>
      $text
      </select>
      <p>
      <input type=submit value="$listdocumentsbrowsed_str">
      </form>
EOF
    }
  } else {
    $sth=$::dbh->prepare("select distinct squidlog.user from squidlog,users where squidlog.user=users.userid and users.comment='$::adminschool student'");
    $sth->execute;
    MENUS::dbherr();
    if ($sth->rows) {
	while (my $user=($sth->fetchrow)[0]) {
	  $sti=$::dbh->prepare("select fullname from users where userid='$user'");
	  $sti->execute;
	  MENUS::dbherr();
	  my ($fullname)=$sti->fetchrow;
	  $text.="<option value=$user>$fullname ($user)\n";
	}
    } else {
	$text="<option value=''>" . ::getstr("No inappropriate use") . "\n";
    }
    my $selectauser_str=::getstr("Select a User");
    print << "EOF";
    <center>
    <h1>$selectauser_str</h1>
    <form method=post action=users.pl>
    <input type=hidden name=menuitem value=squidlog>
    <input type=hidden name=adminschool value=$::adminschool>
    <select size=10 name=squidloguser>
    $text
    </select>
    <p>
    <input type=submit value="List Sites Browsed by This User">
    </form>
EOF
  }
}


# Work in progress.  Edit attributes of individual servers.

sub editserver {
    if ($::indomainadmin) {
	if (my $schoolserver=$::query->param("schoolserver")) {
	  $sth=$::dbh->prepare("select name,description from schoolservers where id=$schoolserver");
	  $sth->execute;
	  MENUS::dbherr();
	  my ($name, $description) = $sth->fetchrow;

	  $sth=$::dbh->prepare("select school from servermap where server=$schoolserver");
	  $sth->execute;
	  MENUS::dbherr();
	  while (my ($school) = $sth->fetchrow) {
	      $schoolmap{$school}=1;
	  }


	  $sth=$::dbh->prepare("select id,longname from schools order by longname");
	  $sth->execute;
	  MENUS::dbherr();
	  $attachedschools="<tr>\n";
	  my $i=-1;
	  while (my ($id, $longname) = $sth->fetchrow) {
	      ($schoolmap{$id}) ? ($checked="checked") : ($checked='');
	      if ($i++ == 2) {
		  $i=0;
		  $attachedschools.="</tr>\n<tr>\n<td><input type=checkbox name=School$id $checked> $longname</td>\n";
	      } else {
		  $attachedschools.="<td><input type=checkbox name=School$id $checked> $longname</td>\n";
	      }
	  }

	  my $q_schoolserver=$::dbh->quote($schoolserver);
	  my $booleanconfigtext="<table border=1>\n<tr>\n";
	  my $choiceconfigtext='';
	  $sth=$::dbh->prepare("select id, vieworder, type, shortname,longname,options from serverconfigoptions order by vieworder");
	  $sth->execute;
	  my $b_i=-1;
	  my $c_i=-1;
	  while (my ($id, $order, $type, $shortname, $longname, $options) = $sth->fetchrow) {
	      my $q_shortname=$::dbh->quote($shortname);
	      if ($type eq 'BOOLEAN') {
		  if ($b_i++ == 3) {
		      $b_i=0;
		      $booleanconfigtext.="</tr>\n<tr>\n<td>\n";
		  } else {
		      $booleanconfigtext.="<td>\n";
		  }
		  $sti=$::dbh->prepare("select optionvalue from serverconfig where schoolserver=$q_schoolserver and optionname=$q_shortname");
		  $sti->execute;
		  MENUS::dbherr();
		  my ($value) = $sti->fetchrow;
		  ($value) ? ($checked='checked') : ($checked='');
		  $booleanconfigtext.="<input type=checkbox name='serveroption$id' $checked> $longname<p>\n</td>\n";
	      } elsif ($type eq 'CHOICE') {
		  $choiceconfigtext.="<td colspan=4>\n";
		  $sti=$::dbh->prepare("select optionvalue from serverconfig where schoolserver=$q_schoolserver and optionname=$q_shortname");
		  $sti->execute;
		  MENUS::dbherr();
		  my ($value) = $sti->fetchrow;
		  my @options = split(/:/, $options);
		  my $optiontext='';
		  my $selected='';
		  foreach (@options) {
		      ($_ eq $value) ? ($selected='selected') : ($selected='');
		      $optiontext.="<option value='$_' $selected> $_\n";
		  }
		  $choiceconfigtext.="$longname:<select name='serveroption$id'>$optiontext</select>\n</td>\n";
	      } else {
# Some other type of configoption
	      }
	  }
	  $choiceconfigtext.="</tr>\n</table>\n";
	  my $serviceconfigtext="<table border=1>\n<tr>\n";
	  $i=-1;
	  $sth=$::dbh->prepare("select id,type,name from services");
	  $sth->execute;
	  while (my ($id, $type, $name) = $sth->fetchrow) {
	      my $q_name=$::dbh->quote($name);
	      if ($type eq 'BOOLEAN') {
		  if ($i++ == 4) {
		      $i=0;
		      $serviceconfigtext.="</tr>\n<tr>\n<td>\n";
		  } else {
		      $serviceconfigtext.="<td>\n";
		  }
		  my $sti=$::dbh->prepare("select value from serviceconfig where schoolserver=$q_schoolserver and service=$q_name");
		  $sti->execute;
		  MENUS::dbherr();
		  my ($value) = $sti->fetchrow;
		  ($value) ? ($checked='checked') : ($checked='');
		  ($sti->rows) || ($checked='checked');
		  $serviceconfigtext.="<input type=checkbox name='serviceoption$id' $checked> $name<p>\n</td>\n";
	      }
	  }
	  $serviceconfigtext.="</tr>\n</table>\n";
	  my $serveroptions_str=::getstr("Server Options");
	  my $servername_str=::getstr("Server Name");
	  my $schoolsthatusethisserver_str=::getstr("Schools that use this server");
	  my $servicestoberun_str=::getstr("Services to be run on this server", "Like samba, squid, apache, etc.");
	  my $commitchanges_str=::getstr("Commit Changes");
	  my $description_str=::getstr("Description");
	  my $deletesshkey_str=::getstr("Delete this server's SSH key");
	  my $deletesshkeyexplain_str=::getstr("If you do this, you will need to run <em>k12admin-client.setup</em> on the client to generate a new SSH key.  Use this option if you believe that a server's SSH key has been compromised.  I needed to use this option once when the hard drive was stolen from a machine that was being set up as a new server.");
	  print << "EOF";
	  <form method=post>
	  <input type=hidden name=adminschool value=$::adminschool>
	  <input type=hidden name=action value=editserver>
	  <input type=hidden name=serverid value=$schoolserver>
	  <input type=hidden name=menuitem value=editserver>
	  <center>
	  <table>
	  <tr><td>$servername_str</td><td>$name</td></tr>
	  <tr><td>$description_str</td><td><textarea name=description wrap=physical rows=5 cols=40>$description</textarea></td></tr>
	  <tr><th colspan=2>$serveroptions_str</td></tr>
	  <tr><td colspan=2>
	  $booleanconfigtext
	  </tr>
	  $choiceconfigtext
	  </td></tr>
	  <tr><th colspan=2>$servicestoberun_str</td></tr>
	  <tr><td colspan=2 align=center>
	  $serviceconfigtext
	  </td></tr>
	  <tr><th colspan=2>$schoolsthatusethisserver_str</td></tr>
	  <tr>
	  <td colspan=2 align=center>
	  <table border=1 cellpadding=0 cellspacing=0>
	  $attachedschools
	  </table>
	  </td>
	  </tr>
	  </table>
	  <table border=1 cellpadding=0 cellspacing=0>
	  <tr><td>
	  <input type=checkbox name=deletesshkey> $deletesshkey_str<br>$deletesshkeyexplain_str
	  </td></tr>
	  </table>
	  <input type=submit value="$commitchanges_str">
	  </form>
EOF
	} else {
	  $sth=$::dbh->prepare("select id,name from schoolservers order by name");
	  $sth->execute;
	  MENUS::dbherr();
	  while (my ($id, $name)=$sth->fetchrow) { 
	    push (@schoolservers,$name);
	    $serveroptions.="<option value=$id>$name\n";
	  }
	  my $editthisserver_str=::getstr("Edit This Server");
	  print << "EOF";
	  <form method=post>
	  <input type=hidden name=adminschool value=$::adminschool>
	  <input type=hidden name=menuitem value=editserver>
	  <center>
	  <select name=schoolserver size=10>
	  $serveroptions
	  </select>
	  <p>
	  <input type=submit value="$editthisserver_str">
	  </form>
EOF
	}
    }
}


# Add/modify/delete machine accounts (mostly used for smbpasswd)

sub adminmachines {
    if ($::indomainadmin) {
	if (my $schoolserver=$::query->param("schoolserver")) {
	  $sth=$::dbh->prepare("select name,description from schoolservers where id=$schoolserver");
	  $sth->execute;
	  MENUS::dbherr();
	  my ($name, $description) = $sth->fetchrow;

	  $sth=$::dbh->prepare("select school from servermap where server=$schoolserver");
	  $sth->execute;
	  MENUS::dbherr();
	  while (my ($school) = $sth->fetchrow) {
	      $schoolmap{$school}=1;
	  }


	  $sth=$::dbh->prepare("select id,longname from schools order by longname");
	  $sth->execute;
	  MENUS::dbherr();
	  $attachedschools="<tr>\n";
	  my $i=-1;
	  while (my ($id, $longname) = $sth->fetchrow) {
	      ($schoolmap{$id}) ? ($checked="checked") : ($checked='');
	      if ($i++ == 2) {
		  $i=0;
		  $attachedschools.="</tr>\n<tr>\n<td><input type=checkbox name=School$id $checked> $longname</td>\n";
	      } else {
		  $attachedschools.="<td><input type=checkbox name=School$id $checked> $longname</td>\n";
	      }
	  }

	  my $q_schoolserver=$::dbh->quote($schoolserver);
	  my $booleanconfigtext="<table border=1>\n<tr>\n";
	  my $choiceconfigtext='';
	  $sth=$::dbh->prepare("select id, vieworder, type, shortname,longname,options from serverconfigoptions order by vieworder");
	  $sth->execute;
	  my $b_i=-1;
	  my $c_i=-1;
	  while (my ($id, $order, $type, $shortname, $longname, $options) = $sth->fetchrow) {
	      my $q_shortname=$::dbh->quote($shortname);
	      if ($type eq 'BOOLEAN') {
		  if ($b_i++ == 3) {
		      $b_i=0;
		      $booleanconfigtext.="</tr>\n<tr>\n<td>\n";
		  } else {
		      $booleanconfigtext.="<td>\n";
		  }
		  $sti=$::dbh->prepare("select optionvalue from serverconfig where schoolserver=$q_schoolserver and optionname=$q_shortname");
		  $sti->execute;
		  MENUS::dbherr();
		  my ($value) = $sti->fetchrow;
		  ($value) ? ($checked='checked') : ($checked='');
		  $booleanconfigtext.="<input type=checkbox name='serveroption$id' $checked> $longname<p>\n</td>\n";
	      } elsif ($type eq 'CHOICE') {
		  $choiceconfigtext.="<td colspan=4>\n";
		  $sti=$::dbh->prepare("select optionvalue from serverconfig where schoolserver=$q_schoolserver and optionname=$q_shortname");
		  $sti->execute;
		  MENUS::dbherr();
		  my ($value) = $sti->fetchrow;
		  my @options = split(/:/, $options);
		  my $optiontext='';
		  my $selected='';
		  foreach (@options) {
		      ($_ eq $value) ? ($selected='selected') : ($selected='');
		      $optiontext.="<option value='$_' $selected> $_\n";
		  }
		  $choiceconfigtext.="$longname:<select name='serveroption$id'>$optiontext</select>\n</td>\n";
	      } else {
# Some other type of configoption
	      }
	  }
	  $choiceconfigtext.="</tr>\n</table>\n";
	  my $serviceconfigtext="<table border=1>\n<tr>\n";
	  $i=-1;
	  $sth=$::dbh->prepare("select id,type,name from services");
	  $sth->execute;
	  while (my ($id, $type, $name) = $sth->fetchrow) {
	      my $q_name=$::dbh->quote($name);
	      if ($type eq 'BOOLEAN') {
		  if ($i++ == 4) {
		      $i=0;
		      $serviceconfigtext.="</tr>\n<tr>\n<td>\n";
		  } else {
		      $serviceconfigtext.="<td>\n";
		  }
		  my $sti=$::dbh->prepare("select value from serviceconfig where schoolserver=$q_schoolserver and service=$q_name");
		  $sti->execute;
		  MENUS::dbherr();
		  my ($value) = $sti->fetchrow;
		  ($value) ? ($checked='checked') : ($checked='');
		  ($sti->rows) || ($checked='checked');
		  $serviceconfigtext.="<input type=checkbox name='serviceoption$id' $checked> $name<p>\n</td>\n";
	      }
	  }
	  $serviceconfigtext.="</tr>\n</table>\n";
	  my $serveroptions_str=::getstr("Server Options");
	  my $servername_str=::getstr("Server Name");
	  my $schoolsthatusethisserver_str=::getstr("Schools that use this server");
	  my $servicestoberun_str=::getstr("Services to be run on this server", "Like samba, squid, apache, etc.");
	  my $commitchanges_str=::getstr("Commit Changes");
	  my $description_str=::getstr("Description");
	  my $deletesshkey_str=::getstr("Delete this server's SSH key");
	  my $deletesshkeyexplain_str=::getstr("If you do this, you will need to run <em>k12admin-client.setup</em> on the client to generate a new SSH key.  Use this option if you believe that a server's SSH key has been compromised.  I needed to use this option once when the hard drive was stolen from a machine that was being set up as a new server.");
	  print << "EOF";
	  <form method=post>
	  <input type=hidden name=adminschool value=$::adminschool>
	  <input type=hidden name=action value=editserver>
	  <input type=hidden name=serverid value=$schoolserver>
	  <input type=hidden name=menuitem value=editserver>
	  <center>
	  <table>
	  <tr><td>$servername_str</td><td>$name</td></tr>
	  <tr><td>$description_str</td><td><textarea name=description wrap=physical rows=5 cols=40>$description</textarea></td></tr>
	  <tr><th colspan=2>$serveroptions_str</td></tr>
	  <tr><td colspan=2>
	  $booleanconfigtext
	  </tr>
	  $choiceconfigtext
	  </td></tr>
	  <tr><th colspan=2>$servicestoberun_str</td></tr>
	  <tr><td colspan=2 align=center>
	  $serviceconfigtext
	  </td></tr>
	  <tr><th colspan=2>$schoolsthatusethisserver_str</td></tr>
	  <tr>
	  <td colspan=2 align=center>
	  <table border=1 cellpadding=0 cellspacing=0>
	  $attachedschools
	  </table>
	  </td>
	  </tr>
	  </table>
	  <table border=1 cellpadding=0 cellspacing=0>
	  <tr><td>
	  <input type=checkbox name=deletesshkey> $deletesshkey_str<br>$deletesshkeyexplain_str
	  </td></tr>
	  </table>
	  <input type=submit value="$commitchanges_str">
	  </form>
EOF
	} else {
	  $sth=$::dbh->prepare("select id,name from schoolservers order by name");
	  $sth->execute;
	  MENUS::dbherr();
	  while (my ($id, $name)=$sth->fetchrow) { 
	    push (@schoolservers,$name);
	    $serveroptions.="<option value=$id>$name\n";
	  }
	  my $editthisserver_str=::getstr("Edit This Server");
	  my $newmachinename_str=::getstr("New machine name");
	  my $notrailingdollar_str=::getstr('(It is not necessary to add the trailing $ sign)');
	  my $addmachine_str=::getstr("Add This Machine");
	  print << "EOF";
	  <form method=post>
	  <input type=hidden name=adminschool value=$::adminschool>
	  <input type=hidden name=menuitem value=editserver>
	  <center>
	  <select name=schoolserver size=10>
	  $serveroptions
	  </select>
	  <p>
	  <input type=submit value="$editthisserver_str">
	  </form>
	  <p>
	  <form method=post>
	  <input type=hidden name=adminschool value=$::adminschool>
	  <input type=hidden name=menuitem value=adminmachines>
	  <input type=hidden name=action value=adminmachines>
	  $newmachinename_str: <input name=newmachine size=30>
	  <br>$notrailingdollar_str
	  <br>
	  <input type=submit value="$addmachine_str">
	  </form>
EOF
	}
    }
}

# Work in progress.  Edit attributes of individual schools.

sub editschool {
  my (@schools, $schooloptions);
  if ($::indomainadmin) {
    if (my $schoolid=$::query->param("editschool")) {
      $sth=$::dbh->prepare("select id, school, longname from schools where id=$schoolid");
      $sth->execute;
      MENUS::dbherr();
      my ($id, $school, $longname) = $sth->fetchrow;
      my $shortname_str=::getstr("Short Name");
      my $longname_str=::getstr("Long Name");
      my $editschool_str=::getstr("Edit School");
      print << "EOF";
      <form method=post>
      <input type=hidden name=adminschool value=$::adminschool>
      <input type=hidden name=action value=editschool>
      <input type=hidden name=schoolid value=$id>
      <input type=hidden name=menuitem value=editschool>
      <center>
      <h1>$editschool_str</h1>
      <table>
      <tr><td>$shortname_str</td><td>$school</td></tr>
      <tr><td>$longname_str</td><td><input name=longname
      value="$longname"></td></tr>
      </table>
      <input type=submit value="$editschool_str">
      </form>
EOF
      

    } else {
      $sth=$::dbh->prepare("select id,school from schools");
      $sth->execute;
      MENUS::dbherr();
      while (my ($id, $school)=$sth->fetchrow) { 
	push (@schools,$school);
	$schooloptions.="<option value=$id>$school\n";
      }
      my $editschool_str=::getstr("Edit School");
      print << "EOF";
      <form method=post>
      <input type=hidden name=adminschool value=$::adminschool>
      <input type=hidden name=menuitem value=editschool>
      <center>
      <h1>$editschool_str</h1>
      <select name=editschool size=10>
      $schooloptions
      </select>
      <p>
      <input type=submit value="$editschool_str">
      </form>
EOF
    }
  }
}

# Add a new school to the system.

sub addschool {
  local (@schools);
  if ($::indomainadmin) {
    $sth=$::dbh->prepare("select school from schools");
    $sth->execute;
    MENUS::dbherr();
    while (@record=$sth->fetchrow) { 
      push (@schools,$record[0]);
    }
    my $shortname_str=::getstr("Short Name");
    my $longname_str=::getstr("Long Name");
    my $addschool_str=::getstr("Add School");
    print << "EOFFORM";
    <FORM action=users.pl method=post>
    <input type=hidden name=adminschool value=$::adminschool>
    <input type=hidden name=action value=addschool>
    <center>
    <table cellpadding=2 border=1>
    <tr><td>$shortname_str (no spaces or punctuation): </td><td><input name=newschool></td></tr>
    <tr><td>$longname_str: </td><td><input name=longname></td></tr>
    </table>
    <p>
    <input value="$addschool_str" type=submit>
    </form>
    </body></html>
EOFFORM
  }
}

sub editsystem {
    foreach (keys %::configs) {
	print "$_ : ".$::configs{$_}."<br>\n";
    }
    my $sth=$::dbh->prepare("select id, vieworder, type, shortname,longname,options from systemconfigoptions order by vieworder");
    $sth->execute;
    my $b_i=-1;
    my $c_i=-1;
    my $booleanconfigtext='';
    my $choiceconfigtext='';
    my $textconfigtext='';
    while (my ($id, $order, $type, $shortname, $longname, $options) = $sth->fetchrow) {
	my $q_shortname=$::dbh->quote($shortname);
	if ($type eq 'BOOLEAN') {
	    if ($b_i++ == 3) {
		$b_i=0;
		$booleanconfigtext.="</tr>\n<tr>\n<td>\n";
	    } else {
		$booleanconfigtext.="<td>\n";
	    }
	    my $sti=$::dbh->prepare("select optionvalue from systemconfig where optionname=$q_shortname");
	    $sti->execute;
	    MENUS::dbherr();
	    my ($value) = $sti->fetchrow;
	    ($value) ? ($checked='checked') : ($checked='');
	    $booleanconfigtext.="<input type=checkbox name='systemoption$id' $checked> $longname<p>\n</td>\n";
	} elsif ($type eq 'CHOICE') {
	    $choiceconfigtext.="<td colspan=4>\n";
	    my $sti=$::dbh->prepare("select optionvalue from systemconfig where optionname=$q_shortname");
	    $sti->execute;
	    MENUS::dbherr();
	    my ($value) = $sti->fetchrow;
	    my @options = split(/:/, $options);
	    my $optiontext='';
	    my $selected='';
	    foreach (@options) {
		($_ eq $value) ? ($selected='selected') : ($selected='');
		$optiontext.="<option value='$_' $selected> $_\n";
	    }
	    $choiceconfigtext.="$longname:<select name='systemoption$id'>$optiontext</select>\n</td>\n";
	} elsif ($type eq 'TEXT') {
	    $textconfigtext.="<td colspan=4>\n";
	    my $sti=$::dbh->prepare("select optionvalue from systemconfig where optionname=$q_shortname");
	    $sti->execute;
	    MENUS::dbherr();
	    my ($value) = $sti->fetchrow;
	    $value=$::dbh->quote($value);
	    $textconfigtext.="$longname: <input name='systemoption$id' value=$value>\n</td>\n";
	} else {
# Some other type of configoption
	}
    }
    my $systemoptions_str=::getstr("Edit System Configuration Options");
    my $commitchanges_str=::getstr("Commit Changes");
    print << "EOF";
    <center>
    <form method=post>
    <input type=hidden name=adminschool value=$::adminschool>
    <input type=hidden name=action value=editsystem>
    <center>
    <table>
    <tr><th colspan=2><h2>$systemoptions_str</h2></td></tr>
    <tr><td colspan=2>
    <table border=1>
    <tr>
    $booleanconfigtext
    </tr>
    $choiceconfigtext
    </tr>
    <tr>
    $textconfigtext
    </tr>
    </table>
    <tr><td align=center><input type=submit value="$commitchanges_str"></td></tr>
    </table>
EOF
}


sub setdomainadmins {
    my $sth=$::dbh->prepare("select userid,fullname from users where flags & $::flags{'domainadmins'} order by fullname");
    $sth->execute;
    my $domainadmins='';
    while (my ($userid, $fullname) = $sth->fetchrow) {
	$domainadmins.="<option value=$userid>$fullname ($userid)\n";
    }
    print << "EOF";
    <form method=post>
    <table border=1>
    <tr><th>Remove Domain Admin Rights:</th><th>Add Domain Admin Rights</th></tr>
    <tr><td>
    <input type=hidden name=adminschool value=$::adminschool>
    <input type=hidden name=action value=setdomainadmins>
    <input type=hidden name=menuitem value=setdomainadmins>
    <select name=removedomainadmins size=10 multiple>
    $domainadmins
    </select>
    </td>
    <td>
    Enter a userid to add domainadmin rights to:
    <br>
    <input name=adddomainadmins size=20>
    </td>
    </tr>
    <tr><td colspan=2 align=center>
    <input type=submit>
    </td></tr>
    </table>
    </form>
EOF
}

# List of options for domain administrators.

sub admintools {
    if ($::indomainadmin) {
	my $selectadmintask_str=::getstr("Select an Administrative Task");
	my $addschool_str=::getstr("Add a School");
	my $renameschool_str=::getstr("Rename a School");
	my $deleteschool_str=::getstr("Delete a School");
	my $editschool_str=::getstr("Edit a School");
	my $editserver_str=::getstr("Edit Client Server Options");
	my $editsystem_str=::getstr("Edit K12Admin System Options");
	my $reviewlog_str=::getstr("Review K12Admin Log");
	my $reviewaudit_str=::getstr("Review Security Audit");
	my $setdomainadmins_str=::getstr("Set Domain Administrators");
	my $localizestrings_str=::getstr("Localize String Database");
	my $go_str=::getstr("Go");
	print <<"EOFFORM";
	<input type=hidden name=adminschool value=$::adminschool>
	<center>
	<table cellpadding=10 border=1>
	<tr><th colspan=3>$selectadmintask_str
	<tr><td align=center>
	<a href=users.pl?adminschool=$::adminschool&menuitem=addschool>$addschool_str</a><br>
	<a href=users.pl?adminschool=$::adminschool&menuitem=renameschool>$renameschool_str</a><br>
	<a href=users.pl?adminschool=$::adminschool&menuitem=deleteschool>$deleteschool_str</a><br>
	<a href=users.pl?adminschool=$::adminschool&menuitem=editschool>$editschool_str</a><br>
	</td><td align=center>
	<a href=users.pl?adminschool=$::adminschool&menuitem=editserver>$editserver_str</a><br>
	<a href=users.pl?adminschool=$::adminschool&menuitem=editsystem>$editsystem_str</a><br>
	<a href=users.pl?adminschool=$::adminschool&menuitem=translate>$localizestrings_str</a><br>
	</td><td align=center>
	<a href=users.pl?adminschool=$::adminschool&menuitem=reviewlog>$reviewlog_str</a><br>
	<a href=users.pl?adminschool=$::adminschool&menuitem=reviewaudit>$reviewaudit_str</a><br>
	<a href=users.pl?adminschool=$::adminschool&menuitem=setdomainadmins>$setdomainadmins_str</a><br>
	</td></tr>
	</table>
	<p>
EOFFORM
    }
}

sub moveuser {
    my $mvuser=$::query->param('moveuser');
    my $q_u=$::dbh->quote($mvuser);
    my $sth=$::dbh->prepare("select fullname from users where userid=$q_u");
    $sth->execute;
    my ($fullname)=$sth->fetchrow;
    my $moveto=$::query->param('moveto');
    if ($moveto) {
	print "<center><table border=1><tr><th>\n";
	print "Moving $fullname ($mvuser) to $moveto.\n";
	print "</th></tr><tr><td>\n";
	ACTIONS::moveuser($mvuser, $moveto);
	print "</td></tr>\n";
	print "<tr><td>Please <a href=users.pl?menuitem=modify&adminschool=$moveto>modify this user</a> so that they have the appropriate permissions (web access, dialin access, etc.).</td></tr>\n";
	print "</table>\n<hr>\n";
	print <<"EOF";
	<p>
EOF
    } else {
	print << "EOF";
	<center>
	<h2>Select a new school for $fullname ($mvuser)</h2>
	<form method=post>
	<input type=hidden name=menuitem value=moveuser>
	<input type=hidden name=moveuser value=$mvuser>
	<input type=hidden name=adminschool value=$::adminschool>
	$::selectallschools
	<p>
	<input type=submit value="Move To This School">
	</form>
	<hr>
	<table width=300><tr><td>
	<hr>
EOF
    }
}

# Allows an admin to move a group of students from his school to another.
# Useful for elementary to secondary transitions.

sub movelocalgroup {
    my $localgroup=$::query->param('movelocalgroup');
    my $st=$::dbh->prepare("select shortname,longname from localgroups where school=$::q_adminschool order by longname");
    $st->execute;
    MENUS::dbherr();
    my $localgrouplist;
    while (my ($short, $long)=$st->fetchrow) {
      $localgrouplist.="<option value=$short>$long\n";
    }
    if ($localgrouplist eq '') {
	$localgrouplist='No groups defined.';
    } else {
	$localgrouplist='<select name=movelocalgroup>'.$localgrouplist.'</select>';
    }
    unless ($localgroup) {
	print <<"EOF";
	<center>
	<form method=post>
	<input type=hidden name=menuitem value=movelocalgroup>
	<input type=hidden name=adminschool value=$::adminschool>
	$localgrouplist
	<p>
	<input type=submit value="Move This Group">
	</form>
EOF
    } else {
	my $lgq=$::dbh->quote($localgroup);
	my $moveto=$::query->param('moveto');
	if ($moveto) {
	    my $st=$::dbh->prepare("select longname from localgroups where shortname=$lgq");
	    $st->execute;
	    MENUS::dbherr();
	    my ($longname) = $st->fetchrow;
	    print "<center><table border=1><tr><th>\n";
	    print "Moving \"$longname\" users to $moveto.\n";
	    print "</th></tr><tr><td>\n";
	    $st=$::dbh->prepare("select userid from lglist where localgroup=$lgq
	    and school=$::q_adminschool");
	    $st->execute;
	    MENUS::dbherr();
	    while (my ($user) = $st->fetchrow) {
		ACTIONS::moveuser($user, $moveto);
	    }
	    print "</td></tr></table>\n<hr>\n";
	    print <<"EOF";
	    <p>
EOF
	} else {
	    print << "EOF";
	    <center>
	    <form method=post>
	    <input type=hidden name=menuitem value=movelocalgroup>
	    <input type=hidden name=movelocalgroup value=$localgroup>
	    <input type=hidden name=adminschool value=$::adminschool>
	    $::selectallschools
	    <p>
	    <input type=submit value="Move To This School">
	    </form>
	    <hr>
	    <table width=300><tr><td>
	    The following users will be moved from $::adminschool to the
	    school selected above.  Once the users are moved, they will no
	    longer be under your control.
	    <p>
	    <b>You will not be able to undo this!</b>  Please ensure that the
	    correct school is selected above.</td></tr></table>
	    <p>
	    Staff accounts will be displayed in red.
	    <hr>
EOF
	    my $st=$::dbh->prepare("select lglist.userid,users.fullname,users.flags from lglist,users where lglist.userid=users.userid and school=$::q_adminschool and localgroup=$lgq order by users.fullname");
	    $st->execute;
	    MENUS::dbherr();
	    print "<table border=1><tr>\n";
	      while (my ($userid, $fullname, $flags) = $st->fetchrow) {
		  my ($last,$first)=split(/\s+/, $fullname);
		  if ($flags & $::flags{'staff'}) {
		      print "<td><font color=red>$first $last</font></td>\n";
		  } else {
		      print "<td>$first $last</td>\n";
		  }
		  if ($i++>4) {
		      $i=0;
		      print "</tr><tr>\n";
		  }
	    }
	    print "</tr></table>\n";
	}
    }
}

# This is the first menu that a user sees of the system.

sub mainmenu {
    my $domainadmintext='';
    if ($::indomainadmin) {
	  my $selectadmintask_str=::getstr("Select an Administrative Task");
	  my $addschool_str=::getstr("Add a School");
	  my $renameschool_str=::getstr("Rename a School");
	  my $deleteschool_str=::getstr("Delete a School");
	  my $editschool_str=::getstr("Edit a School");
	  my $editserver_str=::getstr("Edit Client Server Options");
	  my $adminmachines_str=::getstr("Administer Machines");
	  my $editsystem_str=::getstr("Edit K12Admin System Options");
	  my $reviewlog_str=::getstr("Review K12Admin Log");
	  my $reviewaudit_str=::getstr("Review Security Audit");
	  my $setdomainadmins_str=::getstr("Set Domain Administrators");
	  my $localizestrings_str=::getstr("Localize String Database");
	  my $go_str=::getstr("Go");
	  $domainadmintext= << "EOF";
<tr><td align=center colspan=2>
<table border=1 bgcolor=#DDDD77>
<tr>
<th colspan=3>K12Admin District Administration Menu</th>
</tr>
<tr>
<th>School Setup</th><th>Configuration Options</th><th>Miscellaneous</th>
</tr>
<tr>
<td align=center>
<a href=users.pl?adminschool=$::adminschool&menuitem=addschool>$addschool_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=renameschool>$renameschool_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=deleteschool>$deleteschool_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=editschool>$editschool_str</a><br>
</td><td align=center>
<a href=users.pl?adminschool=$::adminschool&menuitem=editserver>$editserver_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=adminmachines>$adminmachines_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=editsystem>$editsystem_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=translate>$localizestrings_str</a><br>
</td><td align=center>
<a href=users.pl?adminschool=$::adminschool&menuitem=reviewlog>$reviewlog_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=reviewaudit>$reviewaudit_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=setdomainadmins>$setdomainadmins_str</a><br>
</td></tr>
</table>
</td></tr>
EOF
    }
    $::selectschool=~s/<option value=$::adminschool>$::longnames{$::adminschool}//;
    $header="<th colspan=2><font color=#990000 size=+1>".$::longnames{$::adminschool}."</font></th>";
    my $help_str=::getstr("If you need help with anything on this site, your best resource is to post your question to <b>tonnesen\@cmsd.bc.ca</b>");
    my $individual_str=::getstr("Individual");
    my $groups_str=::getstr("Groups");
    my $misc_str=::getstr("Miscellaneous");
    my $createaccounts_str=::getstr("Create Accounts");
    my $modifyaccounts_str=::getstr("Modify Accounts");
    my $removeaccounts_str=::getstr("Remove Accounts");
    my $modifygrouplists_str=::getstr("Modify Group Lists");
    my $movegroup_str=::getstr("Move Group to a New School");
    my $search4user_str=::getstr("Search for a User");
    my $browseproxylogs_str=::getstr("Browse Student Proxy Logs");
    my $reviewaudit_str=::getstr("Review Security Audit");
    my $listaccounts_str=::getstr("List Accounts");
    my $picklang_str=::getstr("Pick a Language");
    print << "EOFFORM";
<center>
$help_str
<table border=1 cellpadding=3 bgcolor=#AAAADD>
<tr>$header
</tr>
<tr><th>$individual_str</th><th>$misc_str</th></tr>
<form method=post>
<tr valign=top><td align=center>
<a href="users.pl?menuitem=addmultiple&adminschool=$::adminschool">$createaccounts_str </a><br>
<a href="users.pl?menuitem=modify&adminschool=$::adminschool">$modifyaccounts_str</a><br>
<a href="users.pl?menuitem=delacct&adminschool=$::adminschool">$removeaccounts_str</a><br>
</td>
<td  rowspan=3 align=center>
<a href="users.pl?menuitem=searchuser&adminschool=$::adminschool">$search4user_str</a><br>
<a href="users.pl?menuitem=squidlog&adminschool=$::adminschool">$browseproxylogs_str</a><br>
<a href="users.pl?menuitem=listrequests&adminschool=$::adminschool">$listaccounts_str</a><br>
<a href="users.pl?menuitem=reviewauditschool&adminschool=$::adminschool">$reviewaudit_str</a><br>
<a href="users.pl?menuitem=language">$picklang_str</a><br>
<a href=users.pl?adminschool=$::adminschool&menuitem=test>New Interface Demo</a><br>
<br>$::selectschool
</td></tr>
<tr>
<th>$groups_str</th>
</tr>
<tr>
<td align=center>
<a href="users.pl?menuitem=localgroups&adminschool=$::adminschool">$modifygrouplists_str</a><br>
<a href="users.pl?menuitem=movelocalgroup&adminschool=$::adminschool">$movegroup_str</a><br>
</td>
</tr>
$domainadmintext
</table>
</form>
EOFFORM
}


#
# Pick a language for translations
#

sub language {
    my @langs;
    my $sth=$::dbh->prepare("show columns from strings");
    $sth->execute;
    my $supportedlangs=::getstr("Currently supported languages are")." ";
    while (my ($field) = $sth->fetchrow) {
	(next) if ($field eq 'id');
	push (@langs, $field);
	$supportedlangs.="$field, ";
    }
    chop $supportedlangs;
    chop $supportedlangs;
    $supportedlangs.=".  ".::getstr("You may add new languages.");
    $pickalanguage_str=::getstr("Pick a Language");
    $setlanguage_str=::getstr("Set Language");
    print << "EOF";
    <center>
    <h1>$pickalanguage_str</h1>
    <form method=post>
    <input type=hidden name=action value=language>
    <input type=hidden name=menuitem value=skip>
    Language: <input size=15 name=lang>
    <p>
    <input type=submit value="$setlanguage_str">
    </form>
    $supportedlangs
    <p>
EOF
}

# List accounts that were recently added, or accounts from a specific group.

sub listrequests {
  my $localgrouplist='';
  my $st=$::dbh->prepare("select shortname,longname from localgroups where school=".$::dbh->quote($::adminschool)." order by vieworder");
  $st->execute;
  MENUS::dbherr();
  while (my ($short, $long)=$st->fetchrow) {
      $localgrouplist.="<option value=$short>$long\n";
  }
  print << "EOF";
  <HTML><HEAD><TITLE>List Recently Added Users</title></head>
  <Body>
  <center>
  <h1>List Accounts at $::adminschool</h1>
  <table>
  <tr><td>
  <form method=post action=users.pl>
  <input type=hidden name=userid value=$::username>
  <input type=hidden name=adminschool value=$::adminschool>
  <input type=hidden name=action value=listrequests>
  <input type=hidden name=menuitem value=skip>
  <input type=hidden name=listtype value=time>
  <table cellpadding=10 border=1>
  <tr><th>List Recently Added Users</th></tr>
  <tr><td align=center>
  Going back: 
  <input size=5 name=backhowfar>
  <select name=units value=hours>
  <option value=hours>hours
  <option value=days>days
  <option value=weeks>weeks
  </select>
  <p>
  <input type=submit value=Submit>
  </form>
  </td></tr>
  </table>
  </td><td>
  <form method=post>
  <input type=hidden name=userid value=$::username>
  <input type=hidden name=adminschool value=$::adminschool>
  <input type=hidden name=action value=listrequests>
  <input type=hidden name=menuitem value=skip>
  <input type=hidden name=listtype value=group>
  <table cellpadding=10 border=1>
  <tr><th>Select a Group of Users</th></tr>
  <tr><td align=center>
  <select name=localgroup>
  $localgrouplist
  </select>
  <p>
  <input type=submit value=Submit>
  </td></tr>
  </table>
  </form>
  </td></tr>
  </table>

  <p>
EOF
}


# A menu with just one option: "Return to Main Menu".  This is used when
# an action prints out information.  sub listrequests is a good example
# of this.

sub skipform {
  print <<"EOF";
  <center>
  <FORM action=users.pl method=post>
  <input type=hidden name=userid value=$::username>
  <input type=hidden name=adminschool value=$::adminschool>
  <input type=submit value="Return to Main Menu">
  </form>
  </center>
EOF
}


# Subroutine was used before all functions were completed. Not currently used
# anywhere.

sub naform {
  print <<"EOF";
  <center>
  <h1>This feature is not yet implemented</h1>
  <FORM action=users.pl method=post>
  <input type=hidden name=userid value=$::username>
  <input type=hidden name=adminschool value=$::adminschool>
  </form>
EOF
}



# Add multiple accounts.  There used to be an addsingle routine, but I just
# deleted it.  :)

sub addmultiple {
  my ($text);
  my $st=$::dbh->prepare("select shortname,longname from localgroups where school=".$::dbh->quote($::adminschool)." order by longname");
  $st->execute;
  MENUS::dbherr();
  my $localgrouplist='';
  my $lglist='';
  while (my ($short, $long)=$st->fetchrow) {
    $lglist.="<input type=checkbox name=lg value=$short> $long<br>\n";
  }
  ($lglist) || ($lglist=::getstr("No Local Groups Defined"));

  if ($::indomainadmin) {
      $st=$::dbh->prepare("select shortname,longname from localgroups where school='global'  order by vieworder,longname");
  } else {
      $st=$::dbh->prepare("select shortname,longname from localgroups where school='global'  and restricted !=1 order by vieworder,longname");
  }
  $st->execute;
  MENUS::dbherr();
  my $gglist='';
  while (($short, $long)=$st->fetchrow) {
      $long = ::getstr($long, "Global group name.  Should be short (Application Administrators is currently the longest english one)");
      $gglist.="<input type=checkbox name=gg value=$short> $long<br>\n";
  }
  ($gglist) || ($gglist=::getstr("No Global Groups Defined"));
  my $addmultipleusers_str=::getstr("Add Users");
  my $group_str=::getstr("group");
  my $firstname_str=::getstr("First name");
  my $lastname_str=::getstr("Last name");
  my $password_str=::getstr("Password");
  my $passwordisoptional_str=::getstr("password is optional");
  my $defaultpassword_str=::getstr("Default Password");
  my $addusers_str=::getstr("Add Users");
  my $localgroups_str=::getstr("Local Groups");
  my $globalgroups_str=::getstr("Global Groups");

  print <<"EOFFORM"
  <center>
  <FORM action=users.pl method=post>
  <input type=hidden name=userid value=$::username>
  <input type=hidden name=action value=addmultiple>
  <input type=hidden name=menuitem value=addmultiple>
  <input type=hidden name=adminschool value=$::adminschool>
  <table cellpadding=3 border=1>
      <tr><th colspan=2>
	  <table>
	      <tr><td>
	      $addmultipleusers_str ($::adminschool $group_str) 
	      </td><td>
	      <a href=/k12admin/help/createaccounts.html target="Account Admin Help"><img src=/k12admin/images/help.gif align=left border=0></a>
	      </td></tr>
	  </table>
	  </th>
      </tr>
      <tr>
	  <td valign=top>
	  <table>
	      <tr><td colspan=4>
		  <center>
		  $firstname_str,$lastname_str,$password_str<br>
		  <i>$passwordisoptional_str</i>
		  <br>
		  <textarea rows=7 cols=24 name=multusers></textarea>
		  </center>
		  </td>
	      </tr>
	      <tr>
		  <td>$defaultpassword_str: </td><td><input name=defaultpass size=9></td>
	      </tr>
	      <tr>
		  <td colspan=4 align=center>
		  <input type=submit value="$addusers_str">
		  </td>
	      </tr>
	  </table>
	  </td>
	  <td valign=top>
	      <table><tr><td valign=top>
	      <center>$globalgroups_str</center><hr>$gglist
	      </td><td valign=top>
	      <center>$localgroups_str</center><hr>$lglist
	      </td></tr></table>
	  </td>
      </tr>
  </table>
  </form>
  <br>
EOFFORM
}

# Cute, but useless.  Prints a fortune cookie at the bottom of each screen.
# Make sure that you have removed the obscene fortunes...

sub fortune {
  local ($fortune);
  $fortune=`/usr/games/fortune`;
  return ("<font size=2><hr>\n<pre>\n$fortune\n</pre><hr></font>");
}


# Delete accounts.

sub delacct {
    local (@student, $text, @staff, $daf, @record);
    $text="<table border=1 cellpadding=4>\n";
    $text.="<tr><th>". ::getstr("Students") ."</th><th>" . ::getstr("Staff") . "</th></tr>\n";
    $text.="<tr><td align=center><select name=delstudent multiple size=15>\n";
    $daf=$::dbh->prepare("select users.fullname,users.userid from users,homeschools where homeschools.school='$::adminschool' and !(users.flags&$::flags{'staff'}) and homeschools.userid=users.userid order by fullname");
    $daf->execute;
    MENUS::dbherr();
    while (($fullname, $userid)=$daf->fetchrow) {
	($last, $first)=split(/\s+/, $fullname);
	$fullname="$last, $first";
	$text.="<option value=$userid>$fullname ($userid)\n";
    }
    $text.="</select></td><td align=center><select name=delstaff multiple size=15>";
$daf=$::dbh->prepare("select users.fullname,users.userid from users,homeschools where homeschools.school='$::adminschool' and (users.flags&$::flags{'staff'}) and homeschools.userid=users.userid order by fullname");
    $daf->execute;
    MENUS::dbherr();
    while (($f, $u)=$daf->fetchrow) {
	($last,$first)=split(/\s+/,$f);
	$fullname="$last, $first";
	$text.="<option value=$u>$fullname ($u)\n";
    }
    $text.="</select></td></tr></table>\n";
    my $deleteaccounts_str=::getstr("Delete Accounts");
    print << "EOFFORM";
    <FORM action=users.pl method=post>
    <input type=hidden name=userid value=$::username>
    <input type=hidden name=adminschool value=$::adminschool>
    <input type=hidden name=action value=delacct>
    <input type=hidden name=menuitem value=>
    <center>
    <table cellpadding=10 border=1>
    <tr><th colspan=2>
    <table>
    <tr><td>
    $deleteaccounts_str ($::adminschool)
    </td><td>
    <a href=/k12admin/help/delete.html target="Account Admin Help"><img src=/k12admin/images/help.gif align=right border=0></a>
    </td></tr></table>
    </th></tr>
    <tr><td>
    <center>
    $text
    </center>
    </td></tr>
    </table>
    <p>
    <input type=submit value="$deleteaccounts_str">
    </form>
    <p>
EOFFORM
}


# Subroutine to print a tasklist.  This was originally designed to show the
# status of task completion on our NT system, and isn't very relevant for
# linux only setups.  I'd like to replace this with something that just uses
# the "log" table which is cleaner anyway.

sub gettasklist {
  my $time=time()-24*3600;
  my $date=localtime($time);
  my $output="<H1>" . ::getstr("Activity Log for") . " $::username</H1>\n";
  my $q_username=$::dbh->quote($::username);
  my $sth=$::dbh->prepare("select time,activity from log where user=$q_username and time>$time order by id desc");
  $sth->execute;
  $output.="\n<br>\n<table border=1>\n<tr><th colspan=2>" . ::getstr("Activity Log for") . " $::username</th></tr>\n";
  while (my ($t, $a)=$sth->fetchrow) {
    $date=join(' ',(split(/\s+/,localtime($t)))[0,1,2,3]);
    $output.="<tr><td>$date<td>$a</tr>\n";
  }
  $output.="</table>\n";
  return ($output);
}

# Review Security Audit

sub reviewaudit {
    unless ($::indomainadmin) {
	print "<font color=red size=+4>Unauthorized access to global security audit.  This abuse has been logged.</font><br>\n";
	return;
    }
    my $numrecords=86400*3;
    my (@criteria, $auditsite, $audituserid, $auditsource);;
    if ($auditsite = $::query->param("auditsite")) {
	my $q_site = $::dbh->quote($auditsite);
	push @criteria, " site=$q_site ";
    }
    if ($audituserid = $::query->param("audituserid")) {
	my $q_userid = $::dbh->quote($audituserid);
	push @criteria, " userid=$q_userid ";
    }
    if ($auditsource = $::query->param("auditsource")) {
	my $q_source = $::dbh->quote($auditsource);
	push @criteria, " source=$q_source ";
    }
    my $criteria='';
    if ($#criteria>=0) {
	$criteria = 'and '.join ("and", @criteria);
    }
    my $sth;
    if ($::query->param("criteria")) {
	$sth=$::dbh->prepare("select max(start),min(start) from audit where 1 $criteria");
	$sth->execute;
	my ($maxdate,$mindate) = $sth->fetchrow;
	my $startdate=$::query->param("startid");
	my $highdate=$maxdate+1;
	if ($startdate) {
	    $highdate=$startdate;
	}
	    
	my $lowdate=$highdate-$numrecords;
	my $nextdate=$highdate+$numrecords;
	my $prevdate;
	if ($nextdate > ($maxdate+1)) {
	    $prevdate=$maxdate+1-$numrecords;
	    $nextdate=$maxdate+1;
	} else {
	    $prevdate=$nextdate-$numrecords*2;
	}
	($prevdate < ($mindate+$numrecords)) && ($prevdate=$mindate+$numrecords);

	print "<H1>" . ::getstr("Security Audit") . "</H1>\n";
	my $back_str=::getstr("Back");
	my $forward_str=::getstr("Back");
	my $changecriteria_str=::getstr("Change Criteria");
	print << "EOF";
	<table>
	<tr>
	<td width=50% align=left>
	<form method=post>
	<input type=hidden name=menuitem value=reviewauditschool>
	<input type=hidden name=criteria value=1>
	<input type=hidden name=auditsite value=\"$auditsite\">
	<input type=hidden name=audituserid value=\"$audituserid\">
	<input type=hidden name=auditsource value=\"$auditsource\">
	<input type=hidden name=adminschool value=$::adminschool>
	<input type=hidden name=startid value=$prevdate>
	<input type=submit value="$back_str">
	</form>
	</td>
	<td>
	<form method=post>
	<input type=hidden name=menuitem value=reviewauditschool>
	<input type=hidden name=criteria value=0>
	<input type=hidden name=adminschool value=$::adminschool>
	<input type=submit value="$changecriteria_str">
	</form>
	</td>
	<td width=50% align=right>
	<form method=post>
	<input type=hidden name=menuitem value=reviewaudit>
	<input type=hidden name=criteria value=1>
	<input type=hidden name=auditsite value=\"$auditsite\">
	<input type=hidden name=audituserid value=\"$audituserid\">
	<input type=hidden name=auditsource value=\"$auditsource\">
	<input type=hidden name=adminschool value=$::adminschool>
	<input type=hidden name=startid value=$nextdate>
	<input type=submit value="$forward_str">
	</form>
	</td></tr>
	</table>
EOF
	my $q_username=$::dbh->quote($::username);
	$sth=$::dbh->prepare("select source,alternate,description from auditsources");
	$sth->execute;
	MENUS::dbherr();
	my (%alternate, %description);
	while (my ($s, $a, $d) = $sth->fetchrow) {
	    $alternate{$s}=::getstr("$a");
	    $description{$s}=::getstr("$d");
	}

	my $task="select computer, ip, start, end, elapsed, source, userid, site from audit where start>$lowdate and start<$highdate $criteria order by start desc";
	$sth=$::dbh->prepare($task);
	$sth->execute;
	MENUS::dbherr();
	print "<table border=1>\n";
	print "<tr><th>" . ::getstr("Userid") . "</th><th>" . ::getstr("Site") . "</th><th>" . ::getstr("Service") . "</th><th>" . ::getstr("Computer") . "</th><th>" . ::getstr("IP Address") . "</th><th>" . ::getstr("Start Time") . "</th><th>" . ::getstr("End Time") . "</th><th>" . ::getstr("Elapsed") . "</th></tr>\n";
	while (my ($computer, $ip, $start, $end, $elapsed, $source, $userid, $site) = $sth->fetchrow) {
	    $starttime=localtime($start);
	    $endtime=localtime($end);
	    my $seconds_str=::getstr("seconds", "as in '4 seconds have elapsed'");
	    my $minute_str=::getstr("minute", "as in '1 minute has elapsed'");
	    my $minutes_str=::getstr("minutes", "as in '4 seconds have elapsed'");
	    my $hour_str=::getstr("hour", "as in '1 hour has elapsed'");
	    my $hours_str=::getstr("hours", "as in '4 hours have elapsed'");
	    my $day_str=::getstr("day", "as in '1 day has elapsed'");
	    my $days_str=::getstr("days", "as in '4 days have elapsed'");
	    SWITCH: {
		if ($elapsed <60) { $elapsed=sprintf "%d $seconds_str", $elapsed; last SWITCH; }
		if ($elapsed <120) { $elapsed="1 $minute_str"; last SWITCH; }
		if ($elapsed <3600) { $elapsed=sprintf "%d $minutes_str", $elapsed/60; last SWITCH; }
		if ($elapsed <7200) { $elapsed="1 $hour_str"; last SWITCH; }
		if ($elapsed <3600*24) { $elapsed=sprintf "%d $hours_str", $elapsed/60/60; last SWITCH; }
		if ($elapsed< 3600*24*2) { $elapsed="1 $day_str"; last SWITCH; }
		$elapsed=sprintf "%d $days_str", $elapsed/60/60/24;
	    }
	    $used{$source}=1;

	    my $service;
	    ($service=$alternate{$source}) || ($service=$source);
	    printf "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>\n", $userid, $site, $service, $computer, $ip, $starttime, $endtime, $elapsed;
	}
	print "</table><br><hr>\n";
	print "<table>\n";
	print "<tr><th colspan=2>" . ::getstr("Service Descriptions") . "</th></tr>\n";
	foreach (keys %used) {
	    print "<tr><td>".$alternate{$_}."</td><td>".$description{$_}."</td></tr>\n";
	}
    } else {
	$sth=$::dbh->prepare("select distinct site from audit order by site");
	$sth->execute;
	MENUS::dbherr();
	my $siteoptions="";
	while (my ($site) = $sth->fetchrow) {
	    (next) unless ($site);
	    $siteoptions.="<option value=\"$site\"> $site\n";
	}
	$sth=$::dbh->prepare("select distinct userid from audit order by userid");
	$sth->execute;
	MENUS::dbherr();
	my $useridoptions="";
	while (my ($userid) = $sth->fetchrow) {
	    (next) unless ($userid);
	    $useridoptions.="<option value=\"$userid\"> $userid\n";
	}
	$sth=$::dbh->prepare("select distinct source from audit order by source");
	$sth->execute;
	MENUS::dbherr();
	my $sourceoptions="";
	while (my ($source) = $sth->fetchrow) {
	    (next) unless ($source);
	    $sourceoptions.="<option value=\"$source\"> $source\n";
	}
	$selectcriteria_str=::getstr("Select Criteria");
	print << "EOF";
	<h1>Select Criteria</h1>
	<form method=post>
	<input type=hidden name=menuitem value=reviewaudit>
	<input type=hidden name=criteria value=1>
	<table border=1>
	<tr><th>Site</th><th>Service</th><th>Userid</th></tr>
	<tr>
	<td>
	<select name=auditsite size=10>$siteoptions</select>
	</td>
	<td>
	<select name=auditsource size=10>$sourceoptions</select>
	</td>
	<td>
	<select name=audituserid size=10>$useridoptions</select>
	</td></tr>
	</table>
	<input type=submit>
	</form>
EOF
    }
}


# Review audit for one school

sub reviewauditschool {
    my $numrecords=86400*3;
    my ($sth, @criteria, $auditsite, $audituserid, $auditsource);;
    $sth=$::dbh->prepare("select schoolservers.name from schoolservers,schools,servermap where schools.id=servermap.school and schoolservers.id=servermap.server and schools.school=$::q_adminschool");
    $sth->execute;
    MENUS::dbherr();
    my $siteoptions="";
    my @sites;
    while (my ($site) = $sth->fetchrow) {
	(next) unless ($site);
	$siteoptions.="<option value=\"$site\"> $site\n";
	push @sites, "site=".$::dbh->quote($site);
    }
    my $sitecriteria='';
    ($#sites>-1) && ($sitecriteria='('.join (' or ', @sites).')');
    if ($auditsite = $::query->param("auditsite")) {
	my $q_site = $::dbh->quote($auditsite);
	unless ($::indomainadmin) {

# Check to see if this user has access to this server.  They will have access
# if this server is attached to any school that they are a member of
# accountadmins in

	    $sth=$::dbh->prepare("select * from lglist,servermap,schools,schoolservers where servermap.school=schools.id and servermap.server=schoolservers.id and lglist.school=schools.school and schoolservers.name=$q_site and lglist.localgroup='accountadmins' and lglist.userid=$::q_username");
	    $sth->execute;
	    MENUS::dbherr();
	    unless ($sth->rows) {
		print "<font color=red size=+3>You do not have access to the $auditsite server.  This abuse has been logged.</font><br>\n";
		return;
	    }
	}
	push @criteria, " site=$q_site ";
    }
    if ($audituserid = $::query->param("audituserid")) {
	my $q_userid = $::dbh->quote($audituserid);
	unless ($::indomainadmin) {

# Check to see if this admin has access to this user.  The admin will have
# access if this user is a member of any school that the admin is a member of
# accountadmins in

	    $sth=$::dbh->prepare("select * from lglist,schools,homeschools where homeschools.school=schools.id and homeschools.userid=$q_userid and lglist.school=schools.school and lglist.localgroup='accountadmins' and lglist.userid=$::q_username");
	    $sth->execute;
	    MENUS::dbherr();
	    unless ($sth->rows) {
		print "<font color=red size=+3>You do not have access to the $audituserid account.  This abuse has been logged.</font><br>\n";
		return;
	    }
	}
	push @criteria, " userid=$q_userid ";
    }
    if ($auditsource = $::query->param("auditsource")) {
	my $q_source = $::dbh->quote($auditsource);
	push @criteria, " source=$q_source ";
    }
    my $criteria='';
    if ($#criteria>=0) {
	$criteria = 'and '.join ("and", @criteria);
    }
    if ($::query->param("criteria")) {
	$sth=$::dbh->prepare("select max(start),min(start) from audit where $sitecriteria $criteria");
	$sth->execute;
	my ($maxdate,$mindate) = $sth->fetchrow;
	my $startdate=$::query->param("startid");
	my $highdate=$maxdate+1;
	if ($startdate) {
	    $highdate=$startdate;
	}
	    
	my $lowdate=$highdate-$numrecords;
	my $nextdate=$highdate+$numrecords;
	my $prevdate;
	if ($nextdate > ($maxdate+1)) {
	    $prevdate=$maxdate+1-$numrecords;
	    $nextdate=$maxdate+1;
	} else {
	    $prevdate=$nextdate-$numrecords*2;
	}
	($prevdate < ($mindate+$numrecords)) && ($prevdate=$mindate+$numrecords);

	print "<H1>" . ::getstr("Security Audit") . "</H1>\n";
	print << "EOF";
	<table>
	<tr>
	<td width=50% align=left>
	<form method=post>
	<input type=hidden name=menuitem value=reviewaudit>
	<input type=hidden name=criteria value=1>
	<input type=hidden name=auditsite value=\"$auditsite\">
	<input type=hidden name=audituserid value=\"$audituserid\">
	<input type=hidden name=auditsource value=\"$auditsource\">
	<input type=hidden name=adminschool value=$::adminschool>
	<input type=hidden name=startid value=$prevdate>
	<input type=submit value="Previous days">
	</form>
	</td>
	<td>
	<form method=post>
	<input type=hidden name=menuitem value=reviewauditschool>
	<input type=hidden name=criteria value=0>
	<input type=hidden name=adminschool value=$::adminschool>
	<input type=submit value="Change Criteria">
	</form>
	</td>
	<td width=50% align=right>
	<form method=post>
	<input type=hidden name=menuitem value=reviewaudit>
	<input type=hidden name=criteria value=1>
	<input type=hidden name=auditsite value=\"$auditsite\">
	<input type=hidden name=audituserid value=\"$audituserid\">
	<input type=hidden name=auditsource value=\"$auditsource\">
	<input type=hidden name=adminschool value=$::adminschool>
	<input type=hidden name=startid value=$nextdate>
	<input type=submit value="Next days">
	</form>
	</td></tr>
	</table>
EOF
	my $q_username=$::dbh->quote($::username);
	$sth=$::dbh->prepare("select source,alternate,description from auditsources");
	$sth->execute;
	MENUS::dbherr();
	my (%alternate, %description);
	while (my ($s, $a, $d) = $sth->fetchrow) {
	    $alternate{$s}=$a;
	    $description{$s}=$d;
	}

	my $task="select computer, ip, start, end, elapsed, source, userid, site from audit where $sitecriteria and start>$lowdate and start<$highdate $criteria order by start desc";
	$sth=$::dbh->prepare($task);
	$sth->execute;
	MENUS::dbherr();
	print "<table border=1>\n";
	print "<tr><th>Userid</th><th>Site</th><th>Service</th><th>Computer</th><th>Address</th><th>Start Time</th><th>End Time</th><th>Elapsed</th></tr>\n";

	print "TESTING!!!!!!<br>\n";
	my $seconds_str=::getstr("seconds", "as in '4 seconds have elapsed'");
	my $minute_str=::getstr("minute", "as in '1 minute has elapsed'");
	my $minutes_str=::getstr("minutes", "as in '4 seconds have elapsed'");
	my $hour_str=::getstr("hour", "as in '1 hour has elapsed'");
	my $hours_str=::getstr("hours", "as in '4 hours have elapsed'");
	my $day_str=::getstr("day", "as in '1 day has elapsed'");
	my $days_str=::getstr("days", "as in '4 days have elapsed'");
	while (my ($computer, $ip, $start, $end, $elapsed, $source, $userid, $site) = $sth->fetchrow) {
	    $starttime=localtime($start);
	    $endtime=localtime($end);
	    SWITCH: {
		if ($elapsed <60) { $elapsed=sprintf "%d $seconds_str", $elapsed; last SWITCH; }
		if ($elapsed <120) { $elapsed="1 $minute_str"; last SWITCH; }
		if ($elapsed <3600) { $elapsed=sprintf "%d $minutes_str", $elapsed/60; last SWITCH; }
		if ($elapsed <7200) { $elapsed="1 $hour_str"; last SWITCH; }
		if ($elapsed <3600*24) { $elapsed=sprintf "%d $hours_str", $elapsed/60/60; last SWITCH; }
		if ($elapsed< 3600*24*2) { $elapsed="1 $day_str"; last SWITCH; }
		$elapsed=sprintf "%d $days_str", $elapsed/60/60/24;
	    }
	    $used{$source}=1;

	    my $service;
	    ($service=$alternate{$source}) || ($service=$source);
	    printf "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>\n", $userid, $site, $service, $computer, $ip, $starttime, $endtime, $elapsed;
	}
	print "</table><br><hr>\n";
	print "<table>\n";
	print "<tr><th colspan=2>Service Descriptions</th></tr>\n";
	foreach (keys %used) {
	    print "<tr><td>".$alternate{$_}."</td><td>".$description{$_}."</td></tr>\n";
	}
    } else {
	$sth=$::dbh->prepare("select schoolservers.name from schoolservers,schools,servermap where schools.id=servermap.school and schoolservers.id=servermap.server and schools.school=$::q_adminschool");
	$sth->execute;
	MENUS::dbherr();
	my $siteoptions="";
	@sites=( );
	while (my ($site) = $sth->fetchrow) {
	    (next) unless ($site);
	    $siteoptions.="<option value=\"$site\"> $site\n";
	    push @sites, "site=".$::dbh->quote($site);
	}
	my $sitecriteria='';
	($#sites>-1) && ($sitecriteria='where ('.join (' or ', @sites).')');
	$sth=$::dbh->prepare("select distinct userid from audit $sitecriteria order by userid");
	$sth->execute;
	MENUS::dbherr();
	my $useridoptions="";
	while (my ($userid) = $sth->fetchrow) {
	    (next) unless ($userid);
	    $useridoptions.="<option value=\"$userid\"> $userid\n";
	}
	$sth=$::dbh->prepare("select distinct source from audit $sitecriteria order by source");
	$sth->execute;
	MENUS::dbherr();
	my $sourceoptions="";
	while (my ($source) = $sth->fetchrow) {
	    (next) unless ($source);
	    $sourceoptions.="<option value=\"$source\"> $source\n";
	}
	print << "EOF";
	<h1>Select Criteria</h1>
	<form method=post>
	<input type=hidden name=menuitem value=reviewauditschool>
	<input type=hidden name=adminschool value=$::adminschool>
	<input type=hidden name=criteria value=1>
	<table border=1>
	<tr><th>Site</th><th>Service</th><th>Userid</th></tr>
	<tr>
	<td>
	<select name=auditsite size=10>$siteoptions</select>
	</td>
	<td>
	<select name=auditsource size=10>$sourceoptions</select>
	</td>
	<td>
	<select name=audituserid size=10>$useridoptions</select>
	</td></tr>
	</table>
	<input type=submit>
	</form>
EOF
    }
}

# Subroutine to print all activity (domainadmins only)

sub reviewlog {
    my $numrecords=100;
    my $sth;
    $sth=$::dbh->prepare("select max(id),min(id) from log");
    $sth->execute;
    my ($maxid,$minid) = $sth->fetchrow;
    my $startid=$::query->param("startid");
    my $highid=$maxid+1;
    if ($startid) {
	$highid=$startid;
    }
	
    my $lowid=$highid-$numrecords;
    my $nextid=$highid+$numrecords;
    my $previd;
    if ($nextid > ($maxid+1)) {
	$previd=$maxid+1-$numrecords;
	$nextid=$maxid+1;
    } else {
	$previd=$nextid-$numrecords*2;
    }
    ($previd < ($minid+$numrecords)) && ($previd=$minid+$numrecords);


    print "<H1>" . ::getstr("Activity Log") . "</H1>\n";
    print << "EOF";
    <table>
    <tr>
    <td width=50% align=left>
    <form method=t>
    <input type=hidden name=menuitem value=reviewlog>
    <input type=hidden name=adminschool value=$::adminschool>
    <input type=hidden name=startid value=$previd>
    <input type=submit value="Previous $numrecords log records">
    </form>
    </td>
    <td width=50% align=right>
    <form method=post>
    <input type=hidden name=menuitem value=reviewlog>
    <input type=hidden name=adminschool value=$::adminschool>
    <input type=hidden name=startid value=$nextid>
    <input type=submit value="Next $numrecords log records">
    </form>
    </td></tr>
    </table>
EOF
    my $q_username=$::dbh->quote($::username);
    $sth=$::dbh->prepare("select id,time,activity,user from log where id>=$lowid and id < $highid order by id desc");
    $sth->execute;
    print "<table border=1>\n<tr><th colspan=4>" . ::getstr("Activity Log") . "</th></tr>\n";
    while (my ($id, $time, $activity, $userid)=$sth->fetchrow) {
	$date=join(' ',(split(/\s+/,localtime($time)))[0,1,2,3]);
	print "<tr><td>$id</td><td>$userid</td><td>$date</td><td>$activity</td></tr>\n";
    }
    print "</table>\n";
}


# Subroutine checks for errors after every database call.  probably should
# print to a logfile somewhere, as well as to the webpage.

sub dbherr {
    ($::dbh->err) && (print $::dbh->errstr."<br>\n");
}
1;

