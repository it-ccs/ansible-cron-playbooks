#!/usr/bin/perl

package JAVASCRIPT;

sub scripts {
    my $javascript='';
    my ($action, $menu) = @_;

    if ($menu eq 'test') {
	$javascript=<< "EOF";
	var lg = new Array
	var gg = new Array
	var users = new Array
	var dropdownexists=0

	function init () {
	    top.output.document.close()
	    top.output.document.open()
	    top.output.document.writeln("<center><h1>Data loaded.  Select an item from the menu above.</h1>")
	    top.output.document.close()
	}



	function Changes () {
	    top.output.document.close()
	    top.output.document.open()
	    top.output.document.writeln("<center><h1>List of scheduled changes</h1>")
	    top.output.document.writeln("<hr width=10%>")
	    var anychanges=0
	    for (var k in users) {
		var changed=0
		if (users[k].deleted) {
		    top.output.document.writeln(users[k].fullname+" ("+k+") will be deleted.<br>")
		    changed=1
		    anychanges=1
		}
		if (users[k].password) {
		    top.output.document.writeln(users[k].fullname+" ("+k+") has a new password ("+users[k].password+").<br>")
		    changed=1
		    anychanges=1
		}
		for (var l in users[k].groupchanges) {
		    if (users[k].groupchanges[l] == 1) {
			if (l>=lg.length) {
			    top.output.document.writeln(users[k].fullname+" ("+k+") has been added to "+gg[l-lg.length].longname+".<br>")
			} else {
			    top.output.document.writeln(users[k].fullname+" ("+k+") has been added to "+lg[l].longname+".<br>")
			}
			changed=1
			anychanges=1
		    } 
		    if (users[k].groupchanges[l] == -1) {
			if (l>=lg.length) {
			    top.output.document.writeln(users[k].fullname+" ("+k+") has been removed from "+gg[l-lg.length].longname+".<br>")
			} else {
			    top.output.document.writeln(users[k].fullname+" ("+k+") has been removed from "+lg[l].longname+".<br>")
			}
			changed=1
			anychanges=1
		    }
		}
	    if (changed) { top.output.document.writeln("<hr width=10%>") }
	    }
	    if (! anychanges) { top.output.document.writeln("No changes have been made.<hr width=10%>") }
	    top.output.document.close()
	    return false
	}
	function CreateAccounts () {
	    return false
	}


	function groupdropdown () {
	    var l=CurrentGroup
	    top.menu.dropdownexists=1
	    top.output.document.myform.groups.options.length=0
	    var index=0
	    for (var j=0; j<lg.length; j++) {
		var option = new Option (lg[j].longname,index)
		if (j == l) {
		    option.selected = true
		}
		top.output.document.myform.groups.options[index]=option
		index++
	    }
	    for (var j=0; j<gg.length; j++) {
		var option = new Option (gg[j].longname,index)
		if ((j+lg.length) == l) {
		    option.selected = true
		}
		top.output.document.myform.groups.options[index]=option
		index++
	    }
	    var option = new Option ("All Users", l)
	    if (l == (lg.length+gg.length)) {
		option.selected = true
	    }
	    top.output.document.myform.groups.options[index]=option
	}

	function ModifyAccounts () {
	    if (top.menu.dropdownexists) {
		CurrentGroup=top.output.document.myform.groups.selectedIndex;
	    }
	    var l = CurrentGroup
	    top.output.document.close()
	    top.output.document.open()
	    top.output.document.write("<form name=myform><table border=1>")
	    top.output.document.write("<tr><th colspan=2><font size=+2 color=red>Modify Accounts at "+schoolname+"</font></th></tr><tr><td valign=top>")
	    top.output.document.writeln("<select name=groups onChange=top.menu.ModifyAccounts()><option value=0>Unpopulated Dropdown Box</select></td><td>");
	    top.output.document.writeln("<hr><center><font size=+1>Select a User to Modify</font></center><hr></td></tr><tr><td colspan=2><table cellpadding=0 cellspacing=0 border=1><tr><td>")
	    groupdropdown()
	    var i=1
	    if (l == (lg.length+gg.length)) {
		var userlist = new Array;
		var i=0
		for (var k in users) {
		    userlist[i++]=k
		}
		writeuserlist(userlist,0,"ModifyUser")
	    } else {
		if (l<lg.length) {
		    var userlist = new Array;
		    var i=0;
		    for (var k in lg[l].members) {
			if (users[k].groupchanges[l] != -1) {
			    userlist[i++]=k
			}
		    }
		    writeuserlist(userlist,0,"ModifyUser")
		} else {
		    var userlist = new Array;
		    var i=0
		    for (var k in gg[l-lg.length].members) {
			if (users[k].groupchanges[l] != -1) {
			    userlist[i++]=k
			}
		    }
		    writeuserlist(userlist,0,"ModifyUser")
		}
	    }

	    top.output.document.writeln("</td></tr></table>")
	    top.output.document.writeln("</td></tr></table></form>")
	    flaglegend()
	    top.output.document.close()
	    return false
	}

	function flaglegend () {
	    top.output.document.writeln("<table border=1><tr><th colspan=2>Flag Legend</th></tr>")
	    for (var k in userflags) {
		top.output.document.writeln("<tr><td><img src=/k12admin/flags/"+flagcolors[k]+"flag.gif></td><td>"+userflags[k]+"</td></tr>")
	    }
	    top.output.document.writeln("</table>")
	}

	function ListAccounts () {
	    return false
	}

	function Search () {
	    return false
	} 


	function Submit () {
	    var changes=''
	    top.output.document.close()
	    top.output.document.open()
	    top.output.document.writeln("<center><h1>List of scheduled changes</h1>")
	    top.output.document.writeln("Please review these changes and click the SUBMIT button at the bottom if there are no problems.")
	    top.output.document.writeln("<hr width=10%>")
	    var anychanges=0
	    for (var k in users) {
		var changed=0
		if (users[k].deleted) {
		    top.output.document.writeln(users[k].fullname+" ("+k+") will be deleted.<br>")
		    changes+="Deleteuser "+k+"\\n"
		    changed=1
		    anychanges=1
		}
		if (users[k].password) {
		    top.output.document.writeln(users[k].fullname+" ("+k+") has a new password ("+users[k].password+").<br>")
		    changes+="Password "+k+" "+users[k].password+"\\n"
		    changed=1
		    anychanges=1
		}
		for (var l in users[k].groupchanges) {
		    if (users[k].groupchanges[l] == 1) {
			if (l>=lg.length) {
			    top.output.document.writeln(users[k].fullname+" ("+k+") has been added to "+gg[l-lg.length].longname+".<br>")
			    changes+="Addtogroup "+k+" "+gg[l-lg.length].shortname+" "+shortschoolname+"\\n"
			} else {
			    top.output.document.writeln(users[k].fullname+" ("+k+") has been added to "+lg[l].longname+".<br>")
			    changes+="Addtogroup "+k+" "+lg[l].shortname+" "+shortschoolname+"\\n"
			}
			changed=1
			anychanges=1
		    } 
		    if (users[k].groupchanges[l] == -1) {
			if (l>=lg.length) {
			    top.output.document.writeln(users[k].fullname+" ("+k+") has been removed from "+gg[l-lg.length].longname+".<br>")
			    changes+="Removefromgroup "+k+" "+gg[l-lg.length].shortname+" "+shortschoolname+"\\n"
			} else {
			    top.output.document.writeln(users[k].fullname+" ("+k+") has been removed from "+lg[l].longname+".<br>")
			    changes+="Removefromgroup "+k+" "+lg[l].shortname+" "+shortschoolname+"\\n"
			}
			changed=1
			anychanges=1
		    }
		}
	    if (changed) { top.output.document.writeln("<hr width=10%>") }
	    }
	    if (! anychanges) { top.output.document.writeln("No changes have been made.<hr width=10%>") }
	    top.output.document.writeln("<pre>"+changes+"</pre>");
	    top.output.document.writeln("<form name=myform method=post action=users.pl target=_top>");
	    top.output.document.writeln("<input type=hidden name=action value=submitjavascript>")
	    top.output.document.writeln("<input type=hidden name=submitdata>")
	    top.output.document.writeln("<br>");
	    top.output.document.writeln("<input type=submit>");
	    top.output.document.writeln("</form>");
	    top.output.document.myform.submitdata.value=changes
	    top.output.document.close()
	    return false
	} 

	function GroupLists () {
	    return false
	}


	function checkpass() {
	    if (top.output.document.myform.password.value == top.output.document.myform.confirm.value) {
		alert ("Password changed.")
		top.menu.users[top.output.document.myform.userid.value].password=top.output.document.myform.password.value
	    }
	}

	function changegroups (user, group) {
	    var activegroups = new Array();
	    for (var k in users[user].groups) {
		var g=users[user].groups[k]
		activegroups[g]=1
	    }


	    if (top.output.document.myform.elements[group+4].checked) {
		if (activegroups[group]) {
		    users[user].groupchanges[group]=0
		    if (group >=lg.length) { gg[group-lg.length].groupchanges[user]=0 } else { lg[group].groupchanges[user]=0 }

		} else {
		    users[user].groupchanges[group]=1
		    if (group>=lg.length) { gg[group-lg.length].groupchanges[user]=1 } else { lg[group].groupchanges[user]=1 }
		}
	    } else {
		if (activegroups[group]) {
		    users[user].groupchanges[group]=-1
		    if (group >=lg.length) { gg[group-lg.length].groupchanges[user]=-1 } else { lg[group].groupchanges[user]=-1 }
		} else {
		    users[user].groupchanges[group]=0
		    if (group >=lg.length) { gg[group-lg.length].groupchanges[user]=0 } else { lg[group].groupchanges[user]=0 }
		}
	    }
	}




	function ModifyUser (user) {
	    top.menu.dropdownexists=0;
	    top.output.document.close()
	    top.output.document.open()
	    top.output.document.writeln("Working on User #"+user+" ("+users[user].fullname+")<br>")
	    top.output.document.writeln("<form name=myform>")
	    top.output.document.writeln("<input type=hidden name=userid value="+user+">")
	    top.output.document.writeln("<table border=1>")
	    top.output.document.writeln("<tr><td valign=top><table>")
	    top.output.document.writeln("<tr><td>Fullname:</td><td><input name=fullname value=\\""+users[user].fullname+"\\"></td></tr>")
	    top.output.document.writeln("<tr><td>Password:</td><td><input name=password type=password value=\\"******\\" onChange=top.menu.checkpass()></td></tr>")
	    top.output.document.writeln("<tr><td>Confirm Password:</td><td><input name=confirm type=password value=\\"******\\" onChange=top.menu.checkpass()></td></tr>")
	    top.output.document.writeln("</table>")
	    top.output.document.writeln("</td><td>")
	    top.output.document.writeln("<table><tr><th>Local Groups</th><th>Global Groups</th></tr><tr><td valign=top>")
	    var newcol=0
	    var activegroups = new Array();
	    for (var k in users[user].groups) {
		var group=users[user].groups[k]
		activegroups[group]=1
	    }
	    for (var k in lg) {
		var checked=''
		if (((activegroups[k]) && (users[user].groupchanges[k] != -1)) || (users[user].groupchanges[k] == 1)) {
		    checked='checked'
		}
		top.output.document.writeln("<input type=checkbox name=group"+k+" "+checked+" onClick=top.menu.changegroups(\\""+user+"\\","+k+")> "+lg[k].longname+"<br>")
	    }
	    top.output.document.writeln("</td><td valign=top>")
	    for (var k in gg) {
		var checked=''
		if (((activegroups[k+lg.length]) && (users[user].groupchanges[k+lg.length] != -1)) || (users[user].groupchanges[k+lg.length] == 1)) {
		    checked='checked'
		}
		top.output.document.writeln("<input type=checkbox name=group"+(k+lg.length)+" "+checked+" onClick=top.menu.changegroups(\\""+user+"\\","+(k+lg.length)+")> "+gg[k].longname+"<br>")
	    }
	    top.output.document.writeln("</td></tr></table>")
	    top.output.document.writeln("</td></tr>")
	    top.output.document.writeln("</table>")
	    top.output.document.writeln("")
	    top.output.document.writeln("")
	    top.output.document.writeln("")
	    top.output.document.writeln("")
	    top.output.document.writeln("")
	    top.output.document.writeln("<a href=/ onClick=top.menu.ModifyAccounts(0)>Return to Group List</a>")
	    top.output.document.close()
	}



	function writeuserlist(userlist, type, call) {
	    var i=1;
	    var counter=0
	    for (var j in userlist) {
		counter++
		k=userlist[j]
		var checked=''
		if (users[k].deleted == true) {
		    checked='checked'
		}
		var postfix=' '
		for (var t in userflags) {
		    if (users[k].flags & Math.pow(2,t)) {
			postfix=postfix+"<img src=/k12admin/flags/"+flagcolors[t]+"flag.gif>"
		    }
		}
		if (type == 1) {
		    top.output.document.writeln("<input type=checkbox name=box "+checked+" onClick=top.menu."+call+"(\\""+k+"\\")> "+users[k].fullname+postfix+users[k].groups.length);
		}
		if (type == 0) {
		    top.output.document.writeln("<a href=/ onClick=top.menu."+call+"(\\""+k+"\\")>"+users[k].fullname+"</a>"+postfix);
		}
		if (i==4) {
		    top.output.document.writeln("</td></tr><tr><td>")
		    i=0
		} else {
		    top.output.document.writeln("</td><td>")
		}
		i++
	    }
	    if (! counter) { top.output.document.writeln("This group has no members.") }
	}
	
	function DeleteAccounts () {
	    if (top.menu.dropdownexists) {
		CurrentGroup=top.output.document.myform.groups.selectedIndex;
	    }
	    var l = CurrentGroup
	    alert ("Local Group: "+l)
	    top.output.document.close()
	    top.output.document.open()
	    top.output.document.write("<form name=myform><table border=1>")
	    top.output.document.write("<tr><th colspan=2><font size=+2 color=red>Delete Accounts at "+schoolname+"</font></th></tr><tr><td valign=top>")
	    top.output.document.writeln("<select name=groups onChange=top.menu.DeleteAccounts()><option value=0>Unpopulated Dropdown Box</select></td><td>");
	    top.output.document.writeln("<hr><center><font size=+1>Check off users to be deleted "+l+"</font></center><hr></td></tr><tr><td colspan=2><table cellpadding=0 cellspacing=0 border=1><tr><td>")
	    groupdropdown()
	    var i=1
	    if (l == (lg.length+gg.length)) {
		var userlist = new Array;
		var i=0
		for (var k in users) {
		    userlist[i++]=k
		}
		writeuserlist(userlist,1,"deleteuser")
	    } else {
		if (l<lg.length) {
		    var userlist = new Array;
		    var i=0;
		    for (var k in users) {
		    if (((users[k].grouplist[l]) && (users[k].groupchanges[l] != -1)) || (users[k].groupchanges[l] == 1)) {
			    userlist[i++]=k
			}
		    }
		    writeuserlist(userlist,1,"deleteuser")
		} else {
		    var userlist = new Array;
		    var i=0
		    for (var k in users) {
			//if (((users[k].grouplist[l]) && (users[k].groupchanges[l] != -1)) || (users[k].groupchanges[l] == 1)) {
			if (users[k].grouplist[l]) {
			    userlist[i++]=k
			}
		    }

		    writeuserlist(userlist,1,"deleteuser")
		}
	    }

	    top.output.document.writeln("</td></tr></table>")
	    top.output.document.writeln("</td></tr></table></form>")
	    flaglegend()
	    top.output.document.close()
	    return false
	}

	function deleteuser (l) {
	    if (users[l].deleted) {
		users[l].deleted=false
	    } else {
		users[l].deleted=true
	    }
	}


	function member (userid, fullname, flags, groups) {
	    this.userid=userid
	    this.fullname=fullname
	    this.flags=flags
	    this.visible=true
	    this.deleted=false
	    this.groups=groups
	    this.groupchanges=new Array()
	    this.password=''
	    this.grouplist = new Array()
	}

	function localgroup (shortname,longname, restriction) {
	    this.shortname=shortname
	    this.longname=longname
	    this.selected=false
	    this.members=new Array()
	    this.restriction=restriction
	    this.groupchanges = new Array()
	}


	function addm(userid, fullname, flags, groupnum) {
	    m = new member(userid,fullname,flags,new Array ())
	    lg[groupnum].members[userid]=m
	}

	function addgm(userid, fullname, flags, groupnum) {
	    m = new member(userid,fullname,flags,new Array ())
	    gg[groupnum].members[userid]=m
	}

	function addu(userid, fullname, flags, groups) {
	    m = new member(userid,fullname,flags,groups)
	    users[userid]=m
	    for (var g in groups) {
		if (groups[g] == -1) {
		    break
		}
		users[userid].grouplist[groups[g]]=1
		if (userid == 'dschwab') {
		    alert (userid+" in group "+groups[g])
		}
		if (groups[g] < lg.length) {
		    addm(userid,fullname,flags,groups[g])
		} else {
		    addgm(userid,fullname,flags,groups[g]-lg.length)
		}
	    }
	}

EOF
	$javascript.=" // $::indomainadmin <--\n";
	if ($::indomainadmin) {
	    $javascript.="var RestrictionLevel=100\n";
	} else {
	    $javascript.="var RestrictionLevel=0\n";
	}
	$javascript.="var CurrentGroup=0\n";
	$sth=$::dbh->prepare("select users.userid,users.fullname,users.comment,users.flags from users,homeschools where homeschools.school=$::q_adminschool and homeschools.userid=users.userid order by users.fullname,users.userid");
	$sth->execute;
	MENUS::dbherr();
	while (my ($u, $f, $c, $flags) = $sth->fetchrow) {
	    $q_f=$::dbh->quote($f);
	    $order{$index++}=$u;
	    $fullnames{$u}=$q_f;
	    $flags{$u}=$flags;
	}
	my $sth=$::dbh->prepare("select shortname,longname from localgroups where school=$::q_adminschool order by vieworder,longname");
	$sth->execute;
	MENUS::dbherr();
	my $groupnum=0;
	my %groups;
	while (my ($s, $l) = $sth->fetchrow) {
	    $javascript.="lg[$groupnum]=new localgroup('$s', '$l', 0);\n";
	    $q_s=$::dbh->quote($s);
	    my $sti=$::dbh->prepare("select distinct lglist.userid,users.fullname from lglist,users where users.userid=lglist.userid and lglist.school=$::q_adminschool and lglist.localgroup=$q_s order by fullname,userid");
	    $sti->execute;
	    MENUS::dbherr();
	    while (my ($u, $f) = $sti->fetchrow) {
		(next) unless ($fullnames{$u});
		$groups{$u}.="$groupnum,";
	    }
	    $groupnum++;
	}
	my $localgroups=$groupnum;
	$javascript.="// Localgroups: $localgroups\n";
	$javascript.="var schoolname='$::longnames{$::adminschool}'\n";
	$javascript.="var shortschoolname='$::adminschool'\n";
	$sth=$::dbh->prepare("select shortname,longname,restricted from localgroups where school='global' order by vieworder,longname");
	$sth->execute;
	MENUS::dbherr();
	$groupnum=0;
	while (my ($s, $l, $r) = $sth->fetchrow) {
	    $javascript.="gg[$groupnum]=new localgroup('$s', '$l', $r);\n";
	    $q_s=$::dbh->quote($s);
	    my $sti=$::dbh->prepare("select distinct lglist.userid,users.fullname,users.comment from lglist,users where users.userid=lglist.userid and lglist.school=$::q_adminschool and lglist.localgroup=$q_s order by fullname,userid");
	    $sti->execute;
	    MENUS::dbherr();
	    while (my ($u, $f, $c) = $sti->fetchrow) {
		$type=(split(/:/, $c))[1];
		$q_f=$::dbh->quote($f);
		$groups{$u}.=($groupnum+$localgroups).",";
	    }
	    $groupnum++;
	}

	#sub bynumber { $a <=> $b; }

	foreach (sort bynumber keys %order) {
	    $u=$order{$_};
	    $groups{$u}.="-1";
	    $javascript.="addu('$u', ".$fullnames{$u}.", ".$flags{$u}.", new Array(".$groups{$u}."))\n";
	}
	$javascript.="var userflags=new Array\n";
	$javascript.="var flagcolors=new Array\n";
	$sth=$::dbh->prepare("select id,name,color from userflags");
	$sth->execute;
	while (my ($id, $name, $color) = $sth->fetchrow) {
	    $javascript.="userflags[$id]='$name'\n";
	    $javascript.="flagcolors[$id]='$color'\n";
	}
    }
    if ($menu eq 'localgroups') {
	$javascript=<< "EOF";
	var lg = new Array;
	var gg = new Array;
	var users = new Array;


	function member (userid, fullname, type) {
	    this.userid=userid;
	    this.fullname=fullname;
	    this.type=type;
	    this.visible=true;
	}

	function localgroup (shortname,longname, restriction) {
	    this.shortname=shortname;
	    this.longname=longname;
	    this.selected=false;
	    this.members=new Array();
	    this.restriction=restriction
	}


	function addm(userid, fullname, type, groupnum) {
	    m = new member(userid,fullname,type);
	    lg[groupnum].members[userid]=m;
	}

	function addgm(userid, fullname, type, groupnum) {
	    m = new member(userid,fullname,type);
	    gg[groupnum].members[userid]=m;
	}

	function addu(userid, fullname, type, groups) {
	    m = new member(userid,fullname,type);
	    users[userid]=m;
	    for (var g in groups) {
		if (groups[g] == -1) {
		    break;
		}
		if (groups[g] < lg.length) {
		    addm(userid,fullname,type,groups[g])
		} else {
		    addgm(userid,fullname,type,groups[g]-lg.length)
		}
	    }
	}

EOF
	$javascript.=" // $::indomainadmin <--\n";
	if ($::indomainadmin) {
	    $javascript.="var RestrictionLevel=100\n";
	} else {
	    $javascript.="var RestrictionLevel=0\n";
	}
	$sth=$::dbh->prepare("select users.userid,users.fullname,users.comment from users,homeschools where homeschools.school='$::adminschool' and homeschools.userid=users.userid order by users.fullname,users.userid");
	$sth->execute;
	MENUS::dbherr();
	while (my ($u, $f, $c) = $sth->fetchrow) {
	    $type=(split(/\s+/, $c))[1];
	    $q_f=$::dbh->quote($f);
	    $order{$index++}=$u;
	    $fullnames{$u}=$q_f;
	    $types{$u}=$type;
	}
	$t=time();
	$::timingloops{$t}="userids";
	$q_school=$::dbh->quote($::adminschool);
	my $sth=$::dbh->prepare("select shortname,longname from localgroups where school=$q_school order by vieworder,longname");
	$sth->execute;
	MENUS::dbherr();
	my $groupnum=0;
	my %groups;
	while (my ($s, $l) = $sth->fetchrow) {
	    $javascript.="lg[$groupnum]=new localgroup('$s', '$l', 0);\n";
	    $q_s=$::dbh->quote($s);
	    my $sti=$::dbh->prepare("select distinct lglist.userid,users.fullname,users.comment,users.flags from lglist,users where users.userid=lglist.userid and lglist.school=$q_school and lglist.localgroup=$q_s order by fullname,userid");
	    $sti->execute;
	    MENUS::dbherr();
	    while (my ($u, $f, $c, $flags) = $sti->fetchrow) {
		(next) unless ($fullnames{$u});
		if ($flags & $::flags{'staff'}) {
		    $type='Staff';
		} else {
		    $type='Student';
		}
		$q_f=$::dbh->quote($f);
		$groups{$u}.="$groupnum,";
	#	$javascript.="addm('$u', $q_f, '$type', $groupnum);\n";
	    }
	    $groupnum++;
	}
	$t=time();
	$::timingloops{$t}="Grouplists";
	my $localgroups=$groupnum;
	$javascript.="// Localgroups: $localgroups\n";
	$sth=$::dbh->prepare("select shortname,longname,restricted from localgroups where school='global' order by vieworder,longname");
	$sth->execute;
	MENUS::dbherr();
	$groupnum=0;
	while (my ($s, $l, $r) = $sth->fetchrow) {
	    $javascript.="gg[$groupnum]=new localgroup('$s', '$l', $r);\n";
	    $q_s=$::dbh->quote($s);
	    my $sti=$::dbh->prepare("select distinct lglist.userid,users.fullname,users.comment from lglist,users where users.userid=lglist.userid and lglist.school=$q_school and lglist.localgroup=$q_s order by fullname,userid");
	    $sti->execute;
	    MENUS::dbherr();
	    while (my ($u, $f, $c) = $sti->fetchrow) {
		$type=(split(/:/, $c))[1];
		$q_f=$::dbh->quote($f);
		$groups{$u}.=($groupnum+$localgroups).",";
	    }
	    $groupnum++;
	}

	sub bynumber { $a <=> $b; }

	foreach (sort bynumber keys %order) {
	    $u=$order{$_};
	    $groups{$u}.="-1";
	    $javascript.="addu('$u', ".$fullnames{$u}.", '".$types{$u}."', new Array(".$groups{$u}."))\n";
	}
	
	if ($menu eq 'localgroups') {
	    $javascript .= << "EOF";

	function setSelected() {
	    for (var l=0; l<document.localgroups.grouplist.options.length; l++) {
		if (document.localgroups.grouplist.options[l].selected) {
		    lg[document.localgroups.grouplist.options[l].value].selected=true;
		} else {
		    lg[document.localgroups.grouplist.options[l].value].selected=false;
		}
	    }
	}

	function redraw() {
	    document.localgroups.grouplist.options.length=0;
	    var index=0;
	    for (var group in lg) {
		var option=new Option(lg[group].longname+" ("+lg[group].shortname+")",group);
		document.localgroups.grouplist.options[index]=option;
		document.localgroups.grouplist.options[index].selected=lg[group].selected;
		index++;
	    }
	}

	function movedown() {
	    if (document.localgroups.grouplist.options[document.localgroups.grouplist.options.length-1].selected) {
		return;
	    }
	    for (var l=lg.length-2; l>=0; l--) {
		if (document.localgroups.grouplist.options[l].selected) {
		    swap(l,l+1);
		    document.localgroups.grouplist.options[l+1].selected=true;
		}
	    }
	    memberDropdown();
	}

	function moveup() {
	    if (document.localgroups.grouplist.options[0].selected) {
		return;
	    }
	    for (var l=1; l<lg.length; l++) {
		if (document.localgroups.grouplist.options[l].selected) {
		    swap(l-1,l);
		    document.localgroups.grouplist.options[l-1].selected=true;
		}
	    }
	    memberDropdown();
	}

	function deletelocalgroups() {
	    if (confirm("Are you sure you want to delete the selected groups?")) {
		for (var l=document.localgroups.grouplist.options.length-1; l>=0; l--) {
		    if (document.localgroups.grouplist.options[l].selected) {
			for (var k=l; k<lg.length-1; k++) {
			    lg[k]=lg[k+1];
			}
			lg.length=lg.length-1;
		    }
		}
		setSelected;
		redraw();
		memberDropdown();
	    }
	}

	function selectAllNonmembers(state) {
	    for (var l=0; l<document.editgroups.nonmembers.options.length; l++) {
		document.editgroups.nonmembers.options[l].selected=state;
	    }
	}

	function selectAllMembers(state) {
	    for (var l=0; l<document.editgroups.members.options.length; l++) {
		document.editgroups.members.options[l].selected=state;
	    }
	}

	function swap(index1,index2) {
	    setSelected();
	    var temp = lg[index1];
	    lg[index1]=lg[index2];
	    lg[index2]=temp;
	    redraw();
	}

	function submitChanges() {
	    var returnstring="";
	    for (var l=0; l<lg.length; l++) {
		returnstring+=lg[l].shortname+":"+l+":"+lg[l].longname+"\\n";
	    }
	    returnstring+="BeginGroupMembership\\n";
	    var index=lg.length+1;
	    for (var l in lg) {
		for (var k in lg[l].members) {
		    returnstring+=lg[l].shortname+":"+lg[l].members[k].userid+"\\n";
		}
	    }
	    for (var l in gg) {
		for (var k in gg[l].members) {
		    returnstring+=gg[l].shortname+":"+gg[l].members[k].userid+"\\n";
		}
	    }
	    returnstring+="EndGroupMembership\\n";
	    document.submitdata.returndata.value=returnstring;
	    document.submitdata.submit();
	}

	function showValue() {
	    for (var l=0; l<document.localgroups.grouplist.options.length; l++) {
		if (document.localgroups.grouplist.options[l].selected) {
		    alert("Value: "+document.localgroups.grouplist.options[l].value);
		}
	    }
	}

	function setAllVisible() {
	    for (var l in users) {
		users[l].visible=true;
	    }
	}

	function setInvisible(userid) {
	    for (var l=0; l<users.length; l++) {
		if (users[l].userid == userid) {
		    users[l].visible=false;
		    break;
		}
	    }
	}
	
	function setVisible(userid) {
	    for (var l=0; l<users.length; l++) {
		if (users[l].userid == userid) {
		    users[l].visible=true;
		    break;
		}
	    }
	}

	function membersSort(arg1, arg2) {
	    if (arg1.userid > arg2.userid) {
		return 1;
	    } else {
		return -1;
	    }
	}

	function showMembers() {
	    var l=document.editgroups.leftgroup.selectedIndex;
	    var r=document.editgroups.rightgroup.selectedIndex;
	    var localgroups=lg.length;
	    if (localgroups == -1) {
		localgroups=0;
	    }
	    setAllVisible();
	    document.editgroups.members.options.length=0;
	    var index=0;
	    if ((l<localgroups) && (localgroups>0)) {
		for (var k in lg[l].members) {
		    var prefix=''
		    if (users[k].type == 'Teacher') {
			prefix='*'
		    }
		    var option=new Option (prefix+lg[l].members[k].fullname+" ("+lg[l].members[k].userid+")",lg[l].members[k].userid);
		    document.editgroups.members.options[index++]=option;
		    users[lg[l].members[k].userid].visible=false;
		}
	    } else {
		for (var k in gg[l-localgroups].members) {
		    var prefix=''
		    if (users[k].type == 'Teacher') {
			prefix='*'
		    }
		    var option=new Option (prefix+gg[l-localgroups].members[k].fullname+" ("+gg[l-localgroups].members[k].userid+")",gg[l-localgroups].members[k].userid);
		    document.editgroups.members.options[index++]=option;
		    users[gg[l-localgroups].members[k].userid].visible=false;
		}
	    }

	    document.editgroups.nonmembers.options.length=0;
	    index=0;
	    if (r == (lg.length+gg.length)) {
		for (var k in users) {
		    if (users[k].visible) {
			var prefix=''
			if (users[k].type == 'Teacher') {
			    prefix='*'
			}
			var option=new Option (prefix+users[k].fullname+" ("+users[k].userid+")",k);
			document.editgroups.nonmembers.options[index]=option;
			index++;
		    }
		}
	    } else {
		if (r<lg.length) {
		    for (var k in lg[r].members) {
			if (users[k].visible) {
			    var prefix=''
			    if (users[k].type == 'Teacher') {
				prefix='*'
			    }
			    var option=new Option (prefix+users[k].fullname+" ("+users[k].userid+")",k)
			    document.editgroups.nonmembers.options[index]=option
			    index++;
			}
		    }
		} else {
		    for (var k in gg[r-lg.length].members) {
			if (users[k].visible) {
			    var prefix=''
			    if (users[k].type == 'Teacher') {
				prefix='*'
			    }
			    var option=new Option (prefix+users[k].fullname+" ("+users[k].userid+")",k)
			    document.editgroups.nonmembers.options[index]=option
			    index++
			}
		    }
		}
	    }
	}

	function memberDropdown() {
	    document.editgroups.leftgroup.options.length=0
	    document.editgroups.rightgroup.options.length=0
	    var index=0;
	    for (var l=0; l<lg.length; l++) {
		document.editgroups.leftgroup.options[index]=new Option (lg[l].longname+" ("+lg[l].shortname+")",index);
		document.editgroups.rightgroup.options[index]=new Option (lg[l].longname+" ("+lg[l].shortname+")",index);
		index++;
	    }
	    for (var l=0; l<gg.length; l++) {
		document.editgroups.leftgroup.options[index]=new Option (gg[l].longname+" ("+gg[l].shortname+")",index);
		document.editgroups.rightgroup.options[index]=new Option (gg[l].longname+" ("+gg[l].shortname+")",index);
		index++;
	    }
	    document.editgroups.rightgroup.options[index]=new Option ("All Users", l);
	    document.editgroups.rightgroup.options[index].selected=true;
	    document.editgroups.leftgroup.options[0].selected=true;
	}

	function init() {
	    memberDropdown();
	    redraw();
	    showMembers();
	}

	function addlocalgroup() {
	    var shortname='testjunknothing';
	    while (shortname.length != 0) {
		while (shortname == 'testjunknothing') {
		    var shortname=prompt("Enter a short name:\\n(Leave blank to stop)",'');
		    if (! shortname) {
			shortname='';
		    }
		    if (shortname.length == 0) {
			break;
		    }
		    re=/[^a-zA-Z0-9]/;
		    if (re.test(shortname)) {
			confirm("Illegal characters in "+shortname+".\\nPlease use only letters and numbers");
			shortname='testjunknothing';
		    }
		    if ((shortname.length>8) && (shortname != 'testjunknothing')) {
			confirm("Short Name should be no more than eight characters.");
			shortname='testjunknothing';
		    }
		}
		if (shortname.length==0) {
		    break;
		}
		var longname=prompt("Enter a long name:",'');
		if (! longname) {
		    longname='';
		}
		while (longname.length == 0) {
		    alert ("The long name must not be blank.");
		    var longname=prompt("Enter a long name:",longname);
		    if (! longname) {
			longname='';
		    }
		}
		lg[lg.length]=new localgroup(shortname, longname);
		redraw();
		shortname='testjunknothing';
	    }
	    memberDropdown();
	}

	function addtogroup() {
	    var groupnum=document.editgroups.leftgroup.selectedIndex;
	    if (groupnum>=lg.length) {
		if (gg[groupnum-lg.length].restriction > RestrictionLevel) {
		    alert("You do not have access to modify this group.")
		    return
		}
	    }
	    for (var l=0; l<document.editgroups.nonmembers.options.length; l++) {
		if (document.editgroups.nonmembers.options[l].selected) {
		    var num=document.editgroups.nonmembers.options[l].value;
		    addUser(groupnum,num);
		}
	    }
	    showMembers();
	}

	function addUser (groupnum,userid) {
	    if (groupnum < lg.length) {
		lg[groupnum].members[userid]=users[userid];
	    } else {
		gg[groupnum-lg.length].members[userid]=users[userid];
	    }
	    setSelected;
	}

	function removeUser (groupnum,userid) {
	    if (groupnum < lg.length) {
		delete lg[groupnum].members[userid];
	    } else {
		delete gg[groupnum-lg.length].members[userid]
	    }
	    setSelected;
	}

	function removefromgroup() {
	    var groupnum=document.editgroups.leftgroup.selectedIndex;
	    for (var l=0; l<document.editgroups.members.options.length; l++) {
		if (document.editgroups.members.options[l].selected) {
		    var userid=document.editgroups.members.options[l].value;
		    removeUser(groupnum,userid);
		}
	    }
	    showMembers();
	}

	function returnToMain() {
	    if (confirm("If you continue, you will lose all of your changes.\\nAre you sure you want to continue?")) {
		document.returnMain.submit();
	    }
	}
EOF
	}
    }
    unless ($javascript) {
	$javascript="function init() { }";
    }
	
    return $javascript;

}

1;
