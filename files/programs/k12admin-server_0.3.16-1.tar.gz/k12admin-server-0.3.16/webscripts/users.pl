#!/usr/bin/perl -w

package main;

use CGI::Carp qw(fatalsToBrowser);
use strict;

my ($action, $mainmenu);
$action=$mainmenu='';

my $dbuser='k12';
my $dbpass=`cat /etc/k12admin.mysql.pass`;
chop ($dbpass);

# Mysql contains code for interacting with the mysql database server
use DBI;

# CGI contains code that converts form data back to ascii
use CGI;

# menus.pm contains the subroutines for printing data to the web browser.
use MENUS;

# actions.pl contains the subroutines that perform actions for the 
# administrator.  Mainly, this consists of adding tasks to the tasklist
# such as adding a user, deleting a user, etc.  Some of the subroutines
# here also query the mysql server and return the output to the web browser
use ACTIONS;



use JAVASCRIPT;


# Create a new CGI object for retrieving form data
$::query=new CGI;



my $starttime=time;


# Read info from cgi input

$::adminschool=$::query->param('adminschool');
$mainmenu=$::query->param('menuitem');
$action=$::query->param('action');
$::query->delete('action');
$::query->delete('menuitem');
$::query->delete('adminschool');

($action) || ($action='');
($mainmenu) || ($mainmenu='');


$::username=$ENV{'REMOTE_USER'};


# Randomize
srand(time|$$);

print "Content-type: text/html\n\n";
if ($::username) {
# connect to database
$::dbh=DBI->connect("dbi:mysql:k12admin", $dbuser, $dbpass);


# The setupconfig hash contains system configuration options
&setupconfig();

my $sth=$::dbh->prepare("select id,name from userflags");
$sth->execute;
while (my ($id, $name) = $sth->fetchrow) {
    $::flags{$name}=2**$id;
}

$::q_username=$::dbh->quote($::username);
$::q_adminschool=$::dbh->quote($::adminschool);
$sth=$::dbh->prepare("select lang from users where userid=$::q_username");
$sth->execute;
($::lang) = $sth->fetchrow;

if ($action eq 'gettasklist') {
    print "<html><head><title>".::getstr("Activity Log for")." $::username</title>\n";
    print "</head><body>\n";
    print "<center>\n";
    print "<img src=/k12admin/k12admin-header.gif><p>\n";
    print MENUS::gettasklist();
    print "</body></html>\n";
    exit;
}


# Get a list of all schools (for use when a domain admin has connected)

$sth=$::dbh->prepare("select id,school,longname from schools");
$sth->execute;
$::allschools='';
while (my($id, $school, $longname)=$sth->fetchrow) {
    push (@::allschools, $school);
    $::allschools.=$school.",";
    $::longnames{$school}=$longname;
}

# I want to ditch the groups database completely.  Throwback to NT admin days.
# Where else can I store the list of which schools a user administers?  Maybe
# a schooladmins database?

# Or maybe give admin access to all teachers... then they could theoretically
# administer their own groups.  Thinking things like yearbook club here.

$sth=$::dbh->prepare("select userid,school from lglist where localgroup='accountadmins'");
$sth->execute;
while (my ($u, $s) = $sth->fetchrow) {
    $::admins{$u}.="$s,";
}



# Get a list of "Domain Admins".  These users have access to all schools.
# "Domain Admins" must also be in "Staff Admins" to administer staff accounts
# 

$sth=$::dbh->prepare("select flags from users where userid=$::q_username");
$sth->execute;
my ($userflags)=$sth->fetchrow;
$::indomainadmin=0;
if ($userflags & $::flags{'domainadmins'}) {
    ($::indomainadmin=1);
    $::admins{$::username}=$::allschools;
}


# Print out generic top of html page.
# This obviously needs to be configurable.

my $javascript=JAVASCRIPT::scripts($action,$mainmenu);
unless (($mainmenu eq 'test') && ($::query->param('frame') ne 'top')) {
print "<html><head><title>".::getstr("K12Admin Wide Area Network Administration")."</title>\n";
print << "EOF";
<script language="JavaScript">
<!--
function openWindow(myLink,windowName,height,width)
{
    if (! window.focus) return;
    var myWin=window.open("",windowName,"height="+height+",width="+width+",dependent=yes,scrollbars=yes,resize=yes");
    myWin.focus();
    myLink.target=windowName;
}
function goOpener(myLink,closeme,closeonly)
{
    if (! (window.focus && window.opener)) return true;
    window.opener.focus();
    if (! closeonly) window.opener.location.href=myLink.href;
    if (closeme)window.close();
    return false;
}
function menu(item)
{
    href="users.pl?menuitem="+item;
    location.href=href;
}

function changeschool()
{
    index=document.forms[0].adminschool.selectedIndex;
    adminschool=document.forms[0].adminschool.options[index].value;
//    alert("Please wait for "+adminschool+" page to load.");
    location.href="users.pl?adminschool="+adminschool;
}

$javascript

//-->

</script>
EOF
    print "</head><body onLoad=init()>\n";
    unless ($mainmenu eq 'test') {
	print "<center>\n";
	print "<img src=/k12admin/k12admin-header.gif><br>\n";
	if (($mainmenu ne '') && ($mainmenu ne 'tasklist') && ($action ne 'modify') && (($mainmenu ne 'modify') || ($::query->param('a') eq ''))) {
	    print "<a href=/k12admin-cgi/users.pl?adminschool=$::adminschool>Return to Main Menu</a><p>\n";
	}
    }
}

# @schools contains the list of schools $::username can administer.

my @schools=split(/,/,$::admins{$::username});
($::adminschool) || ($::adminschool=$schools[0]);
foreach (sort @schools) {
    my $longname=$::longnames{$_};
    $::schoollist.="<option value=$_>$longname\n";
}
$::selectschool="<form method=post><select OnChange=changeschool() name=adminschool><option value=0 selected> ".::getstr("Select a different school")."\n".$::schoollist;
$::selectschool.="</select></form>\n";
if ($#schools == 0) {
    $::selectschool='';
}

$::selectallschools="<select name=moveto>\n";
foreach (sort @::allschools) {
    my $longname=$::longnames{$_};
    $::selectallschools.="<option value=$_> $longname\n";
}
$::selectallschools.="</select>\n";

# If administrator of only one school, set that school as $::adminschool and go 
# on to the main menu.  If administrator of more than one school, they must
# specify which school to administer first.

if (($::admins{$::username}=~/,$::adminschool,/) || ($::admins{$::username}=~/^$::adminschool,/)) {


# $fortune is the cute little quote at the bottom of the page.  Unnecessary?

    my $fortune=MENUS::fortune();

# "action" is a hidden form element in each page.  It specifies which
# subroutine to execute. Most of these do not print anything out to the 
# web page.  The exception seems to be &listrequests().  Maybe that one
# should be moved.  Not sure why it is here...
    
    my $returntomain_str=::getstr("Return to Main Menu");

    my $actiontime=time;
    ACTIONS: {
      if ($action eq '') { last ACTIONS; }
      if ($action eq 'addmultiple') { ACTIONS::addmultiple(); last ACTIONS; }
      if ($action eq 'delacct') { ACTIONS::delacct(); last ACTIONS; }
      if ($action eq 'localgroups') { ACTIONS::localgroups(); last ACTIONS; }
      if ($action eq 'modifygroups') { ACTIONS::modifygroups(); last ACTIONS; }
      if ($action eq 'modify') { ACTIONS::modify(); last ACTIONS; }
      if ($action eq 'chpass') { ACTIONS::chpass(); last ACTIONS; }
      if ($action eq 'listrequests') { ACTIONS::listrequests(); last ACTIONS; }
      if ($action eq 'editschool') { ACTIONS::editschool(); last ACTIONS; }
      if ($action eq 'editserver') { ACTIONS::editserver(); last ACTIONS; }
      if ($action eq 'adminmachines') { ACTIONS::adminmachines(); last ACTIONS; }
      if ($action eq 'editsystem') { ACTIONS::editsystem(); last ACTIONS; }
      if ($action eq 'searchuser') { ACTIONS::searchuser(); last ACTIONS; }
      if ($action eq 'addschool') { ACTIONS::addschool(); last ACTIONS; }
      if ($action eq 'mvuser') { ACTIONS::mvuser(); last ACTIONS; }
      if ($action eq 'deleteschool') { ACTIONS::deleteschool(); last ACTIONS; }
      if ($action eq 'renameschool') { ACTIONS::renameschool(); last ACTIONS; }
      if ($action eq 'translate') { ACTIONS::translate(); last ACTIONS; }
      if ($action eq 'language') { ACTIONS::language(); last ACTIONS; }
      if ($action eq 'setdomainadmins') { ACTIONS::setdomainadmins(); last ACTIONS; }
      if ($action eq 'submitjavascript') { ACTIONS::submitjavascript(); last ACTIONS; }
    }

      #if ($action eq 'logout') { ACTIONS::logout(); last ACTIONS; }
      #if ($action eq 'modacctstaff') { ACTIONS::modacct('staff'); last ACTIONS; }
      #if ($action eq 'modacctaf') { ACTIONS::modacct('a','f'); last ACTIONS; }
      #if ($action eq 'modacctgl') { ACTIONS::modacct('g','l'); last ACTIONS; }
      #if ($action eq 'modacctmr') { ACTIONS::modacct('m','r'); last ACTIONS; }
      #if ($action eq 'modacctsz') { ACTIONS::modacct('s','z'); last ACTIONS; }
# Ok.  $mainmenu is a misnomer.  This "menu" items can be called from
# anywhere.  They basically call a subroutine that spits data out on the
# web page.  This list of subroutines has gotten quite long, but I still
# think it is a fairly elegant solution.  Keeps the whole script in one
# file, anyway.
my $menutime=time;
    
    MENU: {
      if ($mainmenu eq '') { MENUS::mainmenu(); last MENU; }
      if ($mainmenu eq 'searchuser') { MENUS::searchuser(); last MENU; }
      if ($mainmenu eq 'squidlog') { MENUS::squidlog(); last MENU; }
      if ($mainmenu eq 'localgroups') { MENUS::localgroups(); last MENU; }
      if ($mainmenu eq 'grouplists') { MENUS::grouplists(); last MENU; }
      if ($mainmenu eq 'modifygroups') { MENUS::modifygroups(); last MENU; }
      if ($mainmenu eq 'modify') { MENUS::modify(); last MENU; }
      if ($mainmenu eq 'addmultiple') { MENUS::addmultiple(); last MENU; }
      if ($mainmenu eq 'chpass') { MENUS::chpass(); last MENU; }
      if ($mainmenu eq 'delacct') { MENUS::delacct(); last MENU; }
      if ($mainmenu eq 'test') { MENUS::test(); last MENU; }
      if ($mainmenu eq 'listrequests') { MENUS::listrequests(); last MENU; }
      if ($mainmenu eq 'admintools') { MENUS::admintools(); last MENU; }
      if ($mainmenu eq 'addschool') { MENUS::addschool(); last MENU; }
      if ($mainmenu eq 'editschool') { MENUS::editschool(); last MENU; }
      if ($mainmenu eq 'editserver') { MENUS::editserver(); last MENU; }
      if ($mainmenu eq 'adminmachines') { MENUS::adminmachines(); last MENU; }
      if ($mainmenu eq 'editsystem') { MENUS::editsystem(); last MENU; }
      if ($mainmenu eq 'setdomainadmins') { MENUS::setdomainadmins(); last MENU; }
      if ($mainmenu eq 'reviewlog') { MENUS::reviewlog(); last MENU; }
      if ($mainmenu eq 'reviewaudit') { MENUS::reviewaudit(); last MENU; }
      if ($mainmenu eq 'reviewauditschool') { MENUS::reviewauditschool(); last MENU; }
      if ($mainmenu eq 'deleteschool') { MENUS::deleteschool(); last MENU; }
      if ($mainmenu eq 'renameschool') { MENUS::renameschool(); last MENU; }
      if ($mainmenu eq 'listacct') { MENUS::listacct(); last MENU; }
      if ($mainmenu eq 'movelocalgroup') { MENUS::movelocalgroup(); last MENU; }
      if ($mainmenu eq 'moveuser') { MENUS::moveuser(); last MENU; }
      if ($mainmenu eq 'logout') { MENUS::logoutform(); last MENU; }
      if ($mainmenu eq 'skip') { MENUS::skipform(); last MENU; }
      if ($mainmenu eq 'help') { &naform(); last MENU; }
      if ($mainmenu eq 'translate') { &MENUS::translate(); last MENU; }
      if ($mainmenu eq 'language') { &MENUS::language(); last MENU; }

    }
    my $tasklisttime=time;


#if ($mainmenu eq 'modacct') { MENUS::modacct(); last MENU; }
#if ($mainmenu eq 'modacctstaff') { MENUS::modacct('staff'); last MENU; }
#if ($mainmenu eq 'modacctaf') { MENUS::modacct('a','f'); last MENU; }
#if ($mainmenu eq 'modacctgl') { MENUS::modacct('g','l'); last MENU; }
#if ($mainmenu eq 'modacctmr') { MENUS::modacct('m','r'); last MENU; }
#if ($mainmenu eq 'modacctsz') { MENUS::modacct('s','z'); last MENU; }
# MENUS::gettasklist($::username) prints out a list of the tasks requested by $::username
# in the past three hours.

    if ($mainmenu eq 'test') {
	exit;
    }
    print "<a href=users.pl?action=gettasklist target=\"Tasklist for $::username\">" . ::getstr("Show tasklist") . "</a>\n";
    print "<P>\n";
    ((! ($mainmenu=~/^skip/)) && (! ($mainmenu=~/^l_/))) && (print $fortune);
    #print "<b>Timing Loops</b><br>Initialization: ".($actiontime-$starttime)."s\n";
    #print "Actions:  ".($menutime-$actiontime)."s\n";
    #print "Menus: ".($tasklisttime-$menutime)."s\n";
    #print "Tasklist/Fortune: ".(time-$tasklisttime)."s<br>\n";
    if ($mainmenu eq 'test') {
	print "</html>\n";
    } else {
	print "</body></html>\n";
    }
  } else {

# No admin rights

    print "<H1>" . ::getstr("You have no administrative rights") . "</H1>\n";
    print ::getstr("Please leave this site immediately.") . "\n";
  }
}




sub log {
    my $q_activity=$::dbh->quote($_[0]);
    my $activity=$_[0];

    my $time=time();
    my $sth=$::dbh->prepare("insert into log (time, user, activity) values ($time, '$::username', $q_activity)");
    $sth->execute;
    MENUS::dbherr();

    # I want to add all the NT administration stuff in here as well.  Convert
    # each activity into an insert into the tasklist table.  Currently the
    # tasklist table is not used to log _all_ activity because not all actions
    # are performed on the NT servers (due to callous disregard on my part).
    my ($task, $rest) = split(/:/, $activity, 2);

    SWITCH: {
	if ($task eq '') {
	    last SWITCH;
	}
	if ($task eq 'Adduser') {
	    my ($id, $password, $first, $last, $type, $school) = split(/\s/, $rest);
	    my $param=$::dbh->quote("add,$id,$password,$first,$last,$type,$school, ");
	    my $sth=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', $param, '1', '')");
	    $sth->execute;
	    MENUS::dbherr();

	}
	if ($task eq 'Deleteuser') {
	    my ($id) = split(/\s/, $rest);
	    my $param=$::dbh->quote("delete,$_,$::adminschool,staff, ");
	    my $sth=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', $param, '1', '')");
	    $sth->execute;
	    MENUS::dbherr();
	}

	if ($task eq 'Password') {
	    my ($userid, $password) = split(/\s/, $rest);
	    my $param="chpass,$userid,$password,";
	    my $sth=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', '$param', '1', '' ) ");
	    $sth->execute;
	    MENUS::dbherr();
	    last SWITCH;
	}
	if ($task eq 'Fullname') {
	    my ($userid, $fullname) = split(/\s/, $rest, 2);
	    my $param=$::dbh->quote("modify,$userid /fullname:\"$fullname\",");
	    my $daf=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', $param, '1', '' )");
	    $daf->execute;
	    MENUS::dbherr();
	    last SWITCH;
	}
	if ($task eq 'Addtogroup') {
	    my ($userid,$group,$school) = split(/\s/, $rest, 3);
	    my $param=$::dbh->quote("addgrp,$userid,$group,$school,");
	    my $sth=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', $param, '1', '')");
	    $sth->execute;
	    MENUS::dbherr();
	}
	if ($task eq 'Removefromgroup') {
	    my ($userid,$group,$school) = split(/\s/, $rest, 3);
	    my $param=$::dbh->quote("delgrp,$userid,$group,$school,");
	    my $sth=$::dbh->prepare("insert into tasklist (userid, date, task, status, errors) values ( '$::username', '$time', $param, '1', '')");
	    $sth->execute;
	    MENUS::dbherr();
	}
    }
}


# 
# getstr() is the internationalization part of k12admin.  English text is passed through
# the getstr subroutine which looks to see if a translation is available.  If a translation
# is not available, it just returns the english string again.  If the english text isn't
# even in the database, an entry is added for that text.  I'm going to add a feature to 
# the domain tools section so that localization (translation to a particular language) can
# be done from within the k12admin interface.  All that remains to be done for internationalization
# purposes is to wrap all english output text with a getstr() subroutine call.
#
# ie
#
# replace:  print "Welcome to k12admin!";
# with:     print ::getstr("Welcome to k12admin!","Optional hint for translators (add context info here)");
#

sub getstr {
    my $sth;
    ($::lang='english') unless ($::lang);
    my ($string) = shift;
    my ($hint) = shift;
    my $tran_string;
    my $q_string=$::dbh->quote($string);
    my $q_hint=$::dbh->quote($hint);
    ($q_hint) || ($q_hint="''");
    (defined($hint)) || ($q_hint="''");
    $sth=$::dbh->prepare("select $::lang from strings where english=$q_string and hint=$q_hint");
    $sth->execute;
    if ($sth->rows <= 0) {
	my $sti=$::dbh->prepare("insert into strings (english,hint) values ($q_string,$q_hint)");
	$sti->execute;
    }
    $tran_string=$sth->fetchrow;
    if ($tran_string) {
	return $tran_string;
    } else {
	return $string;
    }
}

sub setupconfig {
    my $sth=$::dbh->prepare("select optionname, optionvalue from systemconfig");
    $sth->execute;
    MENUS::dbherr();
    while (my ($item, $value) = $sth->fetchrow) {
	$::configs{$item}=$value;
    }
}
