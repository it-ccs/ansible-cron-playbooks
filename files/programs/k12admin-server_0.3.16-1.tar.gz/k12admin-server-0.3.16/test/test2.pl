#!/usr/bin/perl
use K12Admin;

$district = K12Admin->new();

$district->adduser("Steve", "Tonnesen", "testpass");
$district->adduser("Sue", "Tonnesen", "testpass");
$district->adduser("Ed", "Tonnesen", "testpass");
$district->adduser("Carol", "Tonnesen", "testpass");
$district->adduser("Rob", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->adduser("Cher", "Tonnesen", "testpass");
$district->showuser(0);
$district->showuser(1);
$district->showuser(2);
$district->showuser(3);
$district->showuser(4);
$district->showuser(5);
$district->showuser(6);
$district->showuser(7);
$district->showuser(8);
$district->showuser(9);
$district->showuser(10);
$district->showuser(11);
$district->showuser(12);
$district->showuser(13);
$district->numgroups();
