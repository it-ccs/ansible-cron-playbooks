#!/usr/bin/perl
package K12Admin;
use strict;
use User;
use Group;
use DBI;

my $dbuser='k12';
my %systemflags;

my $dbpass=`cat /etc/k12admin.mysql.pass`;
chop ($dbpass);

$K12Admin::dbh=DBI->connect("dbi:mysql:k12admin", $dbuser, $dbpass);

sub dbherr {
}

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    $self->{USERS} = [];
    $self->{GROUPS} = [];

    bless($self, $class);
    return $self;
}

sub adduser {
    my $self = shift;
    my $first = shift;
    my $last = shift;
    my $password = shift;
    my $user = User->new($first, $last, $password);
    push @{ $self->{USERS} }, $user;
}

sub addgroup {
    my $self = shift;
    my $shortname = shift;
    my $longname = shift;
    my $group = Group->new($shortname, $longname);
    push @{ $self->{GROUPS} }, $group;
}


sub showuser {
    my $self = shift;
    my $number = shift;
    my $user = ${ $self->{USERS} }[$number];
    printf "User: %s\n", $user->first();
    printf "Userid: %s\n", $user->userid();
    printf "UID: %d\n", $user->uid();
}

sub numgroups {
    my $self = shift;
    #${ $self->{GROUPS} }[0].members();
    print "TEST: ".$#{ $self->{GROUPS} }."\n";
}

sub systemflags {
    #my $self = shift;
    my $flag = shift;
    if ($systemflags{$flag}) {
	return $systemflags{$flag};
    } else {
	my $q_flag=$K12Admin::dbh->quote($flag);
	my $sth=$K12Admin::dbh->prepare("select optionvalue from systemconfig where optionname=$q_flag");
	$sth->execute;
	my ($value) = $sth->fetchrow;
	$systemflags{$flag}=$value;
	return $systemflags{$flag};
    }
}

1;
