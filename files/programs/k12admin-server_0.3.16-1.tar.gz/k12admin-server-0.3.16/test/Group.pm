#!/usr/bin/perl

package Group;
use strict;

my $counter=0;
my %gidlist;

sub new {
    my $self = {};
    my $package = shift;
    my $short = shift;
    my $long = shift;
    my $school = shift;
    $school='SouthHaze';
    $self->{GID} = getfreegid();
    $self->{SHORTNAME} = $short;
    $self->{LONGNAME} = $long;
    $self->{VIEWORDER} = 1000;
    $self->{SCHOOL} = $school;
    $self->{FLAGS} = 0;
    $self->{MEMBERS} = [];
    print "New Group: $short (" . $self->{GID} . ")\n";
    my $q_short=$K12Admin::dbh->quote($short);
    my $q_long=$K12Admin::dbh->quote($long);
    my $q_school=$K12Admin::dbh->quote($school);
    my $sth=$K12Admin::dbh->prepare("update localgroups set shortname=$q_short,longname=$q_long,school=$q_school,vieworder=1000 where id=$self->{GID}");
    my $rc = $sth->execute;
    bless($self);
    return $self;
}

sub gid {
    my $self = shift;
    #if (@_) { $self->{UID} = shift }
    return $self->{GID};
}

sub shortname {
    my $self=shift;
    #if (@_) { $self->{USERID} = shift }
    return $self->{SHORTNAME};
}

sub longname {
    my $self=shift;
    #if (@_) { $self->{FIRSTNAME} = shift }
    return $self->{LONGNAME};
}

sub members {
    my $self=shift;
    print "NUMBER OF MEMBERS: ".$#{ $self->{MEMBERS} }."\n";
}


sub getfreegid {
    unless (keys %gidlist) {
	my $sth=$K12Admin::dbh->prepare("select id from localgroups order by id");
	$sth->execute;
	K12Admin::dbherr();
	while (my ($id) = $sth->fetchrow) {
	    $gidlist{$id}=1;
	}
    }
    for (my $i=1; $i<10000; $i++) {
	(next) if ($gidlist{$i});
	$gidlist{$i}=1;
	my $sth=$K12Admin::dbh->prepare("insert into localgroups (id) values ($i)");
	my $rc = $sth->execute;
	K12Admin::dbherr();
	if (! $rc) {
	    # Collision, try again
	    return getfreegid();
	} else {
	    return $i;
	}
    }
}

1;
