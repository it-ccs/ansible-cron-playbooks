#!/usr/bin/perl

package User;
use strict;

my $counter=0;
my %uidlist;
my %useridlist;

sub new {
    print $counter++."\n";
    my $self = {};
    my $package = shift;
    my $first = shift;
    my $last = shift;
    my $pasword= shift;
    $self->{UID} = getfreeuid();
    my $userid=generateuserid($first, $last);
    $self->{USERID} = $userid;
    $self->{FIRSTNAME} = $first;
    $self->{LASTNAME} = $last;
    $self->{COMMENT} = undef;
    $self->{FLAGS} = undef;
    bless($self);
    return $self;
}

sub uid {
    my $self = shift;
    #if (@_) { $self->{UID} = shift }
    return $self->{UID};
}

sub userid {
    my $self=shift;
    #if (@_) { $self->{USERID} = shift }
    return $self->{USERID};
}

sub first {
    my $self=shift;
    #if (@_) { $self->{FIRSTNAME} = shift }
    return $self->{FIRSTNAME}." ".$self->{LASTNAME};
}

sub generateuserid {
    my ($first, $last) = @_;
    my $scheme = K12Admin::systemflags('namescheme');
    my $limit8 = K12Admin::systemflags('limit8');
    my $nametaken=0;
    my $i=1;
    my $j=1;
    $last=~tr/A-Z/a-z/;
    $last=~s/\'//g;
    $last=~s/\-//g;
    $first=~tr/A-Z/a-z/;
    $first=~s/\'//g;
    $first=~s/\-//g;
    ($scheme) || ($scheme = 'First Initial + Last Name');
    if ($scheme eq 'First Initial + Last Name') {
	my $id=substr($first,0,$i++).$last;
	if ($limit8) {
	    $id=substr($id, 0, 8);
	}
	my $stf=$K12Admin::dbh->prepare("select userid from users where userid='$id'");
	$stf->execute;
	K12Admin::dbherr();
	($stf->rows) && ($nametaken=1);
	($useridlist{$id}) && ($nametaken=1);
	while ($nametaken) {
	    if ($limit8) {
		if ($j>9) {
		    $id=substr($id,0,6).$j++;
		} else {
		    $id=substr($id,0,7).$j++;
	        }
	    } else {
		if ($i <= length($first)) {
		    $id=substr($first,0,$i++).$last;
		} else {
		    $id=substr($first,0,1).$last.$j++;
		}
	    }
	    $stf=$K12Admin::dbh->prepare("select userid from users where userid='$id'");
	    $stf->execute;
	    K12Admin::dbherr();
	    ($stf->rows) ? ($nametaken=1) : ($nametaken=0);
	    ($useridlist{$id}) && ($nametaken=1);
	}
	$useridlist{$id}=1;
	return $id;
    } elsif ($scheme eq 'First Name + Last Initial') {
	my $id=$first.substr($last,0,1);
	if ($limit8) {
	    $id=substr($id, 0, 8);
	}
	my $stf=$K12Admin::dbh->prepare("select userid from users where userid='$id'");
	$stf->execute;
	K12Admin::dbherr();
	($stf->rows) && ($nametaken=1);
	while ($nametaken) {
	    if ($limit8) {
		if ($j > 9) {
		    $id=substr($id,0,6).$j++;
		} else {
		    $id=substr($id,0,7).$j++;
		}
	    } else {
		$id=$first.substr($last,0,1).$j++;
	    }
	    $stf=$K12Admin::dbh->prepare("select userid from users where userid='$id'");
	    $stf->execute;
	    K12Admin::dbherr();
	    ($stf->rows) ? ($nametaken=1) : ($nametaken=0);
	}
	$useridlist{$id}=1;
	return $id;
    } elsif ($scheme eq 'numeric') {

# Not yet available.  Just reverts to first initial+last name I kind of doubt
# the usefulness of this option anyway.  I was just filling in space until
# other options are added.

	my $id=substr($first,0,$i++).$last;
	my $stf=$K12Admin::dbh->prepare("select userid from users where userid='$id'");
	$stf->execute;
	K12Admin::dbherr();
	($stf->rows) && ($nametaken=1);
	while ($nametaken) {
	  if ($i <= length($first)) {
	    $id=substr($first,0,$i++).$last;
	  } else {
	    $id=substr($first,0,1).$last.$j++;
	  }
	  $stf=$K12Admin::dbh->prepare("select userid from users where userid='$id'");
	  $stf->execute;
	  K12Admin::dbherr();
	  ($stf->rows) ? ($nametaken=1) : ($nametaken=0);
	}
	$useridlist{$id}=1;
	return $id;
    }
}

sub getfreeuid {
    unless (keys %uidlist) {
	my $sth=$K12Admin::dbh->prepare("select uid from users order by uid");
	$sth->execute;
	K12Admin::dbherr();
	while (my ($uid) = $sth->fetchrow) {
	    $uidlist{$uid}=1;
	}
    }
    for (my $i=1000; $i<60000; $i++) {
	(next) if ($uidlist{$i});
	$uidlist{$i}=1;
	my $sth=$K12Admin::dbh->prepare("insert into users (uid) values ($i)");
	my $rc = $sth->execute;
	K12Admin::dbherr();
	if (! $rc) {
	    # Collision, try again
	    return getfreeuid();
	} else {
	    return $i;
	}
    }
}


1;
