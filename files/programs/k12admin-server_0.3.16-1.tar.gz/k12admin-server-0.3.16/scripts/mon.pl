#!/usr/bin/perl
#
# $Id: monitor.pl,v 1.1.1.1 1998/05/09 16:11:03 tonnesen Exp $
#
# $Log: monitor.pl,v $
# Revision 1.1.1.1  1998/05/09 16:11:03  tonnesen
# Web Administration
#
#
$|=1;
my $dbuser='k12';
my $dbpass=`cat /etc/k12admin.mysql.pass`;
chop ($dbpass);

use Socket;
use DBI;
open (T, ">/var/lock/monitork12");
if (flock(T, 6)) {
    select T; $|=1; select STDOUT;
    print T "$$\n";
    $dbh=DBI->connect("dbi:mysql:k12admin",$dbuser,$dbpass);
#  $sth=$dbh->prepare("select server,port from servers");
#  $sth->execute;
#  while (@record=$sth->fetchrow) {
#    print $record[0].":".$record[1]."\n";
#    $ports{$record[0]}=$record[1];
#  }
    $ports{'manhattan'}=4256;
    #$ports{'hazsec'}=4256;
    #$ports{'beth'}=4256;
    open (ID, "/var/k12admin/home/lastNTid");
    $lastid=<ID>;
    chomp ($lastid);
    print "LAST: $lastid\n";
    $sth=$dbh->prepare("select id,user,time,activity from log where id>$lastid order by id");
    $sth->execute;
    print "Records: ".$sth->rows."\n";
    RECORD:
    while (my ($id, $userid, $date, $task)=$sth->fetchrow) {
	SWITCH:
	{
	    if ($task=~/^Addgroup:(\w*) (\w*) (.*)/) { $task="newgrp,$1 $2,"; last SWITCH; }
	    if ($task=~/^Deletegroup:(\w*) (\w*) (.*)/) {$task="removegrp,$1 $2,"; last SWITCH; }
	    if ($task=~/^Addtogroup:(\w*) (\w*) (\w*)/) {$task="addgrp,$1,$3 $2,"; last SWITCH; }
	    if ($task=~/^Removefromgroup:(\w*) (\w*) (\w*)/) {$task="delgrp,$1,$3 $2,"; last SWITCH; }
	    if ($task=~/^Fullname:(\w*) (.*)/) {$task="modify $1 /comment:\"$2\","; last SWITCH; }
	    if ($task=~/^Password:(\w*) (\w*)/) {$task="chpass,$1,$2"; last SWITCH; }
	    if ($task=~/^Deleteuser:(\w*)/) {$task="delete,$1,"; last SWITCH; }
	    if ($task=~/^Adduser:(\w*) (\w*) (\w*) (\w*) (\w*) (\w*)/) {$task="add,$1,$2,$3,$4,$5,$6,"; last SWITCH; }
	    $lastid=$id;
	    next RECORD;
	}
	$otask=$task;
	$textdate=localtime($date);
	print "----------------------------------\n";
	$printtask=$task;
	if ($printtask=~/^add,(\w*),\w*,(.*)/) {
	    $printtask="add,$1,*****,$2";
	}
	if ($printtask=~/^chpass,(\w*),/) {
	    $printtask="chpass,$1,*****,";
	}


	print "Admin: $userid\nDate: $textdate\nTask: $printtask\n";
	print "----------------------------------\n";
	$return='';
	foreach (keys %ports) {
	    ($server)=split(/\./);
	    print "$task $_\n";
	    $error=&ntutil($task,$_,$ports{$_});
	    #$error=&ntutil2($task,$_,$ports{$_});
	    print "$server: $error\n";
	    ($error=~/completed/) || ($return.="$server: $error<br>");
	    $return.="$server: $error<br>";
	}
	($return) || ($return='completed');
	print "----------------------------------\n";
	$q_task=$dbh->quote($otask);
	$lastid=$id;
	open (ID, ">/var/k12admin/home/lastNTid");
	print ID "$lastid\n";
	close ID;
    }
    flock(T, 12);
} else {
      print "File locked.\n";
}


sub ntutil2 {
      return "completed";
}


sub ntutil {
    sub getreply {
	my ($errormsg,$buffer, $counter);
	$errormsg="";
	until ($buffer=~/^Waiting:/) {
	    $buffer=<S>;
	    if (! ($buffer=~/^Waiting:/)) {
		$errormsg=$errormsg.$buffer;
		print OUT $buffer;
	    } else {
		return ($errormsg);
	    }
	}
	return ($errormsg);
    }

    local ($param,$errorm,$type,$sockaddr,$name,$aliases,$port,$foo,$this,$that);
    $param=$_[0];
    ($port=$_[2]) || ($port=$ports{'hazsec'});
    ($pdc=$_[1]) || ($pdc='hazsec.cmsd.bc.ca');
    print "$pdc : $port : connecting\n";

    chop ($hostname = `hostname`);

    $iaddr=inet_aton($pdc);
    $paddr= sockaddr_in($port, $iaddr);
    $proto=getprotobyname('tcp');

    socket (S, PF_INET, SOCK_STREAM, $proto) || die "Socket: $!";
    connect (S, $paddr) || die "Connect: $!";



    select(S); $|=1; select(STDOUT);
    &getreply();
    send(S,"$param\n",0);
    $errorm=&getreply();
    sleep 2;
    send(S,"quit\n",0);
    close(S);
    return($errorm);
}

